# Hook latency budget comparison

Current: 7/7. Pre-edit snapshot: 4/7.

Single paired case; no time/token comparison. Four shared passes are regression controls.
