# Skill benchmark: research-orchestrator-skill

Included runs: 0; excluded runs: 2.

with_skill - old_skill comparison: 0 / 1 cases matched. Delta unavailable (no matched cases).
Excluded 2 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |

## Excluded runs

- work-project-start/old_skill: Preflight infrastructure exclusion: 90-second timeout before any recorded tool execution or task work; native event 5 reports the initial skill-file read/command runner stalled; outputs retain only unchanged brief.md and empty final.md. Exact infrastructure root cause is unconfirmed.
- work-project-start/with_skill: Preflight infrastructure exclusion: 90-second timeout before any recorded tool execution or task work; native event 5 reports the initial skill-file read/command runner stalled; outputs retain only unchanged brief.md and empty final.md. Exact infrastructure root cause is unconfirmed.
