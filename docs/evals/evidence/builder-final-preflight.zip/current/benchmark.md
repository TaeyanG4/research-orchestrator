# Skill benchmark: research-orchestrator-skill

Included runs: 0; excluded runs: 2.

with_skill - old_skill comparison: 0 / 1 cases matched. Delta unavailable (no matched cases).
Excluded 2 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |

## Excluded runs

- work-project-start/old_skill: Grading error: Unavailable preflight: timeout before any recorded tool result or substantive project output; exclude from behavioral scoring.
- work-project-start/with_skill: Grading error: Unavailable preflight: timeout before any recorded tool result or substantive project output; exclude from behavioral scoring.
