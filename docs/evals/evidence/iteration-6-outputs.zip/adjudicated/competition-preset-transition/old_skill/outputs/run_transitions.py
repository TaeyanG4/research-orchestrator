"""Capture local matrix attempts against the supplied, unmodified skill.

Only the skill's initializer and checker are executed. Outward command text is
stored as data. This harness does not implement a replacement initializer/hook.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
SKILL = ROOT.parent / "skill"
INITIALIZER = SKILL / "scripts" / "init_research_orchestrator.py"
CHECKER = SKILL / "scripts" / "check_project.py"
PYTHON = Path(r"<host-path-1d5ebf570ab0>")
PROJECTS = ROOT / "projects"
EVIDENCE = ROOT / "evidence"
CASES = {
    "inherited": None,
    "custom": "release-client publish; delivery-tool send",
    "opted-out": "none",
    "legacy": None,
}


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory() -> dict[str, str]:
    return {
        path.relative_to(SKILL).as_posix(): digest(path)
        for path in sorted(SKILL.rglob("*"))
        if path.is_file()
    }


def run(script: Path, args: list[str], directory: Path, stem: str) -> dict:
    if script not in (INITIALIZER, CHECKER):
        raise ValueError("Only supplied initializer/checker may run")
    argv = [str(PYTHON), "-B", str(script), *args]
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        argv, cwd=ROOT, env=env, capture_output=True, shell=False, timeout=30
    )
    # Keep raw subprocess bytes as evidence, separately from their decoded JSON view.
    (directory / f"{stem}.stdout.txt").write_bytes(completed.stdout)
    (directory / f"{stem}.stderr.txt").write_bytes(completed.stderr)
    record = {
        "argv": argv,
        "cwd": str(ROOT),
        "exit_code": completed.returncode,
        "stdout": completed.stdout.decode("utf-8", errors="replace"),
        "stderr": completed.stderr.decode("utf-8", errors="replace"),
    }
    write_json(directory / f"{stem}.json", record)
    return record


def settings(text: str) -> dict[str, str]:
    section = re.search(r"^## Project settings\n(.*?)(?=^## |\Z)", text, re.M | re.S)
    return dict(re.findall(r"^- ([^:\n]+): (.+)$", section.group(1), re.M)) if section else {}


def main() -> None:
    # Refuse to overwrite previous projects or evidence on a rerun.
    if PROJECTS.exists() or EVIDENCE.exists():
        raise SystemExit("projects/ or evidence/ already exists; preserve previous artifacts")
    PROJECTS.mkdir()
    EVIDENCE.mkdir()
    initial_inventory = inventory()
    write_json(EVIDENCE / "skill-manifest-before.json", initial_inventory)
    help_result = run(INITIALIZER, ["--help"], EVIDENCE, "initializer-help")

    source = INITIALIZER.read_text(encoding="utf-8")
    cli_flags = re.findall(r'parser\.add_argument\(([^\n]+)', source)
    hook_candidates = [
        name for name in initial_inventory
        if "hook" in name.lower() or "pre_tool" in name.lower() or "pre-tool" in name.lower()
    ]
    support = {
        "skill_root": str(SKILL),
        "initializer": str(INITIALIZER),
        "files": list(initial_inventory),
        "parser_argument_declarations": cli_flags,
        "hook_path_candidates": hook_candidates,
        "hook_entrypoint": None,
        "preset_support": False,
        "external_actions_support": False,
        "competition_hub_support": False,
        "phase_clock_support": False,
        "enforcement_support": False,
    }
    write_json(EVIDENCE / "capability-audit.json", support)
    assert not hook_candidates, "Unexpected hook path; inspect it before proceeding"
    assert "--preset" not in help_result["stdout"]
    assert "--external-actions" not in help_result["stdout"]

    results = []
    for name, actions in CASES.items():
        project = PROJECTS / name
        case_evidence = EVIDENCE / name
        project.mkdir()
        case_evidence.mkdir()
        requested = {
            "case": name,
            "initial_preset": "team-research",
            "external_actions_option_present": actions is not None,
            "initial_external_actions_argument": actions,
            "remove_only_external_actions_source_marker": name == "legacy",
            "target_preset": "competition-team",
            "competition_hub": "review-trial",
            "phase_clock": "off",
            "enforcement_initial_and_target": "block",
            "competition_identity": "local-transition-eval",
            "competition_identity_configured": False,
            "credentials_configured": False,
            "note": "Requested values, not generated or active settings",
        }
        write_json(case_evidence / "requested.json", requested)
        common = [
            str(project), "--name", f"Transition {name} (baseline only)",
            "--agents", "A", "--user", "local-eval", "--platform", "adaptive",
            "--platforms", "Claude Code, Codex", "--git", "off",
            "--collector", "off", "--queue-limits", "50,5",
            "--reviewer", "off", "--fallback", "same-host",
        ]
        # These option names are diagnostic attempts based on the task terminology.
        # This package documents none of them; argparse captures the rejection.
        initial_args = [*common, "--preset", "team-research", "--enforcement", "block"]
        if actions is not None:
            initial_args += ["--external-actions", actions]
        initial_attempt = run(INITIALIZER, initial_args, case_evidence, "01-team-research-attempt")
        assert initial_attempt["exit_code"] == 2
        assert not list(project.iterdir()), "Rejected creation unexpectedly wrote files"

        baseline = run(INITIALIZER, common, case_evidence, "02-baseline-initialize")
        assert baseline["exit_code"] == 0
        generated = ["agents.md", "discoveries.md", "handoff.md", "plan.md"]
        assert sorted(p.name for p in project.iterdir()) == sorted(generated)
        # Read the generated coordination files in the skill's prescribed order.
        for filename in generated:
            (project / filename).read_text(encoding="utf-8")
        start_check = run(CHECKER, [str(project)], case_evidence, "03-start-check")
        assert start_check["exit_code"] == 0

        agents_path = project / "agents.md"
        initial_text = agents_path.read_text(encoding="utf-8")
        (case_evidence / "agents-before.md").write_bytes(agents_path.read_bytes())
        legacy = {"applicable": name == "legacy", "marker_present": False, "removed": False}
        if name == "legacy":
            markers = re.findall(r"<!--.*?-->", initial_text, re.S)
            legacy["marker_present"] = bool(markers)
            legacy["reason"] = (
                "No template marker or external_actions_source token exists; conditional removal is a no-op"
            )
            assert not markers and "external_actions_source=" not in initial_text
        write_json(case_evidence / "legacy-marker-operation.json", legacy)
        before_hashes = {filename: digest(project / filename) for filename in generated}

        reconfiguration = run(
            INITIALIZER,
            [str(project), "--reconfigure", "--preset", "competition-team",
             "--competition-hub", "review-trial", "--phase-clock", "off",
             "--enforcement", "block"],
            case_evidence, "04-competition-team-attempt",
        )
        assert reconfiguration["exit_code"] == 2
        after_hashes = {filename: digest(project / filename) for filename in generated}
        assert before_hashes == after_hashes, "Rejected reconfigure changed project files"
        final_text = agents_path.read_text(encoding="utf-8")
        (case_evidence / "agents-after.md").write_bytes(agents_path.read_bytes())
        actual_settings = settings(final_text)
        assert "External actions" not in actual_settings
        assert "Enforcement" not in actual_settings
        write_json(case_evidence / "resulting-settings.json", {
            "project_settings": actual_settings,
            "external_actions_setting": None,
            "external_actions_provenance": None,
            "enforcement_setting": None,
            "competition_hub_setting": None,
            "phase_clock_setting": None,
            "competition_identity_configured": False,
            "generated_file_hashes_before": before_hashes,
            "generated_file_hashes_after": after_hashes,
            "all_files_unchanged_by_reconfiguration_attempt": before_hashes == after_hashes,
        })

        command = "release-client publish artifact.txt" if name in {"custom", "opted-out"} else None
        hook_result = {
            "requested_stage": "pre-tool",
            "command_text": command,
            "command_selection": (
                "Exact matrix command, stored as data only" if command else
                "No configured adapter prefix exists; no applicable command can be selected"
            ),
            "hook_entrypoint": None,
            "evaluated": False,
            "decision": None,
            "exit_code": None,
            "status": "unavailable-missing-hook",
            "reason": "Supplied skill has no pre-tool hook implementation or hook configuration",
            "outward_command_executed": False,
            "gate_operational": False,
            "gate_status": "unsupported; neither an allow decision nor an explicit opt-out result",
        }
        write_json(case_evidence / "hook-evaluation.json", hook_result)
        final_check = run(CHECKER, [str(project)], case_evidence, "05-final-check")
        assert final_check["exit_code"] == 0
        results.append({
            "case": name,
            "requested": requested,
            "initial_attempt_exit": initial_attempt["exit_code"],
            "initial_attempt_error": initial_attempt["stderr"].splitlines()[-1],
            "baseline_initialization_exit": baseline["exit_code"],
            "reconfigure_attempt_exit": reconfiguration["exit_code"],
            "reconfigure_attempt_error": reconfiguration["stderr"].splitlines()[-1],
            "external_actions_actual": None,
            "hook": hook_result,
            "start_check_exit": start_check["exit_code"],
            "final_check_exit": final_check["exit_code"],
            "transition_completed": False,
        })
        print(f"{name}: preset init=2, baseline init=0, reconfigure=2, checks=0/0, hook unavailable")

    final_inventory = inventory()
    write_json(EVIDENCE / "skill-manifest-after.json", final_inventory)
    assert initial_inventory == final_inventory, "Skill files changed"
    write_json(EVIDENCE / "results.json", {
        "captured_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_executable": str(PYTHON),
        "skill_unchanged": initial_inventory == final_inventory,
        "outward_commands_executed": 0,
        "cases": results,
    })


if __name__ == "__main__":
    if Path(sys.executable).resolve() != PYTHON.resolve():
        raise SystemExit("Run with the user-provided Python executable")
    main()
