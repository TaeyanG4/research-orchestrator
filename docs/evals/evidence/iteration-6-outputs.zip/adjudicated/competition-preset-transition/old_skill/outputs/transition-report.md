# Local configuration transition report

The four requested `team-research` → `competition-team` transitions could not complete with the supplied skill package. Its initializer rejects the required options, and the package contains no pre-tool hook. Four real, initializer-generated **baseline-only** projects are preserved under `projects/`, alongside the actual failed-call output. No outward action was executed.

The skill implementation was left unchanged. All work used local files and `<host-path-1d5ebf570ab0>`. Captures were taken on 2026-10-26; the exact UTC timestamp is in [results.json](evidence/results.json).

The intended fixture competition identity `local-transition-eval` is recorded in the request metadata, but could not be configured by this initializer. No external credentials were configured.

## What this skill supports

I read the supplied [SKILL.md](../skill/SKILL.md) first, then inspected the initializer, its help, templates, and package inventory. The package contains nine files, including only two executable scripts: `scripts/init_research_orchestrator.py` and `scripts/check_project.py`. It has no hook implementation, hook registration, adapters, or template provenance marker.

The initializer's settings cover platform mode, platforms, git sync, collector, queue limits, reviewer, and cross-check fallback. It has no options/settings for presets, External actions, Competition hub, Phase clock, Enforcement, or a competition identity. See the captured [initializer help](evidence/initializer-help.stdout.txt) and [capability audit](evidence/capability-audit.json).

For reproducible diagnostic calls, the unsupported options were spelled `--preset`, `--enforcement`, `--competition-hub`, and `--phase-clock`, following the task terminology. This package documents none of those options. `--external-actions` was used exactly as specified in the matrix. These calls demonstrate parser rejection; they are not documented working invocations.

## Four cases and resulting settings

| Project | Initial choice retained in request record | Actual External actions setting after attempt | Provenance | Transition completed |
| --- | --- | --- | --- | --- |
| [inherited](projects/inherited/agents.md) | Omit `--external-actions` | Absent | Absent | No |
| [custom](projects/custom/agents.md) | Explicit `release-client publish; delivery-tool send` | Absent | Absent | No |
| [opted-out](projects/opted-out/agents.md) | Explicit `none` | Absent | Absent | No |
| [legacy](projects/legacy/agents.md) | Omit `--external-actions`; conditionally remove provenance token | Absent | Absent | No |

The exact omitted/custom/`none` distinctions are preserved in each `evidence/<case>/requested.json`, including whether the option was present. The initializer never accepted these settings, so preservation in generated `agents.md` cannot be established. An absent setting must not be interpreted as an accepted explicit `none`.

The initial preset calls failed before writing any project files. To leave useful generated projects, I then invoked the same unmodified initializer with its supported options: slot `A`, synthetic fixture user `local-eval`, platform mode `adaptive`, platforms `Claude Code, Codex`, git `off`, collector `off`, queue limits `50,5`, reviewer `off`, and fallback `same-host`. These are baseline fixtures; their names explicitly say `baseline only`.

All four resulting Project settings blocks contain exactly:

```text
- Platform mode: adaptive
- Platforms: Claude Code, Codex
- Git sync: off
- Plan collector: off
- Plan queue limits: stop at 50, resume at 5
- Reviewer: off
- Cross-check fallback: same-host
```

Each project contains the initializer's four files: `agents.md`, `plan.md`, `discoveries.md`, and `handoff.md`. The subsequent competition reconfiguration attempt failed during argument parsing and left all four files byte-for-byte unchanged. Before/after snapshots and SHA-256 values are saved per case.

For `legacy`, the generated baseline has no template marker and no `external_actions_source=...` token. The matrix's conditional removal was therefore a no-op; no other text was removed. See [legacy-marker-operation.json](evidence/legacy/legacy-marker-operation.json). Legacy migration semantics remain untested because the requested initial preset could not be created.

## Actual initializer output

Every case produced the following exit codes:

| Case | Requested preset initialization | Supported baseline initialization | Competition reconfiguration | Start/final consistency checks |
| --- | --- | --- | --- | --- |
| inherited | 2 | 0 | 2 | 0 / 0 |
| custom | 2 | 0 | 2 | 0 / 0 |
| opted-out | 2 | 0 | 2 | 0 / 0 |
| legacy | 2 | 0 | 2 | 0 / 0 |

The actual final stderr line for the `inherited` and `legacy` initialization calls was:

```text
init_research_orchestrator.py: error: unrecognized arguments: --preset team-research --enforcement block
```

For `custom`:

```text
init_research_orchestrator.py: error: unrecognized arguments: --preset team-research --enforcement block --external-actions release-client publish; delivery-tool send
```

For `opted-out`:

```text
init_research_orchestrator.py: error: unrecognized arguments: --preset team-research --enforcement block --external-actions none
```

All four competition reconfiguration calls ended with:

```text
init_research_orchestrator.py: error: unrecognized arguments: --preset competition-team --competition-hub review-trial --phase-clock off --enforcement block
```

Each successful baseline creation printed four `[CREATE]` lines with the full paths, followed by these actual lines:

```text
Done. Created 4 file(s). Existing files were preserved.
Settings: platform mode adaptive; platforms Claude Code, Codex; git sync off; plan collector off (stop at 50, resume at 5); reviewer off; cross-check fallback same-host; user local-eval
```

Complete stdout/stderr and argument arrays, including usage text and absolute file paths, are preserved for every invocation:

| Case | Requested initialization stderr | Baseline creation stdout | Reconfiguration stderr | Resulting settings | Hook evaluation record |
| --- | --- | --- | --- | --- | --- |
| inherited | [capture](evidence/inherited/01-team-research-attempt.stderr.txt) | [capture](evidence/inherited/02-baseline-initialize.stdout.txt) | [capture](evidence/inherited/04-competition-team-attempt.stderr.txt) | [JSON](evidence/inherited/resulting-settings.json) | [JSON](evidence/inherited/hook-evaluation.json) |
| custom | [capture](evidence/custom/01-team-research-attempt.stderr.txt) | [capture](evidence/custom/02-baseline-initialize.stdout.txt) | [capture](evidence/custom/04-competition-team-attempt.stderr.txt) | [JSON](evidence/custom/resulting-settings.json) | [JSON](evidence/custom/hook-evaluation.json) |
| opted-out | [capture](evidence/opted-out/01-team-research-attempt.stderr.txt) | [capture](evidence/opted-out/02-baseline-initialize.stdout.txt) | [capture](evidence/opted-out/04-competition-team-attempt.stderr.txt) | [JSON](evidence/opted-out/resulting-settings.json) | [JSON](evidence/opted-out/hook-evaluation.json) |
| legacy | [capture](evidence/legacy/01-team-research-attempt.stderr.txt) | [capture](evidence/legacy/02-baseline-initialize.stdout.txt) | [capture](evidence/legacy/04-competition-team-attempt.stderr.txt) | [JSON](evidence/legacy/resulting-settings.json) | [JSON](evidence/legacy/hook-evaluation.json) |

Each capture stem also has a `.json` file with the exact `argv`, working directory, stdout, stderr, and exit code, and separate raw `.stdout.txt` and `.stderr.txt` files.

## Hook evaluation and gate activity

No pre-tool evaluation could run: this supplied skill has no hook path. The hook records explicitly contain `evaluated: false`, `decision: null`, and `exit_code: null`. They record an unavailable evaluation, not a hook response.

| Case | Probe input | Is the External actions gate active? |
| --- | --- | --- |
| inherited | No command could be selected: no configured adapter prefix exists | No operational gate is installed; inherited-default behavior cannot be assessed |
| custom | `release-client publish artifact.txt`, retained as data only | No operational gate is installed; preservation and matching of the custom commands cannot be assessed |
| opted-out | `release-client publish artifact.txt`, retained as data only | No operational gate is installed; this does not demonstrate an accepted explicit opt-out |
| legacy | No configured adapter prefix exists | No operational gate is installed; legacy fallback behavior cannot be assessed |

`Enforcement block` could not be configured or retained. `Competition hub/review-trial` is unavailable. The requested `Phase clock off` could not be configured; the absence of a phase clock implementation does not establish successful application of that setting. There is no allow/block decision to report for any case.

The harness executed only the supplied initializer and checker through Python, with `shell=False`. The custom semicolon-separated value was passed as one argument. Outward command text was never executed. No artifact publication, delivery, git synchronization, credential setup, or network request occurred.

## Verification and artifacts

All eight consistency checks passed with the actual output:

```text
CONSISTENCY: OK (0 plan items, 0 discoveries, 0 events, agents A)
```

Those checks verify baseline coordination-file consistency; they do not validate any competition or outward-action gate. The generated fixture slots remain unassigned because no research session was started inside them.

The [before](evidence/skill-manifest-before.json) and [after](evidence/skill-manifest-after.json) SHA-256 manifests match for all nine supplied skill files. Per-case `resulting-settings.json` records verify that the failed reconfiguration changed none of the four generated files. [results.json](evidence/results.json) contains the combined machine-readable results. [run_transitions.py](run_transitions.py) is the local capture harness; it refuses to overwrite existing project/evidence directories.

Completing the requested transitions and actual harmless hook probes requires a local skill package that includes the competition presets, External actions provenance/settings, and the pre-tool hook. The current package cannot establish the requested gate behavior.
