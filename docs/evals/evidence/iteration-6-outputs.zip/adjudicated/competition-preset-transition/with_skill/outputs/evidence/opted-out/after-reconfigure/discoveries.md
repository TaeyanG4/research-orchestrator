# opted-out — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `cross-host-once`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-B-001 — Short title
- Source: B
- Host: Codex
- User: lee
- Date: 2026-10-05
- Cross-check: VERIFIED
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
  - Claude Code (A): CLOSED — reproduced independently with ...
```
