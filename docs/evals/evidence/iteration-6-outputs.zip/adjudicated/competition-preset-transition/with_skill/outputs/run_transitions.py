"""Reproduce the local transition matrix without executing probe commands."""

from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
SKILL = ROOT.parent / "skill"
PYTHON = Path(r"<host-path-1d5ebf570ab0>")
FILES = ("agents.md", "plan.md", "discoveries.md", "handoff.md")
CASES = {
    "inherited": None,
    "custom": "release-client publish; delivery-tool send",
    "opted-out": "none",
    "legacy": None,
}
ENV = dict(os.environ, PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1",
           RO_HOOK_PYTHON=str(PYTHON), RO_HOOK_DIAGNOSTICS="1")
for credential in ("KAGGLE_USERNAME", "KAGGLE_KEY", "KAGGLE_API_TOKEN"):
    ENV.pop(credential, None)


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def skill_hashes() -> dict[str, str]:
    return {
        path.relative_to(SKILL).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(SKILL.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
        and ".git" not in path.parts and path.suffix != ".pyc"
    }


def capture(evidence: Path, label: str, script: str, args: list[str],
            cwd: Path, payload: dict | None = None) -> subprocess.CompletedProcess:
    # Only these installed, local entry points may be started. Probe text is stdin data.
    if script not in {"init_research_orchestrator.py", "check_project.py", "ro_hook_runner.py"}:
        raise ValueError("Unapproved executable entry point")
    argv = [str(PYTHON), "-S", str(SKILL / "scripts" / script), *args]
    stdin = None
    if payload is not None:
        stdin = (json.dumps(payload) + "\n").encode("utf-8")
        (evidence / f"{label}.input.json").write_bytes(stdin)
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, env=ENV, input=stdin,
                            capture_output=True, shell=False, timeout=30)
    (evidence / f"{label}.stdout.txt").write_bytes(result.stdout)
    (evidence / f"{label}.stderr.txt").write_bytes(result.stderr)
    write_json(evidence / f"{label}.invocation.json", {
        "argv": argv, "cwd": str(cwd), "shell": False,
        "started_utc": started, "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "returncode": result.returncode,
        "stdin_file": f"{label}.input.json" if payload is not None else None,
    })
    if result.returncode:
        raise RuntimeError(f"{label} failed ({result.returncode}): {result.stderr.decode('utf-8')}")
    return result


def snapshot(project: Path, destination: Path) -> None:
    destination.mkdir()
    for name in FILES:
        shutil.copyfile(project / name, destination / name)


def settings(path: Path) -> dict[str, str | None]:
    text = path.read_text(encoding="utf-8")
    result = {}
    for label in ("Preset", "Profile", "Workflow", "Verification", "Enforcement", "Block",
                  "External actions", "Competition", "Phase clock", "Language", "Environment"):
        matches = re.findall(rf"^- {re.escape(label)}: (.*)$", text, re.M)
        if len(matches) != 1:
            raise ValueError(f"Expected exactly one {label} setting in {path}")
        result[label] = matches[0]
    marker = re.search(r"<!-- ro-template: .*? -->", text)
    result["template_marker"] = marker[0] if marker else None
    provenance = re.search(r"\bexternal_actions_source=([^\s)]+)", marker[0]) if marker else None
    result["external_actions_source"] = provenance[1] if provenance else None
    return result


def record_result(project: Path, case: str, result: dict, finding: str) -> None:
    now = dt.datetime.now()
    discovery = (
        f"\n## D-A-001 — {case} External actions transition\n"
        "- Source: A\n- Host: Codex\n- User: <private-host>\n"
        f"- Date: {now:%Y-%m-%d}\n- Session: codex:transition-{case}@{now:%Y-%m-%dT%H:%M}\n"
        "- Cross-check: PENDING\n"
        f"- Finding: {finding}\n"
        f"- Evidence: ../../evidence/{case}/result.json; initializer transcripts, snapshots, "
        "hook input/output, and diagnostics are in that directory.\n"
        "- Implication: Preserve explicit choices and legacy policy; only inherited defaults follow the profile. "
        "No further experiment is needed for this requested matrix.\n- Review<host-path-cc8f364f3b6c>"
    )
    discoveries_path = project / "discoveries.md"
    discoveries = discoveries_path.read_text(encoding="utf-8")
    discoveries_path.write_text(discoveries.rstrip() + "\n" + discovery, encoding="utf-8", newline="\n")
    event = (
        f"\n### {now:%Y-%m-%d %H:%M} — A — none\n"
        "- Host: Codex\n- User: <private-host>\n"
        "- Action: Reconfigured team-research to competition-team with Competition hub/review-trial, "
        "Phase clock off, and Enforcement block; evaluated command text through PreToolUse only.\n"
        "- Result: Local transition and hook evaluation completed; see D-A-001. "
        "Independent review unavailable in this session; review remains PENDING.\n"
        f"- Artifacts: ../../evidence/{case}/\n"
        "- Discovery updates: D-A-001\n- Review verdict: none\n- Resource: CPU\n"
        "- Other executor: none\n"
        "- New plan items: none - all four requested transitions are covered by the matrix; "
        "no outward action was executed.\n"
    )
    handoff_path = project / "handoff.md"
    handoff = handoff_path.read_text(encoding="utf-8")
    if "## Completed / review log" not in handoff and "## Completed/review log" not in handoff:
        raise ValueError("Inspect the generated handoff before appending an event")
    before_archive, separator, archive = handoff.partition("## Archived history")
    assert separator
    handoff_path.write_text(before_archive.rstrip() + "\n" + event + "\n" + separator + archive,
                            encoding="utf-8", newline="\n")


def main() -> None:
    if sys.executable.lower() != str(PYTHON).lower():
        raise RuntimeError("Run with the user-specified Python executable")
    if ((ROOT / "projects").exists() and any((ROOT / "projects").iterdir())) or (ROOT / "evidence").exists():
        raise RuntimeError("Refusing to overwrite existing projects/evidence; preserve this run first")
    (ROOT / "projects").mkdir(exist_ok=True)
    (ROOT / "evidence").mkdir()
    before_hashes = skill_hashes()
    write_json(ROOT / "evidence" / "skill-before.sha256.json", before_hashes)
    adapter = json.loads((SKILL / "references" / "adapters" / "external-actions.json").read_text(encoding="utf-8"))
    summary = []
    for case, explicit in CASES.items():
        project = ROOT / "projects" / case
        evidence = ROOT / "evidence" / case
        project.mkdir()
        evidence.mkdir()
        initial_args = [str(project), "--name", case, "--preset", "team-research", "--user", "<private-host>",
                        "--agents", "A,B", "--platforms", "Claude Code, Codex", "--language", "en",
                        "--environment", "windows/powershell", "--git", "off", "--enforcement", "block"]
        if explicit is not None:
            initial_args += ["--external-actions", explicit]
        capture(evidence, "01-initialize", "init_research_orchestrator.py", initial_args, ROOT)
        snapshot(project, evidence / "initial")
        initial_settings = settings(project / "agents.md")
        if case == "legacy":
            path = project / "agents.md"
            old = path.read_text(encoding="utf-8")
            marker = re.search(r"<!-- ro-template: .*? -->", old)
            assert marker
            new_marker, count = re.subn(r" external_actions_source=[^\s)]+", "", marker[0])
            assert count == 1
            changed = old[:marker.start()] + new_marker + old[marker.end():]
            assert old.replace(" external_actions_source=default", "", 1) == changed
            path.write_text(changed, encoding="utf-8", newline="\n")
            (evidence / "legacy-marker-only.diff").write_text(
                "".join(difflib.unified_diff(old.splitlines(True), changed.splitlines(True),
                                             fromfile="initial/agents.md", tofile="before-reconfigure/agents.md")),
                encoding="utf-8")
        snapshot(project, evidence / "before-reconfigure")
        before_settings = settings(project / "agents.md")
        capture(evidence, "02-check-before", "check_project.py", [str(project)], ROOT)
        capture(evidence, "03-reconfigure", "init_research_orchestrator.py",
                [str(project), "--reconfigure", "--preset", "competition-team", "--competition", "hub/review-trial",
                 "--phase-clock", "off", "--enforcement", "block"], ROOT)
        snapshot(project, evidence / "after-reconfigure")
        after_settings = settings(project / "agents.md")
        for label, expected in {"Preset": "competition-team", "Profile": "competition", "Workflow": "classic",
                                "Enforcement": "block", "Competition": "hub/review-trial", "Phase clock": "off"}.items():
            assert after_settings[label] == expected, (case, label, after_settings[label])
        assert "external.gate" in after_settings["Block"].split(", ")
        if case in ("inherited", "legacy"):
            command = adapter[0] + " -c review-trial -f artifact.txt -m local-probe"
        else:
            command = "release-client publish artifact.txt"
<withheld internal metadata>
                   "tool_name": "PowerShell", "tool_input": {"command": command, "workdir": str(project)}}
        probe = capture(evidence, "04-hook", "ro_hook_runner.py", ["PreToolUse"], project, payload)
        hook = json.loads(probe.stdout)
        assert "hooks.failure" not in probe.stdout.decode("utf-8")
        assert "hooks inactive" not in probe.stdout.decode("utf-8")
        diagnostics = project / ".ro" / "hook-diagnostics.jsonl"
        assert diagnostics.is_file(), "The supplied hook runner must actually run"
        shutil.copyfile(diagnostics, evidence / "04-hook.diagnostics.jsonl")
        output = hook.get("hookSpecificOutput", {})
        decision = output.get("permissionDecision")
        active = (after_settings["External actions"] != "none"
                  and after_settings["Enforcement"] == "block"
                  and "external.gate" in after_settings["Block"].split(", "))
        expected_external = "; ".join(adapter) if case == "inherited" else explicit or "none"
        assert after_settings["External actions"] == expected_external
        initial_rules = (evidence / "before-reconfigure" / "agents.md").read_text(encoding="utf-8").partition("## Project rules")[2]
        final_rules = (project / "agents.md").read_text(encoding="utf-8").partition("## Project rules")[2]
        assert initial_rules == final_rules, "User-owned project rules must be preserved"
        if active:
            assert decision == "deny" and "external.gate:" in output["permissionDecisionReason"]
        else:
            assert hook == {}, hook
        result = {"case": case, "initial_external_actions_flag": explicit,
                  "initial": initial_settings, "before_reconfigure": before_settings,
                  "after_reconfigure": after_settings, "probe_command_text": command,
                  "hook_response": hook, "hook_process_returncode": probe.returncode,
                  "gate_configured_active": active,
                  "probe_command_executed": False, "independent_review": "PENDING"}
        write_json(evidence / "result.json", result)
        finding = (f"External actions changed from {before_settings['External actions']!r} to "
                   f"{after_settings['External actions']!r}; the supplied PreToolUse runner "
                   + ("denied the matching direct outward command via external.gate."
                      if decision == "deny" else "returned {} with no hook decision; external.gate is inactive without patterns."))
        record_result(project, case, result, finding)
        capture(evidence, "05-check-final", "check_project.py", [str(project)], ROOT)
        summary.append(result)
        print(json.dumps({"case": case, "External actions": after_settings["External actions"],
                          "source": after_settings["external_actions_source"], "gate_active": active,
                          "hook_decision": decision or "no hook decision"}), flush=True)
    write_json(ROOT / "evidence" / "results.json", summary)
    after_hashes = skill_hashes()
    write_json(ROOT / "evidence" / "skill-after.sha256.json", after_hashes)
    write_json(ROOT / "evidence" / "skill-integrity.json", {
        "algorithm": "sha256", "excluded": ["__pycache__", ".pyc", ".git"],
        "files_before": len(before_hashes), "files_after": len(after_hashes),
        "identical": before_hashes == after_hashes,
    })
    assert before_hashes == after_hashes, "Installed skill files changed"


if __name__ == "__main__":
    main()
