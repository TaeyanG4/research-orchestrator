# inherited — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `cross-host-once`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-B-001 — Short title
- Source: B
- Host: Codex
- User: lee
- Date: 2026-10-05
- Cross-check: VERIFIED
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
  - Claude Code (A): CLOSED — reproduced independently with ...
```

## D-A-001 — inherited External actions transition
- Source: A
- Host: Codex
- User: <private-host>
- Date: 2026-10-26
- Session: codex:transition-inherited@2026-10-26T14:07
- Cross-check: PENDING
- Finding: External actions changed from 'none' to 'kaggle competitions submit; kaggle kernels push'; the supplied PreToolUse runner denied the matching direct outward command via external.gate.
- Evidence: ../../evidence/inherited/result.json; initializer transcripts, snapshots, hook input/output, and diagnostics are in that directory.
- Implication: Preserve explicit choices and legacy policy; only inherited defaults follow the profile. No further experiment is needed for this requested matrix.
- Reviews:
