# opted-out — Plan

Active unfinished plan items only. Read `<skill-root>/references/plan-items.md` for item format, duplicate checks and priority; `<skill-root>/SKILL.md` for the item lifecycle; and `<skill-root>/references/workflow-classic.md` for ownership.


Each slot keeps its items in its own `## Agent: <name>` section. Item format:

```markdown
### H-A-01 — Short title
- Sources: D-B-001, D-A-004 / none
- Hypothesis: ...
- Evidence: ...
- Improvement: ...
- Impact: 0-3
- Information: 0-3
- Confidence: 0-3
- Unblock: 0-3
- Diversity: 0-3
- Cost: 0-3
- Priority: ...
- Resource: CPU | GPU | EITHER
- Parallel: YES | NO
- Other: NONE | <external executor>
- Next test: ...
```

## Agent: A

_No active items yet. Add only actionable unfinished work._

_Use the item shape above for this project's profile._

## Agent: B

_No active items yet. Add only actionable unfinished work._

_Use the item shape above for this project's profile._

