# Local configuration transition report

All four disposable projects were initialized with `team-research` and reconfigured with `competition-team`, `Competition: hub/review-trial`, `Phase clock: off`, and `Enforcement: block`. The supplied initializer and pre-tool hook runner were used unchanged. No outward command ran, no external credentials were configured, and no network access was used.

| Project | Initial External actions | Provenance before → after | Resulting External actions | External gate | Actual PreToolUse response |
| --- | --- | --- | --- | --- | --- |
| [inherited](projects/inherited/agents.md) | `none`; flag omitted | `default` → `default` | `kaggle competitions submit; kaggle kernels push` | Active for configured prefixes | `deny` via `external.gate` |
| [custom](projects/custom/agents.md) | Explicit `release-client publish; delivery-tool send` | `explicit` → `explicit` | `release-client publish; delivery-tool send` | Active for configured prefixes | `deny` via `external.gate` |
| [opted-out](projects/opted-out/agents.md) | Explicit `none` | `explicit` → `explicit` | `none` | Inactive: no command patterns | `{}`; no hook decision |
| [legacy](projects/legacy/agents.md) | `none`; flag omitted, then provenance removed | absent → absent | `none` | Inactive: no command patterns | `{}`; no hook decision |

The inherited default follows the change from research to competition. Both custom prefixes and the explicit opt-out survive without repeating `--external-actions` during reconfiguration. The legacy file keeps its stored value because absent provenance does not establish that it was an inherited default. Only ` external_actions_source=default` was removed from its generated template marker; the [exact diff](evidence/legacy/legacy-marker-only.diff) and complete snapshots preserve that change.

Every resulting project has this blocking policy:

```text
Enforcement: block
Block: shell.background, shell.heredoc, jobs.mutate-bound, publish.scan, external.gate
Competition: hub/review-trial
Phase clock: off
```

`external.gate` needs matching External actions patterns as well as blocking enforcement and its ID in `Block`. Listing the ID alone leaves the opted-out and legacy external gates inactive. Phase clock controls phase milestones; turning it off does not disable the external gate. These observations concern `external.gate`; the other listed checks were not exercised by this matrix.

The inherited commands are the actual defaults loaded from the skill's [local adapter file](../skill/references/adapters/external-actions.json), even with the generic `hub/review-trial` identity. No hub-specific outward prefix was invented.

## Reproduction and execution boundary

The recorded user is `<private-host>`, inferred from the supplied Python path. All projects use English, `windows/powershell`, slots `A,B`, platforms `Claude Code, Codex`, and Git sync off. Creating two slots does not launch worker agents.

The [local runner](run_transitions.py) used the supplied executable:

```text
<host-path-1d5ebf570ab0>
```

Each initial invocation used the skill's `scripts/init_research_orchestrator.py` with these arguments, substituting the project path and name:

```text
<project> --name <name> --preset team-research --user <private-host> --agents A,B
--platforms "Claude Code, Codex" --language en --environment windows/powershell
--git off --enforcement block
```

The custom case additionally supplied `--external-actions "release-client publish; delivery-tool send"`; the opted-out case supplied `--external-actions none`. The inherited and legacy cases omitted that flag. After initialization, the legacy marker edit described above was applied only to its project file.

Every reconfiguration used:

```text
<project> --reconfigure --preset competition-team --competition hub/review-trial
--phase-clock off --enforcement block
```

`--external-actions` was omitted for all four reconfigurations, so the transitions exercise stored-choice preservation. Both presets use the classic workflow, so no workflow migration or `--force` was needed. The user-owned `## Project rules` regions were checked and remained byte-for-byte equivalent as UTF-8 text.

For each probe, the runner started only:

```text
<python> -S <skill>/scripts/ro_hook_runner.py PreToolUse
```

It set the working directory to that generated project and provided a JSON payload on stdin with `tool_name: PowerShell`, the project `cwd`, slot `A`, a distinct local session ID, and `tool_input.command` containing the following text:

| Project | Evaluated command text |
| --- | --- |
| inherited | `kaggle competitions submit -c review-trial -f artifact.txt -m local-probe` |
| custom | `release-client publish artifact.txt` |
| opted-out | `release-client publish artifact.txt` |
| legacy | `kaggle competitions submit -c review-trial -f artifact.txt -m local-probe` |

The hook runner invoked its installed `ro.py hook PreToolUse` child. Probe command text remained JSON data: it was never supplied to a shell or an external-action execution wrapper. `artifact.txt` is only a command argument in the probe; no publication artifact or executable was needed. The custom probe exercised its first prefix; both stored prefixes were checked for preservation.

## Captured initializer output and hook evidence

These are raw stdout captures from the actual initializer runs. Each adjacent `.stderr.txt` captures stderr, and each `.invocation.json` records the exact argument array, working directory, timestamps, and return code. All eight successful initializer invocations returned zero; their stderr files were empty.

| Project | Initializer stdout | Reconfiguration stdout | Hook input | Hook stdout | Hook diagnostics |
| --- | --- | --- | --- | --- | --- |
| inherited | [initialize](evidence/inherited/01-initialize.stdout.txt) | [reconfigure](evidence/inherited/03-reconfigure.stdout.txt) | [JSON](evidence/inherited/04-hook.input.json) | [JSON](evidence/inherited/04-hook.stdout.txt) | [JSONL](evidence/inherited/04-hook.diagnostics.jsonl) |
| custom | [initialize](evidence/custom/01-initialize.stdout.txt) | [reconfigure](evidence/custom/03-reconfigure.stdout.txt) | [JSON](evidence/custom/04-hook.input.json) | [JSON](evidence/custom/04-hook.stdout.txt) | [JSONL](evidence/custom/04-hook.diagnostics.jsonl) |
| opted-out | [initialize](evidence/opted-out/01-initialize.stdout.txt) | [reconfigure](evidence/opted-out/03-reconfigure.stdout.txt) | [JSON](evidence/opted-out/04-hook.input.json) | [JSON](evidence/opted-out/04-hook.stdout.txt) | [JSONL](evidence/opted-out/04-hook.diagnostics.jsonl) |
| legacy | [initialize](evidence/legacy/01-initialize.stdout.txt) | [reconfigure](evidence/legacy/03-reconfigure.stdout.txt) | [JSON](evidence/legacy/04-hook.input.json) | [JSON](evidence/legacy/04-hook.stdout.txt) | [JSONL](evidence/legacy/04-hook.diagnostics.jsonl) |

For both active gates, the exact hook response was:

```json
{"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny", "permissionDecisionReason": "external.gate: Run this action through ro external with a current PASS receipt and prepared ledger entry."}}
```

For both inactive gates, the exact response was `{}`. All four hook processes returned zero: the PreToolUse deny is conveyed by `permissionDecision`, not a failing process exit code. Diagnostics recorded `external.gate` / `denied` for inherited and custom, and `no hook decision` with no checks for opted-out and legacy. No hook failure or inactive-hook diagnostic occurred.

The opted-out and legacy initializer outputs both explicitly included:

```text
external gate inactive: no command patterns (configure --external-actions to enable)
```

These are direct evaluations through the supplied hook path. They establish configured matching and hook decisions for the tested text; they do not establish automatic interception by the current Codex host. The skill's [hook reference](../skill/references/hooks.md) documents that host coverage limitation and per-call fail-open behavior. An empty response is therefore reported as no hook decision, rather than authorization to publish.

## Validation and preserved artifacts

| Project | Checker before transition | Checker after transition and records |
| --- | --- | --- |
| inherited | [OK](evidence/inherited/02-check-before.stdout.txt) | [OK](evidence/inherited/05-check-final.stdout.txt) |
| custom | [OK](evidence/custom/02-check-before.stdout.txt) | [OK](evidence/custom/05-check-final.stdout.txt) |
| opted-out | [OK](evidence/opted-out/02-check-before.stdout.txt) | [OK](evidence/opted-out/05-check-final.stdout.txt) |
| legacy | [OK](evidence/legacy/02-check-before.stdout.txt) | [OK](evidence/legacy/05-check-final.stdout.txt) |

All eight checker runs returned zero with no WARN or ERROR findings. Each final project has one discovery and a settings-change event. Final checker information consists of the pending independent review and the first direction review due 2026-11-02. No independent review was claimed or fabricated; discoveries remain `PENDING` under the resulting hybrid verification policy.

For each case, `evidence/<case>/initial/`, `before-reconfigure/`, and `after-reconfigure/` contain the four coordination files at those stages. The live projects retain the resulting settings plus the discovery and handoff event. [Machine-readable results](evidence/results.json) include settings, provenance, command text, and the actual hook responses. [Skill integrity evidence](evidence/skill-integrity.json) confirms that all 53 non-cache skill files had identical SHA-256 hashes before and after the run; both complete hash manifests are preserved beside it.

The first setup attempt reported that the target directory did not exist. Its [stderr](setup-attempt-01/inherited/01-initialize.stderr.txt) and invocation were retained. The local runner was corrected to create the disposable directories before invoking the initializer; this required no skill implementation change. No generated project was overwritten or removed.
