# Literal command arguments — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `independent-review`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-A-001 — Short title
- Source: A
- Host: Claude Code
- User: kim
- Date: 2026-10-05
- Session: claude-code:A@2026-10-05T14:10
- Cross-check: VERIFIED
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
  - Claude Code (A): CLOSED — reviewer subagent:fable@2026-10-05T15:02 — reproduced independently with ...
```

## D-A-001 — Literal hook data and hook subcommand
- Source: A
- Host: Codex
- User: Lee
- Date: 2026-10-26
- Session: codex:hook@2026-10-26T13:58
- Cross-check: PENDING
- Finding: In the installed CLI paths tested locally, hook works as the project directory, explicit session identifier, dupcheck search term, Adapter observation value, and separate child argument; the actual hook PreToolUse subcommand returns empty JSON for the harmless payload.
- Evidence: ../command-results.json, especially dupcheck-hook-with-record, observe-adapter-hook-confirm, launch-owned-child, monitor-owned-child, and actual-hook-pretooluse; ../pretooluse-payload.json; runs/literal/argument.txt; .ro/jobs.json. These requested command invocations exited 0, and J-A-0001 exited 0 with a recorded monitor outcome. Earlier setup invocation errors and retries are retained in the command log.
- Implication: The tested ordinary data and actual subcommand are distinguished. No follow-up is needed for the requested local check.
- Reviews:
