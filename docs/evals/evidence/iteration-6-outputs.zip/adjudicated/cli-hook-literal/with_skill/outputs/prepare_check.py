"""Prepare the requested compact item and local owned-job directory."""
from pathlib import Path

root = Path(__file__).resolve().parent
project = root / "hook"
plan = project / "plan.md"
text = plan.read_text(encoding="utf-8")
start = text.index("```markdown")
end = text.index("```", start + 3) + 3
text = text[:start] + text[end:]
placeholder = "_No items yet. Add only actionable unfinished work; every item starts with `- Claimed: none`._"
assert placeholder in text
item = """### H-A-01 — Literal hook handling
- Claimed: none
- Goal: Check hook literal handling in local commands
- Evidence: ../brief.md specifies the local check using ../echo_argument.py.
- Next test: Search hook, record Adapter hook, launch a child with separate argument hook, monitor completion, and exercise hook PreToolUse.
"""
plan.write_text(text.replace(placeholder, item), encoding="utf-8")
handoff = project / "handoff.md"
text = handoff.read_text(encoding="utf-8")
text = text.replace("- Current host: unassigned", "- Current host: Codex")
text = text.replace("- Current user: none", "- Current user: Lee")
text = text.replace("- Current thread: none yet", "- Current thread: H-A-01")
text = text.replace("- Resumable state: read discoveries, then the plan", "- Resumable state: session hook; H-A-01 queued; evidence in ../command-results.json")
text = text.replace("- Next action: choose the highest-priority item you may work on", "- Next action: execute H-A-01")
handoff.write_text(text, encoding="utf-8")
(project / "runs" / "literal").mkdir(parents=True, exist_ok=True)
assert plan.read_text(encoding="utf-8").count("### H-A-01") == 1
print(item)
print("Prepared slot A for Codex / Lee and runs/literal.")
