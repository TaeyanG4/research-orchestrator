"""Capture real subprocess invocations without interpreting their arguments."""
import argparse
import base64
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys


parser = argparse.ArgumentParser()
parser.add_argument("--cwd", default=".")
parser.add_argument("--stdin-file")
parser.add_argument("--label", required=True)
parser.add_argument("argv", nargs=argparse.REMAINDER)
args = parser.parse_args()
argv = args.argv[1:] if args.argv[:1] == ["--"] else args.argv
if not argv:
    parser.error("a command is required after --")
root = Path(__file__).resolve().parent
log_path = root / "command-results.json"
cwd = str(Path(args.cwd).resolve())
stdin_bytes = Path(args.stdin_file).read_bytes() if args.stdin_file else None
env = os.environ.copy()
env.update(PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run(
    argv, cwd=cwd, env=env, input=stdin_bytes,
    stdin=subprocess.DEVNULL if stdin_bytes is None else None,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
)
entry = {
    "label": args.label,
    "command": subprocess.list2cmdline(argv),
    "argv": argv,
    "cwd": cwd,
    "environment_overrides": {"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"},
    "stdin": stdin_bytes.decode("utf-8") if stdin_bytes is not None else None,
    "started_at_utc": started,
    "finished_at_utc": datetime.now(timezone.utc).isoformat(),
    "exit_code": result.returncode,
    "stdout": result.stdout.decode("utf-8", errors="replace"),
    "stderr": result.stderr.decode("utf-8", errors="replace"),
    "stdout_base64": base64.b64encode(result.stdout).decode("ascii"),
    "stderr_base64": base64.b64encode(result.stderr).decode("ascii"),
}
records = json.loads(log_path.read_text(encoding="utf-8")) if log_path.exists() else []
records.append(entry)
log_path.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: entry[key] for key in ("label", "exit_code", "stdout", "stderr")}, ensure_ascii=True, indent=2))
sys.exit(result.returncode)
