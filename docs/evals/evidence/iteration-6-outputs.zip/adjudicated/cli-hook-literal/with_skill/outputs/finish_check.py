"""Check saved execution evidence and finalize the coordinated item."""
import base64
from datetime import datetime
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
project = root / "hook"
records = json.loads((root / "command-results.json").read_text(encoding="utf-8"))
by_label = {entry["label"]: entry for entry in records}
required = (
    "initialize-retry", "project-start-check", "dupcheck-hook-with-record",
    "observe-adapter-hook-confirm", "claim-item-after-preparation",
    "launch-owned-child", "monitor-owned-child", "actual-hook-pretooluse",
)
for label in required:
    assert by_label[label]["exit_code"] == 0, label
assert "H-A-01" in by_label["dupcheck-hook-with-record"]["stdout"]
launch_argv = by_label["launch-owned-child"]["argv"]
child_argv = launch_argv[launch_argv.index("--") + 1:]
assert child_argv == [
    r"<host-path-1d5ebf570ab0>",
    str(root / "echo_argument.py"), "hook",
]
assert json.loads(by_label["actual-hook-pretooluse"]["stdout"]) == {}
argument_path = project / "runs" / "literal" / "argument.txt"
argument_bytes = argument_path.read_bytes()
assert argument_path.read_text(encoding="utf-8") == "hook\n"
jobs = json.loads((project / ".ro" / "jobs.json").read_text(encoding="utf-8"))
job = next(entry for entry in jobs if entry["id"] == "J-A-0001")
assert job["session"] == "hook" and job["slot"] == "A"
assert job["status"] == "finished" and job["child_exit_code"] == 0
assert job["outcome"] == "process exited with code 0"
assert not job["monitor"]["active"] and job["monitor"]["ended"]
assert all(entry["status"] != "running" for entry in jobs)
handoff_path = project / "handoff.md"
handoff = handoff_path.read_text(encoding="utf-8")
assert "- Adapter: hook (Observed at " in handoff
now = datetime.now().astimezone()
discovery_id = by_label["reserve-discovery-id"]["stdout"].strip()
assert discovery_id == "D-A-001"
discovery_path = project / "discoveries.md"
discoveries = discovery_path.read_text(encoding="utf-8")
discovery = f"""
## {discovery_id} — Literal hook data and hook subcommand
- Source: A
- Host: Codex
- User: Lee
- Date: {now:%Y-%m-%d}
- Session: codex:hook@{now:%Y-%m-%dT%H:%M}
- Cross-check: PENDING
- Finding: In the installed CLI paths tested locally, hook works as the project directory, explicit session identifier, dupcheck search term, Adapter observation value, and separate child argument; the actual hook PreToolUse subcommand returns empty JSON for the harmless payload.
- Evidence: ../command-results.json, especially dupcheck-hook-with-record, observe-adapter-hook-confirm, launch-owned-child, monitor-owned-child, and actual-hook-pretooluse; ../pretooluse-payload.json; runs/literal/argument.txt; .ro/jobs.json. These requested command invocations exited 0, and J-A-0001 exited 0 with a recorded monitor outcome. Earlier setup invocation errors and retries are retained in the command log.
- Implication: The tested ordinary data and actual subcommand are distinguished. No follow-up is needed for the requested local check.
- Reviews:
"""
discovery_path.write_text(discoveries.rstrip() + "\n" + discovery, encoding="utf-8")
event = f"""### {now:%Y-%m-%d %H:%M} — A — session
- Host: Codex
- User: Lee
- Action: Completed the installed-CLI local check in session hook and inspected the child result.
- Result: See {discovery_id}; requested check complete. Independent review was not performed in this single-session check; the finding remains PENDING.
- Artifacts: ../command-results.json; ../pretooluse-payload.json; runs/literal/argument.txt; .ro/jobs.json
- Discovery updates: {discovery_id}
- Job: J-A-0001; item H-A-01; outcome: process exited with code 0
- New plan items: none — all requested checks have evidence; no additional local test is needed
- Completed: H-A-01

"""
handoff = handoff.replace("- Current project state: initialized", "- Current project state: local check completed; see D-A-001")
handoff = handoff.replace("- Current thread: H-A-01", "- Current thread: none")
handoff = handoff.replace(
    "- Resumable state: session hook; H-A-01 queued; evidence in ../command-results.json",
    "- Resumable state: session hook; H-A-01 completed; no owned job running; evidence in ../command-results.json; D-A-001 review pending",
)
handoff = handoff.replace("- Next action: execute H-A-01", "- Next action: none — requested local check complete")
handoff = handoff.replace("## Archived history", event + "## Archived history", 1)
handoff_path.write_text(handoff, encoding="utf-8")
plan_path = project / "plan.md"
plan = plan_path.read_text(encoding="utf-8")
assert plan.count("### H-A-01") == 1
plan = plan[:plan.index("### H-A-01")] + "_No unfinished items._\n"
plan = plan.replace("Goal and Hypothesis are aliases. Item format:", "Goal and Hypothesis are aliases.")
plan_path.write_text(plan, encoding="utf-8")
print(json.dumps({
    "requested_checks": "PASS",
    "session": "hook",
    "item": "H-A-01",
    "job": "J-A-0001",
    "child_exit_code": job["child_exit_code"],
    "monitor_outcome": job["outcome"],
    "argument_path": str(argument_path.relative_to(root)),
    "argument_text": argument_path.read_text(encoding="utf-8"),
    "argument_bytes_base64": base64.b64encode(argument_bytes).decode("ascii"),
    "argument_sha256": hashlib.sha256(argument_bytes).hexdigest(),
    "actual_hook_stdout": by_label["actual-hook-pretooluse"]["stdout"],
    "discovery": discovery_id,
    "independent_review": "PENDING",
}, indent=2))
