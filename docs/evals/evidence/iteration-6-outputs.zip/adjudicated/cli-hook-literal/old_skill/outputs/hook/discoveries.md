# Literal command arguments — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `independent-review`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-A-001 — Short title
- Source: A
- Host: Claude Code
- User: kim
- Date: 2026-10-05
- Session: claude-code:A@2026-10-05T14:10
- Cross-check: VERIFIED
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
  - Claude Code (A): CLOSED — reviewer subagent:fable@2026-10-05T15:02 — reproduced independently with ...
```

## D-A-001 — Literal hook data and the hook subcommand both work
- Source: A
- Host: Codex
- User: Lee
- Date: 2026-10-26
- Session: hook
- Cross-check: PENDING
- Finding: The installed ro CLI accepted hook as the project directory, explicit session identifier, search term, observation value, and separate child argument; the actual hook PreToolUse subcommand also returned successfully for the harmless payload.
- Evidence: ../command-results.json records the exact commands, exit codes and outputs. dupcheck hook found H-A-01 and its Goal. Shared state records Adapter: hook. Owned job J-A-0001 in .ro/jobs.json has session hook, child exit code 0, and a recorded monitor outcome; runs/literal/argument.txt contains hook followed by one newline. The actual hook invocation read ../pretooluse-payload.json and returned {} with exit code 0.
- Implication: These exercised ordinary-data positions remain distinct from the actual hook subcommand. No additional local test is needed for this brief.
- Reviews:
