Saved payloads, responses, explanations, and lifecycle evidence in [rename-probes.json](<host-path-be51eab570b7>).

- Relative and absolute `runs` renames: **denied** by `jobs.mutate-bound`, because they would relocate the bound `runs/job-a`.
- `runs/job-b` rename: **no denial** (`{}`), because the sibling overlaps no binding.

All probes ran while the worker was live. No renames executed. All four inputs remain unchanged by SHA-256.

Worker `J-A-0001` was terminated; its final monitored outcome, `job process tree killed`, is recorded. Project checks passed with zero errors or warnings.