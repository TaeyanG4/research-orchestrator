"""Collect local hook evidence; command strings are JSON data, never shell code."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone


ROOT = Path(__file__).resolve().parent
SKILL = ROOT.parent / "skill"
PYTHON = Path(r"<host-path-1d5ebf570ab0>")
SESSION = os.environ.get("CODEX_THREAD_ID") or "codex:rename-protection@2026-10-26"
RO = [str(PYTHON), str(SKILL / "scripts" / "ro.py"), "--project", str(ROOT),
      "--slot", "A", "--session", SESSION]
sys.path.insert(0, str(SKILL / "scripts"))
from ro_jobs import live_monitor, monitor_outcome, running_job
from ro_state import same_process

INPUTS = ("brief.md", "worker.py", "runs/job-a/input.txt", "runs/job-b/input.txt")
OUTPUT = ROOT / "rename-probes.json"
FLAGS = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
report = {
<withheld internal metadata>
    "environment": "windows/powershell", "enforcement": "block",
    "block": ["jobs.mutate-bound"], "event": "PreToolUse",
    "scope": "Direct hook-adapter probes; no rename command is executed. This does not establish automatic Codex hook delivery.",
    "probes": [], "lifecycle": [],
}


def now():
    return datetime.now(timezone.utc).isoformat()


def save():
    OUTPUT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


def hashes():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in INPUTS}


def invoke(*args, payload=None, timeout=25):
    command = RO + list(args)
    started = now()
    result = subprocess.run(command, cwd=ROOT, input=None if payload is None else json.dumps(payload),
                            text=True, encoding="utf-8", capture_output=True, timeout=timeout,
                            creationflags=FLAGS)
    entry = {"argv": command, "started_utc": started, "ended_utc": now(),
             "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    report["lifecycle"].append(entry)
    save()
    if result.returncode:
        raise RuntimeError(f"ro {args[0]} failed: {result.stderr}")
    return entry


def job_entry(job_id):
    entries = json.loads((ROOT / ".ro" / "jobs.json").read_text(encoding="utf-8"))
    return next(entry for entry in entries if entry["id"] == job_id)


def live_snapshot(job_id):
    entry = job_entry(job_id)
    child = entry.get("child") or {}
    child_alive = bool(child.get("pid") and child.get("start") and
                       same_process(int(child["pid"]), child["start"]))
    snapshot = {"observed_utc": now(), "job": entry,
                "owned_job_alive": running_job(entry), "worker_alive": child_alive,
                "monitor_alive": live_monitor(entry)}
    assert snapshot["owned_job_alive"] and child_alive, "probe requires live worker"
    return snapshot


def main():
    job_id = None
    monitor = None
    report["started_utc"] = now()
    report["input_sha256_before"] = hashes()
    save()
    try:
        launch = invoke("launch", "--item", "H-A-01", "--expect", "3m", "--confirm", "2s",
                        "--run-dir", "runs/job-a", "--bind", "runs/job-a/input.txt", "--",
                        str(PYTHON), str(ROOT / "worker.py"))
        entries = json.loads((ROOT / ".ro" / "jobs.json").read_text(encoding="utf-8"))
        job_id = next(entry["id"] for entry in reversed(entries) if entry["session"] == SESSION)
        report["job_id"] = job_id
        assert "confirmed alive" in launch["stdout"], launch["stdout"]
        monitor_command = RO + ["monitor", job_id]
        monitor = subprocess.Popen(monitor_command, cwd=ROOT, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                   creationflags=FLAGS)
        report["monitor_start"] = {"argv": monitor_command, "pid": monitor.pid, "at_utc": now()}
        deadline = time.monotonic() + 5
        while not live_monitor(job_entry(job_id)):
            if monitor.poll() is not None or time.monotonic() >= deadline:
                raise RuntimeError("monitor failed to become live")
            time.sleep(0.05)
        cases = [
            ("relative-parent", "Rename-Item -LiteralPath runs -NewName previous-runs", "deny",
             "runs is an ancestor of the live job's bound runs/job-a directory and input. Renaming it changes their paths."),
            ("absolute-parent", "Rename-Item -LiteralPath '" + str(ROOT / "runs").replace("'", "''") + "' -NewName previous-runs", "deny",
             "The absolute runs path denotes the same ancestor; absolute and relative paths must receive the same protection."),
            ("unrelated-sibling", "Rename-Item -LiteralPath runs/job-b -NewName previous-job", "none",
             "runs/job-b is a sibling of runs/job-a and overlaps no running-job binding. The empty hook response means no denial, not an explicit allow."),
        ]
        for name, command, expected, explanation in cases:
            before = live_snapshot(job_id)
            assert before["monitor_alive"], "monitor must stay live during probes"
            payload = {"hook_event_name": "PreToolUse", "cwd": str(ROOT),
<withheld internal metadata>
                       "tool_input": {"command": command, "cwd": str(ROOT)}}
            result = invoke("hook", "PreToolUse", payload=payload)
            response = json.loads(result["stdout"])
            decision = response.get("hookSpecificOutput", {}).get("permissionDecision", "none")
            probe = {"id": name, "payload": payload, "response": response,
                     "response_stdout": result["stdout"], "response_stderr": result["stderr"],
                     "returncode": result["returncode"], "decision": decision,
                     "expected_decision": expected, "matches_expected": decision == expected,
                     "explanation": explanation, "live_before": before,
                     "live_after": live_snapshot(job_id)}
            report["probes"].append(probe)
            save()
            print(f"{name}: {decision}", flush=True)
    finally:
        # Recover ownership if the CLI failed after registering a job.
        registry = ROOT / ".ro" / "jobs.json"
        if job_id is None and registry.exists():
            matches = [entry for entry in json.loads(registry.read_text(encoding="utf-8"))
                       if entry.get("session") == SESSION and entry.get("item") == "H-A-01"]
            if matches:
                job_id = matches[-1]["id"]
                report["job_id"] = job_id
        if job_id:
            if running_job(job_entry(job_id)):
                invoke("kill", job_id)
            if monitor is not None:
                stdout, stderr = monitor.communicate(timeout=15)
                report["monitor_result"] = {"returncode": monitor.returncode,
                                            "stdout": stdout, "stderr": stderr, "ended_utc": now()}
                save()
            if not monitor_outcome(job_entry(job_id)):
                report["final_monitor"] = invoke("monitor", job_id)
            report["jobs_result"] = invoke("jobs")
            final = job_entry(job_id)
            report["final_job"] = final
            report["job_stopped"] = not running_job(final)
            report["monitor_outcome_recorded"] = monitor_outcome(final)
            child = final.get("child") or {}
            report["worker_stopped"] = not (child.get("pid") and child.get("start") and
                                            same_process(int(child["pid"]), child["start"]))
            report["worker_log"] = Path(final["log"]).read_text(encoding="utf-8", errors="replace")
        report["input_sha256_after"] = hashes()
        report["inputs_unchanged"] = report["input_sha256_before"] == report["input_sha256_after"]
        report["directory_checks"] = {
            "runs_job_a_present": (ROOT / "runs" / "job-a").is_dir(),
            "runs_job_b_present": (ROOT / "runs" / "job-b").is_dir(),
            "previous_runs_absent": not (ROOT / "previous-runs").exists(),
            "previous_job_absent": not (ROOT / "runs" / "previous-job").exists(),
        }
        report["ended_utc"] = now()
        save()
    assert len(report["probes"]) == 3 and all(p["matches_expected"] for p in report["probes"])
    assert report["inputs_unchanged"] and all(report["directory_checks"].values())
    assert report["job_stopped"] and report["worker_stopped"] and report["monitor_outcome_recorded"]
    assert "ready" in report["worker_log"]
    report["result"] = "PASS"
    save()
    print(f"{job_id}: stopped, final monitor outcome recorded; all inputs unchanged", flush=True)


if __name__ == "__main__":
    main()
