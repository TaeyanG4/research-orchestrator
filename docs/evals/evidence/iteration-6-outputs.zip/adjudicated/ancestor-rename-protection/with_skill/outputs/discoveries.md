# Rename protection — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `self`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-A-001 — Short title
- Source: A
- Host: Claude Code
- User: kim
- Date: 2026-10-05
- Cross-check: PENDING
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
```

## D-A-001 — PowerShell ancestor renames are denied for a live owned job
- Source: A
- Host: Codex
- User: Lee
- Date: 2026-10-26
- Session: codex:<withheld-id>@2026-10-26T13:50
- Cross-check: VERIFIED
- Finding: With Environment windows/powershell, Enforcement block and Block jobs.mutate-bound, direct PreToolUse probes deny Rename-Item of runs using either its relative path or absolute project path while J-A-0001 is live in runs/job-a. The runs/job-b sibling probe returns an empty object with no denial. This establishes adapter decisions, not automatic hook delivery by Codex.
- Evidence: rename-probes.json contains the exact three payloads with absolute project cwd, raw responses, PID/start-time liveness checks before and after every probe, bindings, launch/kill/monitor transcripts, and unchanged SHA-256 hashes for all four supplied files. run_rename_probes.py reproduces the procedure using JSON stdin to ro hook PreToolUse, without executing any rename. Both deny responses cite jobs.mutate-bound; the sibling response is {}. The worker log contains ready. The final registry reports killed with monitor reason job process tree killed, with both owned process and worker confirmed stopped.
- Implication: Parent renames require ancestor overlap protection because they relocate the bound run directory and its descendants. Literal sibling components do not overlap. Keep these results scoped to the direct adapter and declared environment.
- Reviews:
  - Codex (A): CLOSED — self-verification: inspected the exact hook responses, live child identities, final monitored registry, worker log and original-file hashes.
