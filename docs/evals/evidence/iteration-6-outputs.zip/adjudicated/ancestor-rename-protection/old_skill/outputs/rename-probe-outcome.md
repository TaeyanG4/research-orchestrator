The ancestor rename protection test is inconclusive. The supplied skill contains
only `scripts/init_research_orchestrator.py` and `scripts/check_project.py`; it has
no owned-job manager, PreToolUse hook, or `jobs.mutate-bound` implementation.
The requested enforcement settings were recorded, but could not be activated.

The available initializer created the research project for Lee on Codex with
slot A, Git sync off, and session identifier `rename-protection-56bb005c-A`.
`brief.md` and the other three input files were preserved byte for byte.

`rename-probes.json` contains all three candidate PreToolUse payloads. Each has
an absolute project cwd, and each was prepared while worker PID 47228 was live
in `runs/job-a`. No payload was submitted: `response` and `decision` are null,
and `submission_status` is `not_submitted_hook_unavailable`. No rename ran.

| Probe source | Expected behavior under the requested rule | Reason |
| --- | --- | --- |
| `runs` | deny | Renaming this ancestor would move the bound `runs/job-a` directory. |
| Absolute project `runs` path | deny | It resolves to the same ancestor as the relative source. |
| `runs/job-b` | allow | This sibling does not contain or overlap the bound job directory. |

These are expectations, not observed hook decisions. Actual protection remains
unverified and requires a skill package containing the hook and owned-job manager.

The local supervisor retained the worker process handle, observed `ready`, then
called `Popen.terminate` and waited for exit. The Windows termination exit code
was 1; stderr was empty and the worker was no longer live after the wait.
`runs/job-a/job-result.json` records its owner, command, run directory, PID,
timestamps, and final result. This was local process supervision, not a job
registered with the missing skill manager. SHA256 hashes before and after
match for all four inputs. The supplied project consistency checker passed.
