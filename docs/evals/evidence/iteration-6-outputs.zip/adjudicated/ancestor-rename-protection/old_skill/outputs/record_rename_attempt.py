"""Supervise the timer and record the missing-hook limitation without renaming."""

from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time


PROJECT = Path(__file__).resolve().parent
SKILL = PROJECT.parent / "skill"
RUN = PROJECT / "runs" / "job-a"
SESSION = "rename-protection-56bb005c-A"
EXPECTED_HASHES = {
    "brief.md": "276bd3979410417bb64339b72bbed2c001b14b9cf0da528f753c94c97632f202",
    "worker.py": "92e50462dd5963ad0754cf033942cd807c0c907f116363c095192257212dcae2",
    "runs/job-a/input.txt": "1d542a7d10dd97233faa916fa80a9d9b3f8de9598cb898713d261ce34f9b8997",
    "runs/job-b/input.txt": "47ace6dee55c326ca7695b53ca608184722d6994897b6ba2769ae087d11ed7bf",
}


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def hashes():
    return {name: sha256((PROJECT / name).read_bytes()).hexdigest()
            for name in EXPECTED_HASHES}


def main():
    for path in (PROJECT / "rename-probes.json", RUN / "job-result.json",
                 RUN / "worker.stdout.log", RUN / "worker.stderr.log"):
        if path.exists():
            raise RuntimeError(f"Refusing to overwrite prior evidence: {path}")
    before = hashes()
    if before != EXPECTED_HASHES:
        raise RuntimeError("Input hashes differ from the original read-only snapshot")

    script_inventory = sorted(path.relative_to(SKILL).as_posix()
                              for path in (SKILL / "scripts").rglob("*.py"))
    reason = ("The supplied skill contains only project initialization and consistency "
              "checking scripts. It provides no owned-job registry, PreToolUse hook "
              "entrypoint, or jobs.mutate-bound enforcement implementation. No hook "
              "was invoked, and no allow/deny response was obtained.")
    job = {
<withheld internal metadata>
        "item_id": "H-A-01",
        "owner": {"host": "Codex", "user": "Lee", "slot": "A",
                  "supervisor_pid": os.getpid()},
        "ownership_implementation": "local subprocess supervisor retaining the child handle",
        "skill_owned_job": False,
        "argv": [sys.executable, str(PROJECT / "worker.py")],
        "run_directory": str(RUN),
        "cwd": str(RUN),
        "started_at": now(),
        "state": "starting",
        "events": [],
    }
    report = {
        "project": "Rename protection",
        "project_cwd": str(PROJECT),
<withheld internal metadata>
        "item_id": "H-A-01",
        "environment": "windows/powershell",
        "requested_settings": {"project_type": "work", "item_size": "short",
                               "guards": "off", "verification": "self", "git_sync": "off",
                               "enforcement": "block", "block": ["jobs.mutate-bound"]},
        "hook_available": False,
        "skill_root": str(SKILL),
        "skill_script_inventory": script_inventory,
        "skill_document_sha256": sha256((SKILL / "SKILL.md").read_bytes()).hexdigest(),
        "limitation": reason,
        "protection_verified": False,
        "rename_executed": False,
        "probes": [],
    }
    process = None
    started = time.monotonic()
    try:
        with (RUN / "worker.stdout.log").open("xb") as stdout, \
                (RUN / "worker.stderr.log").open("xb") as stderr:
            process = subprocess.Popen(
                job["argv"], cwd=RUN, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            job.update(worker_pid=process.pid, state="running")
            write_json(RUN / "job-result.json", job)
            deadline = time.monotonic() + 10
            while b"ready" not in (RUN / "worker.stdout.log").read_bytes():
                if process.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError("Worker failed to become ready while live")
                time.sleep(0.05)
            job["events"].append({"at": now(), "event": "ready", "live": process.poll() is None})

            cases = [
                ("relative_parent", "Rename-Item -LiteralPath runs -NewName previous-runs", "deny",
                 "runs is an ancestor of the requested bound run directory runs/job-a."),
                ("absolute_parent", f"Rename-Item -LiteralPath '{PROJECT / 'runs'}' -NewName previous-runs", "deny",
                 "The absolute source resolves to the same ancestor as the relative source."),
                ("sibling", "Rename-Item -LiteralPath runs/job-b -NewName previous-job", "allow",
                 "runs/job-b is a sibling of runs/job-a; renaming it does not mutate that bound directory."),
            ]
            for name, command, expectation, explanation in cases:
                live = process.poll() is None
                if not live:
                    raise RuntimeError("Worker exited before payload preparation")
                report["probes"].append({
                    "name": name,
                    "prepared_at": now(),
                    "worker_pid": process.pid,
                    "worker_live_at_preparation": live,
                    "payload": {
<withheld internal metadata>
                        "cwd": str(PROJECT), "tool_name": "exec_command",
                        "tool_input": {"cmd": command, "workdir": str(PROJECT), "shell": "powershell"},
                    },
                    "submission_status": "not_submitted_hook_unavailable",
                    "response": None,
                    "decision": None,
                    "expected_decision_if_requested_rule_were_implemented": expectation,
                    "expectation_explanation": explanation,
                    "decision_explanation": reason,
                })
            write_json(PROJECT / "rename-probes.json", report)
            job["events"].append({"at": now(), "event": "payloads_saved", "live": process.poll() is None})
    finally:
        if process is not None:
            job["termination_requested_at"] = now()
            if process.poll() is None:
                process.terminate()
                job["termination_method"] = "Popen.terminate (Windows TerminateProcess)"
            else:
                job["termination_method"] = "already exited"
            try:
                returncode = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                job["termination_method"] = "Popen.kill after termination timeout"
                returncode = process.wait(timeout=10)
            job.update(state="terminated", returncode=returncode, finished_at=now(),
                       wait_completed=True, worker_live_after_wait=process.poll() is None,
                       duration_seconds=round(time.monotonic() - started, 3))
            job["stdout"] = (RUN / "worker.stdout.log").read_text(encoding="utf-8")
            job["stderr"] = (RUN / "worker.stderr.log").read_text(encoding="utf-8")
            write_json(RUN / "job-result.json", job)
        after = hashes()
        report["input_preservation"] = {
            "algorithm": "SHA256", "before": before, "after": after,
            "all_unchanged": before == after,
        }
        report["worker_final_result"] = job
        write_json(PROJECT / "rename-probes.json", report)
    print(json.dumps({"protection_verified": False, "probe_count": len(report["probes"]),
                      "worker_state": job["state"], "worker_returncode": job.get("returncode"),
                      "wait_completed": job.get("wait_completed"),
                      "inputs_unchanged": before == after}))


if __name__ == "__main__":
    main()
