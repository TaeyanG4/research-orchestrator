# Rename protection — Plan

Keep only active unfinished plan items here — nothing else. Project-wide values such as the current best live in `handoff.md` Shared state. Every completed item leaves a discovery (positive, negative, or inconclusive) and a handoff event, then is removed from this file.

Each agent edits only its own `## Agent: <name>` section. Plan item IDs use `H-<Agent>-<NN>`, for example `H-A-01` or `H-B-07`.

Before adding an item, confirm it is not already in `discoveries.md` (every completed experiment is there, including negative and inconclusive ones) or already queued under another agent (check headings and `Hypothesis` lines only). A repeat needs a real `Improvement` and a citation of the earlier ID.

Priority formula:

```text
Priority = 2*Impact + 2*Information + Confidence + Unblock + Diversity + (3-Cost)
```

All factors are 0-3. Cost is 0 for cheap and 3 for expensive.

Use this exact item format:

```markdown
### H-A-01 — Short title
- Sources: D-B-001, D-A-004 / none
- Hypothesis: ...
- Evidence: ...
- Improvement: ...
- Impact: 0-3
- Information: 0-3
- Confidence: 0-3
- Unblock: 0-3
- Diversity: 0-3
- Cost: 0-3
- Priority: ...
- Resource: CPU | GPU | EITHER
- Parallel: YES | NO
- Other: NONE | <external executor>
- Next test: ...
```

Example external executor: `Other: Kaggle`.

## Agent: A
