Created `project/`: all **3 entries total exactly 10 units**, with complete coverage. Saved the calculation, result, and separate arithmetic check; preserved both inputs.

Registered N-A-001 for the scope note and linked it from Shared state. Discovery D-A-001 remains **PENDING**. The project checker passed; output is saved in `project/checker.txt`.