# Finite inventory audit

User: operator. Host: Local. Git sync: off.

The entire declared inventory consists of the three quantities in quantities.txt. Its total is 10 units; verify that total by adding every entry. This is an exhaustive arithmetic measurement, not a held-out sample and not an estimate of a wider population. Save a reproducible stdlib calculation as calculate.py and result.json with count and total. Register one instrument for this complete scope. Use a separate arithmetic check to describe agreement and the exact resolution, with a discovery citation; do not invent empirical performance claims.

The scope note explains why unlisted inventory is outside the claim; it is a coordination note, not another discovery or plan item.
