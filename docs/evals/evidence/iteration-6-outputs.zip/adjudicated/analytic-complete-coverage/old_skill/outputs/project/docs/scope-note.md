# N-A-001 — Inventory scope

Reserved by slot A in handoff.md Shared state before this file was created.
This is a coordination note.

The claim in [D-A-001](../discoveries.md#d-a-001--complete-inventory-total)
is limited to every quantity listed in the preserved quantities.txt. The brief
declares that file to be the entire finite inventory, so adding every entry
provides complete coverage of that declared scope. Unlisted inventory was not
declared or measured and is outside the claim. The total does not estimate a
wider population or establish completeness of any external inventory.
