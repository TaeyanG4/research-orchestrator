"""Check the calculation separately using exact rational arithmetic (stdlib only).

This script reparses every line without importing calculate.py. It is supporting
evidence produced by the source slot, not an independent research review.
"""

from fractions import Fraction
import hashlib
import json
from pathlib import Path


def main():
    folder = Path(__file__).resolve().parent
    raw = (folder / "quantities.txt").read_bytes()
    count = 0
    total = Fraction(0)
    terms = []
    for number, line in enumerate(raw.decode("utf-8").splitlines(), start=1):
        quantity = Fraction(line.strip())
        if quantity.denominator != 1:
            raise ValueError(f"Line {number} is not a whole-unit quantity")
        total += quantity
        count += 1
        terms.append(str(quantity))

    result = json.loads((folder / "result.json").read_text(encoding="utf-8"))
    digest = hashlib.sha256(raw).hexdigest()
    agreement = (
        count == result["count"]
        and total == result["total"]
        and digest == result["input_sha256"]
    )
    check = {
        "method": "separate Fraction parsing and sequential rational addition",
        "expression": " + ".join(terms) + f" = {total}",
        "count": count,
        "total": int(total),
        "agreement": agreement,
        "difference_units": str(total - result["total"]),
        "resolution_units": 1,
        "arithmetic_rounding_error_units": 0,
        "input_sha256": digest,
        "independent_review": False,
    }
    (folder / "arithmetic-check.json").write_text(
        json.dumps(check, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(check))
    if not agreement:
        raise SystemExit("Arithmetic check disagrees with result.json")


if __name__ == "__main__":
    main()
