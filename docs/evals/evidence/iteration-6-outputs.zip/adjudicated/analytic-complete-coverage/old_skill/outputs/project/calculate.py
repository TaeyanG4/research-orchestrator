"""Sum every inventory line with exact Python integers (stdlib only).

Run with the supplied Python executable; paths default to this script's folder.
Blank or malformed lines fail instead of silently reducing coverage.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re


def main():
    folder = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=folder / "quantities.txt")
    parser.add_argument("--output", type=Path, default=folder / "result.json")
    args = parser.parse_args()

    raw = args.input.read_bytes()
    lines = raw.decode("utf-8").splitlines()
    if not lines:
        raise ValueError("The inventory contains no quantity lines")
    quantities = []
    for number, line in enumerate(lines, start=1):
        if re.fullmatch(r"[+-]?[0-9]+", line.strip()) is None:
            raise ValueError(f"Line {number} must contain one integer quantity")
        quantities.append(int(line))

    result = {
        "count": len(quantities),
        "total": sum(quantities),
        "unit": "units",
        "input_sha256": hashlib.sha256(raw).hexdigest(),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
