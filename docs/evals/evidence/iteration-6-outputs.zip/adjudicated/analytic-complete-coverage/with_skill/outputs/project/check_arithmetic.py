"""Check the total separately using exact rational subtraction in reverse order."""

from fractions import Fraction
import hashlib
import json
from pathlib import Path


def main():
    directory = Path(__file__).resolve().parent
    raw = (directory / "quantities.txt").read_bytes()
    lines = raw.decode("utf-8").splitlines()
    if not lines:
        raise ValueError("The declared inventory has no quantity lines")
    quantities = [Fraction(line.strip()) for line in lines]
    if any(value.denominator != 1 for value in quantities):
        raise ValueError("Expected whole-unit quantities on every line")

    negative_total = Fraction(0)
    steps = ["0"]
    for value in reversed(quantities):
        negative_total -= value
        steps.append(f"- ({value})")
    total = -negative_total
    primary = json.loads((directory / "result.json").read_text(encoding="utf-8"))
    difference = total - Fraction(primary["total"])
    input_sha256 = hashlib.sha256(raw).hexdigest()
    agrees = (
        difference == 0
        and len(quantities) == primary["count"]
        and input_sha256 == primary["input_sha256"]
    )
    result = {
        "count": len(quantities),
        "total": int(total),
        "input_sha256": input_sha256,
        "method": "independent code path: exact Fraction parsing and reverse-order subtraction from zero, then negation",
        "arithmetic": f"{' '.join(steps)} = {negative_total}; negate = {total}",
        "difference_units": int(difference),
        "agreement_with_result": agrees,
        "arithmetic_rounding_error_units": 0,
        "quantity_granularity_units": 1,
        "review": "same-session arithmetic check; independent review remains unavailable",
    }
    (directory / "arithmetic-check.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    if not agrees:
        raise SystemExit("Arithmetic, count, or input identity disagrees")


if __name__ == "__main__":
    main()
