# N-A-01 — Scope of the finite inventory audit

The scope is every line of the preserved [quantities.txt](../quantities.txt), because [brief.md](../brief.md) defines those entries as the entire declared inventory. The finding is recorded in [D-A-001](../discoveries.md#d-a-001--exact-total-of-the-complete-declared-inventory).

Unlisted inventory is outside that declaration and was neither observed nor counted. Complete coverage of the declared list establishes no claim about such inventory or a wider population. This is a coordination note, not another discovery or plan item.
