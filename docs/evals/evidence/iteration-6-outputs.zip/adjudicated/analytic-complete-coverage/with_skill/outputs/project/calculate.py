"""Sum every inventory line exactly. Run with Python 3; standard library only."""

import argparse
import hashlib
import json
from pathlib import Path
import re


def main():
    directory = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=directory / "quantities.txt")
    parser.add_argument("--output", type=Path, default=directory / "result.json")
    args = parser.parse_args()

    raw = args.input.read_bytes()
    lines = raw.decode("utf-8").splitlines()
    if not lines:
        raise ValueError("The declared inventory has no quantity lines")
    quantities = []
    for number, line in enumerate(lines, 1):
        token = line.strip()
        if re.fullmatch(r"[+-]?[0-9]+", token) is None:
            raise ValueError(f"Line {number}: expected one integer quantity")
        quantities.append(int(token))

    result = {
        "count": len(quantities),
        "total": sum(quantities),
        "unit": "units",
        "input": args.input.name,
        "input_sha256": hashlib.sha256(raw).hexdigest(),
        "method": "exact integer sum of every line, with no skipped lines",
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
