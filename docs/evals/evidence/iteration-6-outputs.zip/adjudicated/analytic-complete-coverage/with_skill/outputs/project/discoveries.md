# Finite inventory audit — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `independent-review`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-A-001 — Short title
- Source: A
- Host: Claude Code
- User: kim
- Date: 2026-10-05
- Session: claude-code:A@2026-10-05T14:10
- Cross-check: VERIFIED
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
  - Claude Code (A): CLOSED — reviewer subagent:fable@2026-10-05T15:02 — reproduced independently with ...
```

## D-A-001 — Exact total of the complete declared inventory
- Source: A
- Host: Local
- User: operator
- Date: 2026-10-26
- Session: codex:A@2026-10-26T04:49:57
- Cross-check: PENDING
- Finding: every line of the preserved quantities.txt was included: 3 quantities, 2 + 3 + 5 = 10 units, matching the total stated in brief.md. This is an exhaustive result for that declared finite inventory only; it supports no claim about unlisted inventory or a wider population.
- Evidence: [calculate.py](calculate.py) produced [result.json](result.json) by exact integer summation. [check_arithmetic.py](check_arithmetic.py) independently parsed the same preserved input using Fraction and subtracted all quantities in reverse order from zero, then negated the result; [arithmetic-check.json](arithmetic-check.json) records agreement on the count, total, and input SHA-256, with a difference of 0 units. Both calculations have exact arithmetic resolution, with 0 units of rounding error; the input quantities have a granularity of 1 unit. The original and project copies of brief.md and quantities.txt were verified byte-identical by SHA-256. Reproduce with `<host-path-1d5ebf570ab0> project/calculate.py` then the same executable with `project/check_arithmetic.py`, from the enclosing workspace directory.
- Implication: the declared total is supported for the complete listed scope. Coverage does not establish independent provenance or population generalization. The same-session arithmetic check is not an independent review; no eligible reviewer is available in this session, so the discovery remains PENDING.
- Decision class: other
- Instrument: I-A-01
- Result: total_units=10 on I-A-01 cohort declared-inventory
- Family: exhaustive-exact-arithmetic
- Reviews:
