# Archive handoff — Plan

Active unfinished plan items only. Read `<skill-root>/references/plan-items.md` for item format, duplicate checks and priority; `<skill-root>/SKILL.md` for the item lifecycle; and `<skill-root>/references/workflow-classic.md` for ownership.

Use queue position or an optional `Next: H-A-01` in this header to order work. Scores and Priority are optional; still check the discovery index and queued goals for duplicates. Add Sources, Improvement or routing only when useful; omitted Resource/Parallel/Other mean CPU/NO/NONE. Goal and Hypothesis are aliases. Item format:

```markdown
### H-A-01 — Short title
- Goal: <goal or question>
- Evidence: <observations or context>
- Next test: <next step>
```


## Agent: A

_No active items. Completed work is recorded in the session event in handoff.md._
