# Archive handoff — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `self`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-A-001 — Short title
- Source: A
- Host: Claude Code
- User: kim
- Date: 2026-10-05
- Cross-check: PENDING
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
```

## D-A-001 — Stable identifier ordering for the approved archive inventory
- Source: A
- Host: Shell
- User: operator
- Date: 2026-10-26
- Cross-check: PENDING
- Finding: Reusable design decision reported by the helper: sorting the approved inventory by stable identifier avoids the nondeterministic archive order. This is a specification-based design conclusion, with no independent experimental validation or measured speedup.
- Evidence: request.md quotes the helper's evidence as inspection of inventory specification section 2. The specification itself was not supplied locally; this session preserves that reported provenance and has not independently inspected it or performed an experiment.
- Implication: Use stable identifier ordering in the already specified archive task. Preserve this decision for reuse; it makes no performance claim.
- Reviews:
