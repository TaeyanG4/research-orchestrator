Recorded `D-A-001` and explicitly chose no follow-up. The consistency checker passes.

Saved [limits.md](<host-path-36ce50ad1c43>) and [close.txt](<host-path-f0cb72eceee0>).

`ro close` was attempted but could not execute because no `ro` CLI is available. The unsupported quick/guards/self settings were preserved as metadata.