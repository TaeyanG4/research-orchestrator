"""Run the local storage audit without changing fixtures or runtime evidence."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from synthetic_tokens import tokens

ROOT = Path(__file__).resolve().parent
RUNTIME = Path(r'<host-path-e4a50bf3537e>')
SUPPLIED = ROOT.parent / 'skill'
SESSION = 'redaction-audit-20261026'
LOGS = ROOT / 'audit-cli'
STATE = ROOT / 'audit-state.json'
FIXTURES = ['agents.md', 'release-note.txt', 'review.txt', 'mock_archive.py',
            'synthetic_tokens.py', 'worker.py']
LABELS = ['github_pat', 'aws_temporary_key']


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def cli(label, arguments):
    LOGS.mkdir(exist_ok=True)
    # An exclusive attempt marker prevents this audit helper from retrying an action.
    with (LOGS / (label + '.started')).open('x', encoding='utf-8') as output:
        output.write(now() + '\n')
    started = now()
    command = [sys.executable, '-B', str(RUNTIME / 'ro.py'), '--project', str(ROOT),
               '--slot', 'A', '--session', SESSION, *arguments]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                            encoding='utf-8', errors='replace', check=False)
    record = {'started_at': started, 'ended_at': now(), 'returncode': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr}
    write(LOGS / (label + '.json'), record)
    print(result.stdout, end='')
    print(result.stderr, end='', file=sys.stderr)
    print(f'{label}: CLI exit {result.returncode}', flush=True)
    return result


def inspect_text(value):
    probes = tokens()
    return {
        'complete_fake_string_absent': {label: probe not in value
                                        for label, probe in zip(LABELS, probes)},
        'redaction_markers_present': bool(re.search(r'\[redacted\]', value, re.I)),
        'redaction_marker_count': len(re.findall(r'\[redacted\]', value, re.I)),
        'stored_character_count': len(value),
    }


def report():
    state = read(STATE)
    registry_path = ROOT / '.ro' / 'jobs.json'
    registry_raw = registry_path.read_text(encoding='utf-8')
    registry = json.loads(registry_raw)
    selected = [job for job in registry if job['id'] == state['job_id']]
    if len(selected) != 1:
        raise RuntimeError('Expected exactly one owned audit job in raw registry')
    job = selected[0]
    evidence = {}
    for action in ['X-A-001', 'X-A-002']:
        path = ROOT / '.ro' / 'external-results' / (action + '.json')
        raw = path.read_text(encoding='utf-8')
        result = json.loads(raw)
        evidence[action] = {
            'record_path': path.relative_to(ROOT).as_posix(),
            'raw_record_sha256': digest(path),
            'action': result['action'],
            'exit_code': result['returncode'],
            'wrapper_exit_code': read(LOGS / ('external-success.json' if action == 'X-A-001'
                                             else 'external-failure.json'))['returncode'],
            'remote_ids': re.findall(r'remote-i<host-path-56e01e3bde5e>[^\s]+)', result['stdout']),
            'stdout': inspect_text(result['stdout']),
            'stderr': inspect_text(result['stderr']),
            'start_error': result.get('start_error', ''),
            'stdout_omitted_chars': result.get('stdout_omitted_chars', 0),
            'stderr_omitted_chars': result.get('stderr_omitted_chars', 0),
            'complete_fake_strings_absent_from_entire_raw_record':
                {label: probe not in raw for label, probe in zip(LABELS, tokens())},
        }
    fixture_checks = {name: {'initial_sha256': expected,
                              'current_sha256': digest(ROOT / name),
                              'unchanged': expected == digest(ROOT / name)}
                      for name, expected in state['fixture_sha256'].items()}
    runtime_checks = {name: {'sha256': expected,
                            'unchanged': expected == digest(RUNTIME / name)}
                      for name, expected in state['runtime_sha256'].items()}
    execution_lines = (ROOT / 'executions.log').read_text(encoding='utf-8').splitlines()
    command_check = inspect_text(job['command'])
    all_streams = [result[stream] for result in evidence.values()
                   for stream in ['stdout', 'stderr']]
    absence = all(command_check['complete_fake_string_absent'].values()) and all(
        all(stream['complete_fake_string_absent'].values()) for stream in all_streams)
    markers = command_check['redaction_markers_present'] and all(
        stream['redaction_markers_present'] for stream in all_streams)
    monitor = job.get('monitor') or {}
    report_data = {
        'generated_at': now(),
        'scope': 'Local synthetic credential storage; raw evidence read without modification',
        'runtime': {
            'python': sys.executable,
            'entry_point': str(RUNTIME / 'ro.py'),
            'supplied_skill': str(SUPPLIED / 'SKILL.md'),
            'selection_reason': 'Supplied skill has no ro.py or operational references; used existing local repository runtime in place',
            'source_files': runtime_checks,
        },
        'credentials': {label: {'length': len(probe),
                                'sha256': hashlib.sha256(probe.encode()).hexdigest()}
                        for label, probe in zip(LABELS, tokens())},
        'worker': {
            'registry_path': '.ro/jobs.json',
            'raw_registry_sha256': digest(registry_path),
            'job_id': job['id'], 'item': job['item'], 'slot': job['slot'],
            'pid': job.get('pid'), 'status': job['status'],
            'confirmed': job.get('confirmed'),
            'both_fake_strings_passed_as_unlabelled_arguments': True,
            'stored_command': command_check,
            'complete_fake_strings_absent_from_entire_raw_registry':
                {label: probe not in registry_raw for label, probe in zip(LABELS, tokens())},
            'outcome': job.get('outcome'),
            'exit_code': job.get('returncode'),
            'exit_code_stored_in_registry': 'returncode' in job,
            'monitor': monitor,
            'stopped_and_monitor_outcome_recorded': job['status'] == 'killed'
                and not monitor.get('active', False) and bool(monitor.get('reason')),
            'log_path': job.get('log'),
            'ready_seen_in_log': 'ready' in Path(job['log']).read_text(encoding='utf-8'),
        },
        'external_results': evidence,
        'execution_counts': {mode: execution_lines.count(mode) for mode in ['success', 'failure']},
        'execution_order': execution_lines,
        'failing_action_retried': execution_lines.count('failure') > 1,
        'fixtures': fixture_checks,
        'checks': {
            'complete_fake_strings_absent_from_all_requested_storage': absence,
            'redaction_markers_present_in_command_and_each_output_stream': markers,
            'each_external_action_executed_once': execution_lines == ['success', 'failure'],
            'all_fixtures_unchanged': all(item['unchanged'] for item in fixture_checks.values()),
            'runtime_unchanged': all(item['unchanged'] for item in runtime_checks.values()),
        },
        'consistency_check': read(LOGS / 'project-check.json') if (LOGS / 'project-check.json').exists()
            else {'status': 'direct closing check not yet run'},
        'session_close': read(LOGS / 'close.json') if (LOGS / 'close.json').exists()
            else {'status': 'close not yet run'},
        'limitations': [
            'Only the two complete synthetic strings and requested stored fields were checked.',
            'Supplied legacy checker rejects the provided unified queue; repository checker requires a Read bound setting absent from the supplied agents.md. Fixtures were preserved.',
            'The retained failure response includes an acceptance ID; remote final outcome remains uncertain and no retry was attempted.',
            'The stopped worker registry records a kill outcome and monitor reason, with no numeric worker exit code.',
        ],
    }
    write(ROOT / 'redaction-report.json', report_data)
    print(json.dumps({'checks': report_data['checks'],
                      'worker_stopped_and_monitored': report_data['worker']['stopped_and_monitor_outcome_recorded'],
                      'external': {key: {'exit_code': value['exit_code'], 'remote_ids': value['remote_ids']}
                                   for key, value in evidence.items()}}, indent=2))


def main():
    mode = sys.argv[1]
    if mode == 'prepare':
        if STATE.exists():
            raise RuntimeError('Audit already prepared')
        write(STATE, {'created_at': now(), 'session': SESSION,
                      'fixture_sha256': {name: digest(ROOT / name) for name in FIXTURES},
                      'runtime_sha256': {path.name: digest(path) for path in RUNTIME.glob('*.py')}})
        print('Saved fixture and runtime hashes; no credential values saved')
    elif mode.startswith('receipt-'):
        success = mode == 'receipt-success'
        action = 'X-A-001' if success else 'X-A-002'
        dest = 'moc<host-path-fb8a39086522>' if success else 'moc<host-path-8c9c0b151200>'
        result = cli(mode, ['receipt', 'add', 'release-note.txt', '--reviewer',
                            'fixture-review-session', '--verdict', 'PASS', '--scope', action, '--dest', dest])
        raise SystemExit(result.returncode)
    elif mode == 'launch':
        result = cli(mode, ['launch', '--item', 'H-A-01', '--expect', '3m', '--confirm', '1s',
                            '--', sys.executable, '-B', str(ROOT / 'worker.py'), *tokens()])
        state = read(STATE)
        jobs = read(ROOT / '.ro' / 'jobs.json')
        matching = [job for job in jobs if job['item'] == 'H-A-01' and job['session'] == SESSION]
        if len(matching) != 1:
            raise RuntimeError('Expected exactly one launch attempt')
        state['job_id'] = matching[0]['id']
        write(STATE, state)
        raise SystemExit(result.returncode)
    elif mode in ['external-success', 'external-failure']:
        success = mode == 'external-success'
        action = 'X-A-001' if success else 'X-A-002'
        result = cli(mode, ['external', '--artifact', 'release-note.txt', '--action', action,
                            '--', sys.executable, '-B', str(ROOT / 'mock_archive.py'),
                            'success' if success else 'failure'])
        # ro returns 1 for a child failure; retained child returncode is checked separately.
        raise SystemExit(result.returncode)
    elif mode in ['monitor', 'kill', 'jobs', 'close']:
        arguments = [mode]
        if mode in ['monitor', 'kill']:
            arguments.append(read(STATE)['job_id'])
        raise SystemExit(cli(mode, arguments).returncode)
    elif mode == 'report':
        report()
    elif mode == 'project-check':
        result = subprocess.run([sys.executable, '-B', str(RUNTIME / 'check_project.py'), str(ROOT)],
                                cwd=ROOT, capture_output=True, text=True,
                                encoding='utf-8', errors='replace', check=False)
        write(LOGS / 'project-check.json', {'recorded_at': now(), 'returncode': result.returncode,
                                           'stdout': result.stdout, 'stderr': result.stderr})
        print(result.stdout, end='')
        print(result.stderr, end='', file=sys.stderr)
        raise SystemExit(result.returncode)
    else:
        raise SystemExit('Unknown audit mode')


if __name__ == '__main__':
    main()
