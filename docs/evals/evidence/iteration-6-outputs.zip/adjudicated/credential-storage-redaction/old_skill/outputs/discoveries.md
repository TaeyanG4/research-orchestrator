# external action order — Discoveries

## D-A-001 — Synthetic credentials redacted from retained diagnostics
- Source: A
- Host: local
- User: operator
- Date: 2026-10-26
- Session: redaction-audit-20261026
- Cross-check: PENDING
- Finding: Both complete synthetic strings are absent from the owned worker's stored command and both retained output streams for each once-only local external action, using the existing repository runtime identified in redaction-report.json.
- Evidence: redaction-report.json checks the raw .ro/jobs.json and .ro/external-results/X-A-001.json and X-A-002.json. The command and each of the four output streams contain two [REDACTED] markers. X-A-001 retains archive-accepted-482 and exit 0; X-A-002 retains archive-uncertain-731 and exit 7. executions.log contains success then failure exactly once each. The worker reached ready, was stopped as J-A-0001, and its monitor recorded job process tree killed. Fixture and runtime source hashes remain unchanged.
- Implication: The tested runtime retains useful reconciliation evidence while removing these two complete strings. This finding is limited to that runtime because the supplied skill omitted ro.py and operational references. The failed action was not retried; its reported acceptance remains uncertain. No further execution is needed for this bounded audit.
- Reviews:
