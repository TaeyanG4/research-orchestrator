"""Deliberately fake format probes, constructed only when the local test runs."""


def tokens():
    return ["github_pat_" + "aB9_" * 20, "ASIA" + "A1" * 8]
