Saved [redaction-report.json](<host-path-407e9f55c524>).

Redaction checks **PASS**: both complete fake strings are absent from the stored command and all four retained streams; markers are present.

| Action | Retained remote ID | Exit |
|---|---|---:|
| X-A-001 | archive-accepted-482 | 0 |
| X-A-002 | archive-uncertain-731 | 7 |

Each action ran once, with no retry. The worker was stopped and monitored, and its outcome recorded. Supplied metadata checker errors are documented in the report.