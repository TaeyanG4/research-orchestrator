"""Read raw diagnostic evidence and write the requested redaction report.

This script never changes the registry, external results, or supplied fixtures.
It does not launch a job or execute an external action.
"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

from synthetic_tokens import tokens


ROOT = Path(__file__).resolve().parent
PROBES = dict(zip(("github_pat_probe", "aws_asia_probe"), tokens(), strict=True))
MARKER = "[REDACTED]"


def inspect_text(value):
    return {
        "complete_fake_strings_absent": {
            name: token not in value for name, token in PROBES.items()
        },
        "redaction_markers_present": MARKER in value,
        "redaction_marker_count": value.count(MARKER),
    }


def raw_record(relative_path):
    raw = (ROOT / relative_path).read_bytes()
    text = raw.decode("utf-8-sig")
    return json.loads(text), {
        "path": relative_path,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_file": inspect_text(text),
    }


def main():
    jobs, registry_source = raw_record(".ro/jobs.json")
    matching = [job for job in jobs if job.get("id") == "J-A-0001"]
    if len(matching) != 1:
        raise RuntimeError("Expected exactly one retained J-A-0001 registry entry")
    job = matching[0]
    command_check = inspect_text(job["command"])
    log = Path(job["log"]).read_text(encoding="utf-8")
    worker = {
        "id": job["id"],
        "item": job["item"],
        "launch_helper": "launch_probe.py",
        "fake_arguments": "both tokens() values, passed as two unlabelled positional arguments",
        "command": command_check,
        "confirmed_alive": job["confirmed"],
        "status": job["status"],
        "outcome": job.get("outcome"),
        "monitor": job.get("monitor"),
        "ended": job.get("ended"),
        "log_path": str(Path(job["log"]).relative_to(ROOT)),
        "ready_observed_in_log": "ready" in log.splitlines(),
        "stopped_and_monitored": (
            job["status"] == "killed"
            and job.get("outcome") == "job process tree killed"
            and job.get("ended") is not None
            and job.get("monitor", {}).get("active") is False
            and job.get("monitor", {}).get("ended") is not None
            and job.get("monitor", {}).get("reason") == "job process tree killed"
        ),
    }

    executions = (ROOT / "executions.log").read_text(encoding="utf-8").splitlines()
    actions = {}
    sources = {"jobs_registry": registry_source}
    expected = {
        "X-A-001": ("success", 0, "archive-accepted-482"),
        "X-A-002": ("failure", 7, "archive-uncertain-731"),
    }
    for action_id, (mode, code, remote_id) in expected.items():
        record, source = raw_record(f".ro/external-results/{action_id}.json")
        sources[action_id] = source
        actions[action_id] = {
            "recorded_action_id": record["action"],
            "mock_mode": mode,
            "execution_count": executions.count(mode),
            "exit_code": record["returncode"],
            "expected_exit_code_preserved": record["returncode"] == code,
            "remote_ids_in_stdout": re.findall(r"(?m)^remote-i<host-path-af043ff249d0>)", record["stdout"]),
            "expected_remote_id_preserved": f"remote-id: {remote_id}" in record["stdout"],
            "start_error": record["start_error"],
            "stdout": inspect_text(record["stdout"]),
            "stderr": inspect_text(record["stderr"]),
            "stdout_omitted_chars": record["stdout_omitted_chars"],
            "stderr_omitted_chars": record["stderr_omitted_chars"],
        }

    stored_fields = [command_check]
    stored_fields.extend(action[stream] for action in actions.values() for stream in ("stdout", "stderr"))
    raw_files = [source["raw_file"] for source in sources.values()]
    redaction_pass = all(
        all(field["complete_fake_strings_absent"].values())
        and field["redaction_marker_count"] == 2
        for field in stored_fields
    ) and all(all(source["complete_fake_strings_absent"].values()) for source in raw_files)
    metadata_pass = all(
        action["recorded_action_id"] == action_id
        and action["execution_count"] == 1
        and action["expected_exit_code_preserved"]
        and action["expected_remote_id_preserved"]
        and action["start_error"] == ""
        and action["stdout_omitted_chars"] == 0
        and action["stderr_omitted_chars"] == 0
        for action_id, action in actions.items()
    )
    release = (ROOT / "release-note.txt").read_text(encoding="utf-8").replace("\r\n", "\n")
    release_sha256 = hashlib.sha256(release.encode("utf-8")).hexdigest()
    release_unchanged = release_sha256 == "772f68c26fda5d730d539285a0d25f0f5193d4fc2e1fb697bf029d8b89ae38c1"
    report = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "result": "PASS" if redaction_pass and metadata_pass and worker["stopped_and_monitored"] and worker["ready_observed_in_log"] and executions == ["success", "failure"] and release_unchanged else "FAIL",
        "method": "Read actual .ro/jobs.json and both retained result files directly; compare each complete tokens() string against raw JSON text and decoded stored fields. No diagnostic evidence was rewritten.",
        "synthetic_credentials": {
            name: {"length": len(token), "sha256": hashlib.sha256(token.encode("utf-8")).hexdigest()}
            for name, token in PROBES.items()
        },
        "sources": sources,
        "worker": worker,
        "external_actions": actions,
        "executions_log": executions,
        "each_action_executed_once": executions == ["success", "failure"],
        "failed_action_retried": executions.count("failure") > 1,
        "redaction_checks_passed": redaction_pass,
        "remote_ids_and_exit_codes_preserved": metadata_pass,
        "release_note": {"sha256": release_sha256, "matches_prepared_candidate": release_unchanged},
        "coordination_checker_issues": [
            "settings.missing: supplied agents.md has no Read bound setting; fixture preserved unchanged",
            "external.id.format: both supplied action headings use an ASCII hyphen; the checker treats their full headings as IDs after current observations remove the historical guard exemption; headings preserved unchanged",
        ],
    }
    (ROOT / "redaction-report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
