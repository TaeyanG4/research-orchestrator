# external action order — Discoveries

## D-A-001 — Local diagnostic redaction preserves reconciliation metadata
- Source: A
- Host: local
- User: operator
- Date: 2026-10-26
- Session: codex:<withheld-id>@2026-10-26T14:17
- Cross-check: PENDING
- Finding: For both complete strings returned by synthetic_tokens.tokens(), the raw owned-job registry command and both retained stdout/stderr pairs contain no complete fake credential. Each stored command or stream contains two redaction markers. Both remote IDs and the mock exit codes survive, including the uncertain failure. Each mock executed once.
- Evidence: redaction-report.json, reproduced by inspect_storage.py against .ro/jobs.json, .ro/external-results/X-A-001.json, .ro/external-results/X-A-002.json, executions.log, and the worker log. launch_probe.py passes both generated strings as unlabelled positional arguments. The report includes raw-file hashes and separate exact-string checks for every field.
- Implication: The tested diagnostic storage paths preserve usable reconciliation evidence while redacting both supplied credential formats. This does not establish coverage of other formats. Do not repeat the uncertain action; no runtime or fixture change is required for this bounded audit.
- Reviews:
