"""Launch the supplied worker through ro with unlabelled synthetic arguments."""

import os
from pathlib import Path
import subprocess
import sys

from synthetic_tokens import tokens


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    ro = root.parent / "skill" / "scripts" / "ro.py"
    session = os.environ.get("CODEX_THREAD_ID", "codex:storage-redaction@2026-10-26T14:16")
    command = [
        sys.executable, str(ro), "--project", str(root), "--slot", "A",
        "--session", session, "launch", "--item", "H-A-01", "--expect", "3m",
        "--confirm", "1s", "--", sys.executable, str(root / "worker.py"), *tokens(),
    ]
    raise SystemExit(subprocess.run(command, cwd=root).returncode)
