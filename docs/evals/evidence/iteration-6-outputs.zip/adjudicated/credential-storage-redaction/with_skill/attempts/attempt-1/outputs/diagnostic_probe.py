"""Local verification harness; never edits the runtime or retained evidence."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

from synthetic_tokens import tokens


ROOT = Path(__file__).resolve().parent
RO = ROOT.parent / "skill" / "scripts" / "ro.py"
SESSION = os.environ.get("CODEX_THREAD_ID", "local-redaction-probe")
BASE = [sys.executable, str(RO), "--project", str(ROOT), "--slot", "A", "--session", SESSION]


def baseline():
    files = [ROOT / name for name in (
        "agents.md", "release-note.txt", "review.txt", "synthetic_tokens.py",
        "worker.py", "mock_archive.py",
    )]
    files += sorted((RO.parent).rglob("*.py"))
    data = {os.path.relpath(path, ROOT): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in files}
    (ROOT / "fixture-integrity-before.json").write_text(
        json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(f"Recorded integrity hashes for {len(files)} fixture/runtime files", flush=True)


def launch():
    run_dir = ROOT / "runs" / "credential-probe"
    run_dir.mkdir(parents=True, exist_ok=True)
    command = BASE + [
        "launch", "--item", "H-A-01", "--expect", "3m", "--run-dir", str(run_dir),
        "--bind", str(ROOT / "synthetic_tokens.py"), "--confirm", "1s", "--",
        sys.executable, str(ROOT / "worker.py"), *tokens(),
    ]
    return subprocess.run(command, cwd=ROOT, check=False).returncode


def external(action, mode):
    previous = (ROOT / "executions.log")
    if previous.exists() and mode in previous.read_text(encoding="utf-8").splitlines():
        raise RuntimeError(f"Refusing a repeated {mode} action")
    command = BASE + [
        "external", "--artifact", "release-note.txt", "--action", action, "--",
        sys.executable, str(ROOT / "mock_archive.py"), mode,
    ]
    return subprocess.run(command, cwd=ROOT, check=False).returncode


def report():
    probes = tokens()
    names = [f"synthetic_tokens.tokens()[{index}]" for index in range(len(probes))]

    def inspect(value):
        return {
            "complete_fake_string_absent": {
                name: probe not in value for name, probe in zip(names, probes)
            },
            "redaction_markers_present": "[REDACTED]" in value,
            "redaction_marker_count": value.count("[REDACTED]"),
        }

    registry_path = ROOT / ".ro" / "jobs.json"
    registry_raw = registry_path.read_bytes()
    registry = json.loads(registry_raw)
    job = next(entry for entry in registry if entry["id"] == "J-A-0001")
    external_results = {}
    for action, expected_code, expected_remote, diagnostic in (
        ("X-A-001", 0, "archive-accepted-482", "receipt stored; response complete"),
        ("X-A-002", 7, "archive-uncertain-731", "acknowledgement lost after acceptance; reconcile before retry"),
    ):
        path = ROOT / ".ro" / "external-results" / f"{action}.json"
        raw = path.read_bytes()
        record = json.loads(raw)
        remote_ids = re.findall(r"^remote-i<host-path-af043ff249d0>)", record["stdout"], re.MULTILINE)
        external_results[action] = {
            "path": path.relative_to(ROOT).as_posix(),
            "raw_sha256": hashlib.sha256(raw).hexdigest(),
            "raw_record_complete_fake_strings_absent": all(
                probe not in raw.decode("utf-8") for probe in probes),
            "stdout": inspect(record["stdout"]),
            "stderr": inspect(record["stderr"]),
            "remote_ids": remote_ids,
            "remote_id_preserved": remote_ids == [expected_remote],
            "exit_code": record["returncode"],
            "exit_code_preserved": record["returncode"] == expected_code,
            "diagnostic_message_preserved": diagnostic in record["stderr"],
            "start_error": record["start_error"],
            "stdout_omitted_chars": record["stdout_omitted_chars"],
            "stderr_omitted_chars": record["stderr_omitted_chars"],
        }

    integrity_before = json.loads((ROOT / "fixture-integrity-before.json").read_text(encoding="utf-8"))
    changed = [name for name, digest in integrity_before.items()
               if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    executions = (ROOT / "executions.log").read_text(encoding="utf-8").splitlines()
    log_path = Path(job["log"])
    worker = {
        "job_id": job["id"],
        "launch_confirmed": job["confirmed"],
        "arguments": "Both strings from synthetic_tokens.tokens(), passed as two unlabelled arguments",
        "stored_command": inspect(job["command"]),
        "status": job["status"],
        "outcome": job.get("outcome"),
        "ended": job.get("ended"),
        "monitor_active": job.get("monitor", {}).get("active"),
        "monitor_outcome": job.get("monitor", {}).get("reason"),
        "monitor_outcome_recorded": bool(job.get("outcome") and job.get("monitor", {}).get("ended")),
        "stdout_log": log_path.relative_to(ROOT).as_posix(),
        "ready_observed": "ready" in log_path.read_text(encoding="utf-8"),
    }
    stored_fields = [worker["stored_command"]]
    stored_fields += [result[stream] for result in external_results.values()
                      for stream in ("stdout", "stderr")]
    redaction_pass = all(
        all(field["complete_fake_string_absent"].values())
        and field["redaction_markers_present"]
        and field["redaction_marker_count"] == len(probes)
        for field in stored_fields)
    metadata_pass = all(result["remote_id_preserved"] and result["exit_code_preserved"]
                        and result["diagnostic_message_preserved"]
                        for result in external_results.values())
    execution_pass = executions == ["success", "failure"]
    worker_pass = (worker["launch_confirmed"] and worker["ready_observed"]
                   and worker["status"] == "killed" and worker["monitor_outcome_recorded"]
                   and worker["monitor_active"] is False)
    data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "result": "PASS" if redaction_pass and metadata_pass and execution_pass and worker_pass and not changed else "FAIL",
        "scope": "Exact complete synthetic strings in the raw jobs registry command and each retained external stdout/stderr field",
        "tokens": [
            {"source": name, "length": len(probe), "sha256": hashlib.sha256(probe.encode()).hexdigest()}
            for name, probe in zip(names, probes)
        ],
        "jobs_registry": {
            "path": registry_path.relative_to(ROOT).as_posix(),
            "raw_sha256": hashlib.sha256(registry_raw).hexdigest(),
            "raw_complete_fake_string_absent": inspect(registry_raw.decode("utf-8"))["complete_fake_string_absent"],
        },
        "worker": worker,
        "external_results": external_results,
        "execution_audit": {
            "path": "executions.log", "entries": executions,
            "X-A-001_executions": executions.count("success"),
            "X-A-002_executions": executions.count("failure"),
            "each_action_executed_once": execution_pass,
            "failing_action_retried": executions.count("failure") > 1,
        },
        "fixture_and_runtime_integrity": {
            "baseline_path": "fixture-integrity-before.json",
            "checked_files": len(integrity_before), "unchanged": not changed,
            "changed_files": changed,
        },
        "known_project_issues": [
            "Supplied agents.md lacks Read bound (settings.missing); fixtures were preserved.",
            "The two supplied ASCII-hyphen external-action headings trigger external.id.format when current Result times activate guard validation; supplied headings were preserved.",
        ],
    }
    destination = ROOT / "redaction-report.json"
    destination.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(f"{data['result']}: saved {destination.name}")
    return 0 if data["result"] == "PASS" else 1


if __name__ == "__main__":
    operation = sys.argv[1]
    if operation == "baseline":
        baseline()
    elif operation == "launch":
        raise SystemExit(launch())
    elif operation == "external":
        raise SystemExit(external(*sys.argv[2:]))
    elif operation == "report":
        raise SystemExit(report())
    else:
        raise SystemExit("Unknown operation")
