# external action order — Discoveries

## D-A-001 — Local diagnostic redaction retains operational evidence
- Source: A
- Host: local
- User: operator
- Date: 2026-10-26
- Session: codex:<withheld-id>@2026-10-26T14:10
- Cross-check: REVIEWING local (A)
- Finding: Both complete strings from synthetic_tokens.tokens() are absent from the raw stored worker command and from each retained stdout/stderr stream for X-A-001 and X-A-002; each checked field contains two redaction markers. Both remote IDs, action exit codes 0 and 7, and response diagnostics survive.
- Evidence: redaction-report.json; .ro/jobs.json; .ro/external-results/X-A-001.json; .ro/external-results/X-A-002.json; executions.log; fixture-integrity-before.json; diagnostic_probe.py. The execution log records success then failure exactly once; 20 fixture/runtime hashes remain unchanged. J-A-0001 was confirmed ready, stopped, and monitored with the recorded outcome job process tree killed.
- Implication: This local probe supports complete-string redaction in the tested storage fields; it does not establish coverage of other credential formats or storage locations. The failed response retains an uncertain acceptance ID and must not be retried.
- Reviews:
