# Shared queue — Plan

Active unfinished plan items only. Read `<skill-root>/references/plan-items.md` for item format, duplicate checks and priority; `<skill-root>/SKILL.md` for the item lifecycle; and `<skill-root>/references/workflow-unified.md` for ownership.

## Queue

### H-A-01 — Check the archive manifest against the release checklist
- Claimed: A since 2026-10-26 13:55
- Goal: Check the archive manifest against the release checklist.
- Evidence: brief.md specifies this sole work item. The current exercise stops after claim arbitration.
- Next test: Compare manifest entries against the release checklist and record mismatches; do not execute during this claim-only exercise.
