"""Run one claim-only race using the installed, unmodified ro CLI."""

import datetime as dt
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import re
import subprocess
import sys
import time


PROJECT = Path(__file__).resolve().parent
RO = PROJECT.parent / "skill" / "scripts" / "ro.py"
ITEM = "H-A-01"
SESSIONS = {"A": "shared-queue-Lee-A", "B": "shared-queue-Kim-B"}


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def snapshot():
    raw = (PROJECT / "plan.md").read_bytes()
    return {"path": "plan.md", "sha256": hashlib.sha256(raw).hexdigest(),
            "text": raw.decode("utf-8")}


def attempt(slot, barrier, readiness, results):
    args = [sys.executable, str(RO), "--project", str(PROJECT),
            "--session", SESSIONS[slot], "--slot", slot, "claim", ITEM]
    record = {"slot": slot, "session": SESSIONS[slot], "args": args,
              "worker_pid": os.getpid(), "ready_at": now(),
              "ready_monotonic_ns": time.monotonic_ns()}
    readiness.put(dict(record))
    try:
        barrier.wait(timeout=30)
        record.update(released_at=now(), started_monotonic_ns=time.monotonic_ns())
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        with subprocess.Popen(args, cwd=PROJECT, env=env, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, text=True, encoding="utf-8") as child:
            record["claim_pid"] = child.pid
            stdout, stderr = child.communicate(timeout=30)
            record.update(exit_code=child.returncode, stdout=stdout, stderr=stderr)
    except Exception as exc:
        record.update(exit_code=None, stdout="", stderr="", harness_error=repr(exc))
    record.update(finished_at=now(), finished_monotonic_ns=time.monotonic_ns())
    results.put(record)


def main():
    output = PROJECT / "contention.json"
    if output.exists():
        raise SystemExit("Refusing to overwrite the original contention evidence.")
    before = snapshot()
    if len(re.findall(r"^### H-", before["text"], re.M)) != 1:
        raise SystemExit("Expected exactly one queued item.")
    if not re.search(r"^### H-A-01 .+\n- Claimed: none$", before["text"], re.M):
        raise SystemExit("H-A-01 must initially be unclaimed.")
    ctx = mp.get_context("spawn")
    barrier = ctx.Barrier(3)
    readiness, results = ctx.Queue(), ctx.Queue()
    workers = [ctx.Process(target=attempt, args=(slot, barrier, readiness, results))
               for slot in ("A", "B")]
    for worker in workers:
        worker.start()
    ready = [readiness.get(timeout=30) for _ in workers]
    release_at, release_ns = now(), time.monotonic_ns()
    barrier.wait(timeout=30)
    attempts = sorted([results.get(timeout=45) for _ in workers], key=lambda r: r["slot"])
    for worker in workers:
        worker.join(timeout=5)
    after = snapshot()
    match = re.search(r"^- Claimed: ([AB]) since (.+)$", after["text"], re.M)
    owner = match.group(1) if match else None
    loser = next((slot for slot in SESSIONS if slot != owner), None) if owner else None
    success = [a for a in attempts if a["exit_code"] == 0]
    refusal = [a for a in attempts if a["exit_code"] == 1]
    nonclaim = lambda text: re.sub(r"^- Claimed: .+$", "- Claimed: <claim>", text, flags=re.M)
    checks = {
        "both_ready_before_release": all(a["ready_monotonic_ns"] <= release_ns for a in ready),
        "both_released_after_readiness": all(a.get("started_monotonic_ns", 0) >= release_ns for a in attempts),
        "separate_cli_processes": len({a.get("claim_pid") for a in attempts}) == 2,
        "attempt_intervals_overlap": max(a.get("started_monotonic_ns", 0) for a in attempts)
                                     < min(a["finished_monotonic_ns"] for a in attempts),
        "exactly_one_success": len(success) == 1,
        "exactly_one_refusal": len(refusal) == 1,
        "plan_owner_matches_success": len(success) == 1 and success[0]["slot"] == owner,
        "refusal_names_taken_owner": len(refusal) == 1 and f"claimed by taken slot {owner}" in refusal[0]["stderr"],
        "only_claim_line_changed": nonclaim(before["text"]) == nonclaim(after["text"]),
        "workers_exited_cleanly": all(w.exitcode == 0 for w in workers),
    }
    evidence = {
        "item": ITEM, "cwd": str(PROJECT), "procedure": "unmodified installed ro.py claim",
        "barrier": {"kind": "multiprocessing.Barrier", "parties": 3,
                    "ready": sorted(ready, key=lambda r: r["slot"]),
                    "release_requested_at": release_at, "release_requested_monotonic_ns": release_ns},
        "initial_plan": before, "attempts": attempts, "final_plan": after,
        "owner": owner, "loser": loser, "validation": checks,
        "item_started": False, "claim_released": False,
    }
    output.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"owner": owner, "loser": loser, "validation": checks,
                      "attempts": [{k: a[k] for k in ("slot", "claim_pid", "exit_code", "stdout", "stderr")}
                                   for a in attempts]}, indent=2))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
