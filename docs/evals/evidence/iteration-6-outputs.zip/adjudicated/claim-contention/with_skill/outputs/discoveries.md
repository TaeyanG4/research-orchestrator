# Shared queue — Discoveries

This file holds shared findings. At startup read its index (headings plus Finding/Status/Cross-check lines; `ro index`), then open matching entries on demand. Read `<skill-root>/references/records.md` when writing a record, `<skill-root>/SKILL.md` for the item lifecycle, and `<skill-root>/references/verification.md` when reviewing a finding (Verification `self`). In the work profile, preserve changed decisions, dead ends others should not retry, and verified facts others depend on; routine completions use the session event alone.

Discovery format:

```markdown
## D-A-001 — Short title
- Source: A
- Host: Claude Code
- User: kim
- Date: 2026-10-05
- Cross-check: PENDING
- Finding: ...
- Evidence: ...
- Implication: ...
- Reviews:
```
