# Shared queue contention

Create a local work-project named Shared queue with Workflow unified, Guards off, Verification self, Item size short and Git sync off. User Lee owns active slot A on Codex; user Kim owns active slot B on Claude. Both slots are taken, with distinct stable session identifiers. There is exactly one unclaimed item, H-A-01: check the archive manifest against the release checklist. Use this host's environment and English records. No worker or external action is needed.
