"""Record a blocked claim preflight; this is NOT a replacement claim implementation.

The supplied legacy skill has no work-item claim command. Two child processes
read the same unclaimed item, signal readiness, and await the parent's barrier.
Both then fail capability preflight without invoking or emulating a native claim.
"""

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def child(args):
    project = Path(args.project)
    # Follow the supplied skill's read order. These children do not edit files.
    records = {
        name: (project / name).read_text(encoding="utf-8")
        for name in ("agents.md", "discoveries.md", "handoff.md", "plan.md")
    }
    plan = (project / "plan.md").read_bytes()
    assert records["plan.md"].count("### H-") == 1
    assert f"### {args.item} — " in records["plan.md"]
    assert "- Claim: unclaimed\n" in records["plan.md"]
    assert "- Owner: none\n" in records["plan.md"]
    own_slot = records["handoff.md"].split(f"### Agent: {args.slot}\n", 1)[1]
    own_slot = own_slot.split("\n### ", 1)[0].split("\n## ", 1)[0]
    assert f"- Current host: {args.host}\n" in own_slot
    assert f"- Current user: {args.user}\n" in own_slot
    assert f"- Current session: {args.session_id}\n" in own_slot
    print(json.dumps({
        "event": "ready", "pid": os.getpid(), "slot": args.slot,
<withheld internal metadata>
        "observed_claim": "unclaimed", "plan_sha256": digest(plan),
        "at_utc": timestamp(), "monotonic_ns": time.monotonic_ns(),
    }), flush=True)
    if sys.stdin.readline() != "GO\n":
        print("Barrier was not released; no claim invoked.", file=sys.stderr)
        return 3
    print(json.dumps({
        "event": "barrier_passed", "pid": os.getpid(), "slot": args.slot,
        "at_utc": timestamp(), "monotonic_ns": time.monotonic_ns(),
    }), flush=True)
    scripts = sorted(path.name for path in (Path(args.skill_root) / "scripts").glob("*.py"))
    if scripts != ["check_project.py", "init_research_orchestrator.py"]:
        print("Skill inventory changed; inspect it before claiming. No claim invoked.", file=sys.stderr)
        return 3
    print(
        f"UNSUPPORTED_CLAIM_PROCEDURE: slot {args.slot} cannot claim {args.item}. "
        "The supplied SKILL.md documents per-agent research queues, discovery-review "
        "claims, and heavy-compute claims, but no unified work-item claim procedure. "
        "The only bundled Python tools are init_research_orchestrator.py and "
        "check_project.py. Native claim command unavailable; no native claim was "
        "invoked, no ownership was assigned, and the item was not started.",
        file=sys.stderr,
    )
    return 2


def run(args):
    project = Path(args.project).resolve()
    skill = Path(args.skill_root).resolve()
    before = (project / "plan.md").read_bytes()
    records = []
    processes = []
    barrier = {"kind": "parent-controlled stdin readiness barrier", "ready": []}
    try:
        for slot, user, host in (("A", "Lee", "Codex"), ("B", "Kim", "Claude")):
            session = f"shared-queue-{slot}-{user}-{host}"
            command = [
                sys.executable, str(Path(__file__).resolve()), "--child",
                "--project", str(project), "--skill-root", str(skill),
                "--slot", slot, "--user", user, "--host", host,
                "--session-id", session, "--item", "H-A-01",
            ]
            process = subprocess.Popen(
                command, cwd=project, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, text=True, encoding="utf-8",
            )
            processes.append(process)
            records.append({
<withheld internal metadata>
                "requested_operation": "claim", "requested_item": "H-A-01",
                "actual_operation": "capability_preflight_only",
                "arguments": command, "pid": process.pid,
                "native_claim_arguments": None, "native_claim_invoked": False,
            })
        with ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(process.stdout.readline) for process in processes]
            ready_lines = [future.result(timeout=15) for future in futures]
            for record, line in zip(records, ready_lines):
                ready = json.loads(line)
                assert ready["event"] == "ready"
                assert ready["plan_sha256"] == digest(before)
                assert ready["slot"] == record["slot"]
                barrier["ready"].append(ready)
            assert processes[0].pid != processes[1].pid
            barrier["both_ready_before_release"] = True
            barrier["released_at_utc"] = timestamp()
            barrier["released_monotonic_ns"] = time.monotonic_ns()
            completed = [pool.submit(process.communicate, input="GO\n", timeout=15)
                         for process in processes]
            for record, process, line, future in zip(records, processes, ready_lines, completed):
                stdout, stderr = future.result(timeout=20)
                record.update(exit_code=process.returncode, stdout=line + stdout, stderr=stderr)
    finally:
        for process in processes:
            if process.poll() is None:
                process.kill()
                process.communicate()

    after = (project / "plan.md").read_bytes()
    assert before == after, "A preflight must not mutate the plan"
    checker_command = [sys.executable, str(skill / "scripts" / "check_project.py"), str(project)]
    checker = subprocess.run(checker_command, capture_output=True, text=True, encoding="utf-8")
    help_command = [sys.executable, str(skill / "scripts" / "init_research_orchestrator.py"), "--help"]
    help_result = subprocess.run(help_command, capture_output=True, text=True, encoding="utf-8")
    result = {
        "status": "blocked_incompatible_skill",
        "scope": "Two real process preflights; native claim contention could not be exercised.",
        "generated_at_utc": timestamp(), "project_directory": str(project),
        "skill_root": str(skill), "python_executable": sys.executable,
        "skill_sha256": digest((skill / "SKILL.md").read_bytes()),
        "skill_script_inventory": sorted(str(p.relative_to(skill)) for p in (skill / "scripts").glob("*.py")),
        "requested_settings": {
            "name": "Shared queue", "project_type": "work", "workflow": "unified",
            "guards": "off", "verification": "self", "item_size": "short", "git_sync": "off",
            "environment": "Windows / PowerShell", "record_language": "English",
        },
        "settings_support": "Work-project settings recorded manually; not implemented by this skill version.",
        "barrier": barrier, "attempts": records,
        "outcome": {
            "item": "H-A-01", "owner": None, "successful_claims": 0,
            "native_claim_attempts_executed": 0, "item_started": False,
            "claims_released": False,
            "reason": "Neither slot can obtain a normal claim: the required procedure is absent from the supplied skill.",
        },
        "evidence": {
            "plan_before_sha256": digest(before), "plan_final_sha256": digest(after),
            "plan_unchanged_by_processes": before == after,
            "plan_before": before.decode("utf-8"), "plan_final": after.decode("utf-8"),
        },
        "initializer_help": {
            "arguments": help_command, "exit_code": help_result.returncode,
            "stdout": help_result.stdout, "stderr": help_result.stderr,
        },
        "legacy_consistency_check": {
            "arguments": checker_command, "exit_code": checker.returncode,
            "stdout": checker.stdout, "stderr": checker.stderr,
            "interpretation": "Legacy research checker cannot validate the requested unified work queue; failures retained as evidence.",
        },
    }
    (project / "contention.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "owner": None,
                      "preflight_exit_codes": [r["exit_code"] for r in records],
                      "evidence": "contention.json", "plan_unchanged": before == after}))
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--child", action="store_true")
    parser.add_argument("--project", default=".")
    parser.add_argument("--skill-root", required=True)
    for option in ("slot", "user", "host", "session-id", "item"):
        parser.add_argument("--" + option)
    options = parser.parse_args()
    sys.exit(child(options) if options.child else run(options))
