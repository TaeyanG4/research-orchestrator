# Shared queue — Plan

### H-A-01 — Check the archive manifest against the release checklist
- Status: queued
- Owner: none
- Claim: unclaimed
- Claim session: none
- Started: no
- Sources: brief.md
- Goal: Check the archive manifest against the release checklist.
- Next action: Claim through the skill's normal procedure when a compatible local version is available; do not begin this item in this task.

## Agent: A

_No claimed items._

## Agent: B

_No claimed items._
