"""Review supplied observations and prepare local fixtures without running hosts.

Run with the specified Python executable and -B. Exit 1 means the supplied
Codex evidence did not pass the helper's aggregate capability gate.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch


PROJECT = Path(__file__).resolve().parent
CHECKOUT = Path(r"<host-path-b599a19e9655>")
SKILL = PROJECT.parent / "skill"
sys.dont_write_bytecode = True
sys.path.insert(0, str(CHECKOUT))

from scripts.host import dryrun

sys.path.insert(0, str(SKILL / "scripts"))
import ro_hook_runner


def local_path(path: Path) -> str:
    return path.relative_to(PROJECT).as_posix()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@contextmanager
def diagnostics_environment_filtered():
    original = os.environ.pop("RO_HOOK_DIAGNOSTICS", None)
    try:
        yield
    finally:
        if original is not None:
            os.environ["RO_HOOK_DIAGNOSTICS"] = original


def inspect_fixture(project: Path, setup: dict) -> dict:
    jobs = json.loads((project / ".ro" / "jobs.json").read_text(encoding="utf-8"))
    job = jobs[0]
    return {
        "project": local_path(project),
        "environment": setup["environment"],
        "bound_input": local_path(project / "run" / "input.txt"),
        "bound_input_preserved": (project / "run" / "input.txt").read_text(
            encoding="utf-8"
        ) == "synthetic dry-run input\n",
        "synthetic_job_uses_review_process_identity": (
            job["pid"] == os.getpid() and bool(job["start"])
        ),
        "job_process_launched": False,
        "registry_note": (
            "Synthetic registry borrows the review process PID/start identity. "
            "It becomes stale when this review exits; prepare a fresh fixture "
            "before any later live probe."
        ),
        "codex_config_directory_exists": (project / ".codex").exists(),
        "claude_config_directory_exists": (project / ".claude").exists(),
        "diagnostics_marker_exists": (project / ".ro" / "hook-diagnostics.on").is_file(),
    }


def main() -> int:
    input_file = PROJECT / "observations.json"
    observations = json.loads(input_file.read_text(encoding="utf-8-sig"))
    probes = {probe.name: probe for probe in dryrun.probes("powershell")}
    results = []
    for row in observations:
        probe = probes[row["probe"]]
        observed = dryrun.summarize_codex(
            probe, row["decisions"], row["side_effects"],
            row["status"], row["tool_calls"]
        )
        results.append({
            "id": row["id"],
            "probe": probe.name,
            "expected": probe.expected,
            "observed": observed,
            "passed": row["status"] == "completed" and observed == probe.expected,
            "status": row["status"],
            "evidence": {
                "decisions": row["decisions"],
                "side_effects": row["side_effects"],
                "tool_calls": row["tool_calls"],
            },
        })

    # Apply the two conditions from dryrun.main's Codex aggregate gate.
    aggregate_passed = (
        all(result["status"] == "completed" for result in results)
        and all(result["observed"] == result["expected"] for result in results)
    )
    aggregate_exit_status = 0 if aggregate_passed else 1

    probe_root = Path(tempfile.mkdtemp(prefix="offline-probes-", dir=PROJECT))
    codex_project = probe_root / "codex"
    claude_project = probe_root / "claude-control"
    # prepare_project only seeds files and obtains this process's identity.
    # Guard subprocess.run in case future helper changes add process execution.
    with patch.object(dryrun.subprocess, "run", side_effect=AssertionError(
        "Offline review must not launch a subprocess"
    )):
        codex_setup = dryrun.prepare_project(
            codex_project, "codex", dryrun.environment("codex"), repo=CHECKOUT
        )
        claude_setup = dryrun.prepare_project(
            claude_project, "claude", dryrun.environment("claude"), repo=CHECKOUT
        )

    codex_fixture = inspect_fixture(codex_project, codex_setup)
    sample = json.loads((CHECKOUT / "hooks" / "codex-hooks.sample.json").read_text(
        encoding="utf-8"
    ))
    for declarations in sample["hooks"].values():
        for declaration in declarations:
            for hook in declaration["hooks"]:
                for key in ("command", "commandWindows"):
                    hook[key] = hook[key].replace(
                        "/absolute/path/to/plugin", CHECKOUT.resolve().as_posix()
                    )
    actual = json.loads((codex_project / ".codex" / "hooks.json").read_text(
        encoding="utf-8"
    ))
    codex_fixture.update({
        "hooks_file": local_path(codex_project / ".codex" / "hooks.json"),
        "hooks_match_sample_with_only_plugin_path_replaced": actual == sample,
        "config_toml_is_empty": (codex_project / ".codex" / "config.toml").read_bytes() == b"",
        "diagnostics_marker": local_path(codex_project / ".ro" / "hook-diagnostics.on"),
        "diagnostics_marker_is_empty": (
            codex_project / ".ro" / "hook-diagnostics.on"
        ).read_bytes() == b"",
        "diagnostics_log_when_hooks_run": local_path(
            codex_project / ".ro" / "hook-diagnostics.jsonl"
        ),
        "diagnostics_log_created": (codex_project / ".ro" / "hook-diagnostics.jsonl").exists(),
    })

    claude_fixture = inspect_fixture(claude_project, claude_setup)
    try:
        dryrun.environment("claude", "powershell")
    except ValueError as error:
        claude_fixture["powershell_rejected"] = True
        claude_fixture["powershell_rejection_reason"] = str(error)
    else:
        claude_fixture["powershell_rejected"] = False

    with diagnostics_environment_filtered():
        assert "RO_HOOK_DIAGNOSTICS" not in os.environ
        codex_fixture["diagnostics_enabled_without_environment_variable"] = (
            ro_hook_runner.diagnostics_enabled(codex_project)
        )
        codex_fixture["diagnostics_enabled_from_run_subdirectory"] = (
            ro_hook_runner.diagnostics_enabled(codex_project / "run")
        )
        claude_fixture["diagnostics_enabled_without_environment_variable"] = (
            ro_hook_runner.diagnostics_enabled(claude_project)
        )

    codex_fixture["passed"] = all((
        codex_fixture["environment"] == "windows/powershell",
        codex_fixture["bound_input_preserved"],
        codex_fixture["synthetic_job_uses_review_process_identity"],
        codex_fixture["hooks_match_sample_with_only_plugin_path_replaced"],
        codex_fixture["config_toml_is_empty"],
        codex_fixture["diagnostics_marker_is_empty"],
        codex_fixture["diagnostics_enabled_without_environment_variable"],
        codex_fixture["diagnostics_enabled_from_run_subdirectory"],
        not codex_fixture["claude_config_directory_exists"],
        not codex_fixture["diagnostics_log_created"],
    ))
    claude_fixture["passed"] = all((
        claude_fixture["environment"] == "windows/bash",
        claude_fixture["bound_input_preserved"],
        claude_fixture["synthetic_job_uses_review_process_identity"],
        not claude_fixture["codex_config_directory_exists"],
        not claude_fixture["claude_config_directory_exists"],
        not claude_fixture["diagnostics_marker_exists"],
        not claude_fixture["diagnostics_enabled_without_environment_variable"],
        claude_fixture["powershell_rejected"],
    ))
    assert codex_fixture["passed"], codex_fixture
    assert claude_fixture["passed"], claude_fixture

    counts = {
        "total": len(results),
        "passed": sum(result["passed"] for result in results),
        "failed": sum(not result["passed"] for result in results),
        "not_blocked": sum(result["observed"].startswith("not blocked") for result in results),
        "inconclusive": sum(result["observed"].startswith("unknown/inconclusive") for result in results),
    }
    report = {
        "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
        "verification_type": "offline supplied-observation classification and local fixture inspection",
        "live_host_verification": False,
        "hosts_launched": [],
        "input": {"file": "observations.json", "sha256": digest(input_file)},
        "method": {
            "checkout": str(CHECKOUT),
            "helper": str(Path(dryrun.__file__).resolve()),
            "helper_sha256": digest(Path(dryrun.__file__)),
            "classifier": "scripts.host.dryrun.summarize_codex",
            "expected_outcomes": "scripts.host.dryrun.probes('powershell')",
            "fixture_preparation": "scripts.host.dryrun.prepare_project",
            "diagnostics_check": "supplied skill scripts/ro_hook_runner.py:diagnostics_enabled",
            "aggregate_rule": (
                "0 only when every row has status completed and observed equals expected; otherwise 1. "
                "This is the Codex gate in dryrun.main, applied to all supplied rows without launching main."
            ),
            "reproduce": '"' + sys.executable + '" -B review_evidence.py',
        },
        "results": results,
        "summary": counts,
        "aggregate_passed": aggregate_passed,
        "aggregate_exit_status": aggregate_exit_status,
        "diagnostics": {
            "persistent_enable_file": ".ro/hook-diagnostics.on",
            "output_file": ".ro/hook-diagnostics.jsonl",
            "environment_alternative": "RO_HOOK_DIAGNOSTICS=1",
            "verification": (
                "The supplied runner's diagnostics_enabled function returned true for the prepared "
                "Codex project and its run subdirectory with RO_HOOK_DIAGNOSTICS removed. "
                "The Claude control returned false. No hook event was dispatched."
            ),
        },
        "fixtures": {"codex": codex_fixture, "claude_control": claude_fixture},
        "conclusion": (
            "The supplied Codex evidence does not pass the installation gate. "
            "Two rows show execution or deletion despite a denial and five are inconclusive. "
            "The two passing observations and successful local fixture checks do not establish "
            "live Codex or Claude hook delivery or enforcement. No hosts, jobs, or hook runners were launched."
        ),
    }
    output = PROJECT / "evidence-review.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "report": local_path(output),
        "summary": counts,
        "aggregate_exit_status": aggregate_exit_status,
        "probe_projects": local_path(probe_root),
        "codex_fixture_passed": codex_fixture["passed"],
        "claude_control_passed": claude_fixture["passed"],
        "live_host_verification": False,
    }, indent=2))
    return aggregate_exit_status


if __name__ == "__main__":
    raise SystemExit(main())
