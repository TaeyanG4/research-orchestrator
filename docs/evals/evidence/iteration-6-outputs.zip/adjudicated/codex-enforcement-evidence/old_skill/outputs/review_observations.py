"""Review offline evidence using the checkout helper; never launch either host.

Exit status is the Codex capability gate (1 for the supplied observations).
Disposable fixtures remain in this project for inspection. Their synthetic job
entries borrow this Python process's identity and become stale when it exits.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

sys.dont_write_bytecode = True
PROJECT = Path(__file__).resolve().parent
CHECKOUT = Path(r"<host-path-b599a19e9655>")
sys.path.insert(0, str(CHECKOUT))
sys.path.insert(0, str(CHECKOUT / "skills" / "research-orchestrator-skill" / "scripts"))

from scripts.host import dryrun
import ro_hook_runner
import ro_hooks
from ro_state import Project


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    return path.relative_to(PROJECT).as_posix()


def inspect_fixture(base: Path, host: str) -> dict:
    root = base / host
    declared = dryrun.environment(host)
    configured = dryrun.prepare_project(root, host, declared, repo=CHECKOUT)
    shell = declared.split("/")[1]
    job = configured["job"]
    stored = json.loads((root / ".ro" / "jobs.json").read_text(encoding="utf-8"))
    checks = {
        "input_is_synthetic": (root / "run" / "input.txt").read_text(encoding="utf-8")
        == "synthetic dry-run input\n",
        "registry_matches_preparation": stored == [job],
        "registry_borrows_current_python_pid": job["pid"] == os.getpid() and bool(job["start"]),
        "bound_input_matches_fixture": job["bound"] == [str(root / "run" / "input.txt")],
        "environment_matches_host": declared == ("windows/powershell" if host == "codex" else "windows/bash"),
    }
    enabled = ro_hook_runner.diagnostics_enabled(root)
    local_checks = []
    for probe in dryrun.probes(shell):
        # Parse the literal command as data. Never run it in a shell or host.
        payload = {
            "cwd": str(root),
            "tool_name": "PowerShell" if shell == "powershell" else "Bash",
            "tool_input": {"command": probe.command},
        }
        response = ro_hooks.hook(Project(root), "PreToolUse", payload)
        specific = response.get("hookSpecificOutput", {})
        if specific.get("permissionDecision") == "deny":
            decision = "denied"
            check_matches = probe.check in specific.get("permissionDecisionReason", "")
        elif specific.get("additionalContext"):
            decision = "warned"
            check_matches = probe.check in specific["additionalContext"]
        else:
            decision = "no hook decision"
            check_matches = probe.check is None and response == {}
        passed = decision == probe.expected and check_matches
        local_checks.append({
            "probe": probe.name,
            "expected_runner_decision": probe.expected,
            "observed_runner_decision": decision,
            "target_check": probe.check,
            "passed": passed,
            "response": response,
        })
        if host == "codex":
            # Exercise the diagnostic writer directly, without launching a host
            # or executing the probe's tool command.
            ro_hook_runner.finished(Project(root), "PreToolUse", response, 0)
    checks["local_adapter_decisions_match"] = all(row["passed"] for row in local_checks)

    if host == "codex":
        sample = json.loads((CHECKOUT / "hooks" / "codex-hooks.sample.json").read_text(encoding="utf-8"))
        for declarations in sample["hooks"].values():
            for declaration in declarations:
                for hook in declaration["hooks"]:
                    for key in ("command", "commandWindows"):
                        hook[key] = hook[key].replace("/absolute/path/to/plugin", CHECKOUT.resolve().as_posix())
        diagnostic_path = root / ".ro" / "hook-diagnostics.jsonl"
        diagnostics = dryrun.parse_diagnostics(diagnostic_path.read_text(encoding="utf-8"))
        expected_diagnostics = [
            (probe.expected, [probe.check] if probe.check else [])
            for probe in dryrun.probes(shell)
        ]
        checks.update({
            "sample_hooks_preserved_except_checkout_path": configured["hooks"] == sample
            == json.loads((root / ".codex" / "hooks.json").read_text(encoding="utf-8")),
            "codex_config_empty": (root / ".codex" / "config.toml").read_bytes() == b"",
            "diagnostic_marker_present_and_empty": (root / ".ro" / "hook-diagnostics.on").read_bytes() == b"",
            "diagnostics_enabled_without_environment_flag": enabled,
            "diagnostics_written_without_environment_flag": [
                (row["decision"], row["checks"]) for row in diagnostics
            ] == expected_diagnostics,
        })
    else:
        checks.update({
            "no_claude_project_configuration": not (root / ".claude").exists(),
            "no_codex_project_configuration": not (root / ".codex").exists(),
            "no_diagnostic_marker": not (root / ".ro" / "hook-diagnostics.on").exists(),
            "diagnostics_disabled_without_environment_flag": not enabled,
            "no_host_hooks_installed_in_fixture": configured["hooks"] is None,
        })
    assert all(checks.values()), (host, checks)
    return {
        "project": relative(root),
        "environment": declared,
        "passed": all(checks.values()),
        "checks": checks,
        "local_adapter_checks": local_checks,
        "scope": "Offline fixture and local adapter checks; no tool commands or host executables were run.",
        "registry_lifetime": "Synthetic job borrows review Python PID/start identity; stale after this script exits.",
    }


def main() -> int:
    input_path = PROJECT / "observations.json"
    observations = json.loads(input_path.read_text(encoding="utf-8"))
    cases = {probe.name: probe for probe in dryrun.probes("powershell")}
    results = []
    for row in observations:
        probe = cases[row["probe"]]
        observed = dryrun.summarize_codex(
            probe, row["decisions"], row["side_effects"], row["status"], row["tool_calls"]
        )
        results.append({
            "id": row["id"],
            "probe": probe.name,
            "expected": probe.expected,
            "observed": observed,
            "passed": row["status"] == "completed" and observed == probe.expected,
            "status": row["status"],
            "decisions": row["decisions"],
            "side_effects": row["side_effects"],
            "tool_calls": row["tool_calls"],
        })
    # Reproduce dryrun.main's Codex gate; do not call main, which launches hosts.
    all_passed = all(row["status"] == "completed" for row in results) and all(
        row["observed"] == row["expected"] for row in results
    )
    exit_status = 0 if all_passed else 1
    base = Path(tempfile.mkdtemp(prefix="disposable-hook-probes-", dir=PROJECT)).resolve()
    prior_diagnostic_flag = os.environ.pop("RO_HOOK_DIAGNOSTICS", None)
    try:
        fixtures = {host: inspect_fixture(base, host) for host in ("codex", "claude")}
    finally:
        if prior_diagnostic_flag is not None:
            os.environ["RO_HOOK_DIAGNOSTICS"] = prior_diagnostic_flag
    helper_path = Path(dryrun.__file__).resolve()
    report = {
        "review_type": "offline-observation-review",
        "input": {"path": "observations.json", "sha256": digest(input_path)},
        "helper": {
            "path": str(helper_path),
            "sha256": digest(helper_path),
            "classification_function": "scripts.host.dryrun.summarize_codex",
            "fixture_function": "scripts.host.dryrun.prepare_project",
            "exit_rule": "0 only when every status is completed and every observed result equals its expected outcome; otherwise 1.",
        },
        "live_host_verification": False,
        "hosts_launched": [],
        "installation_working_established": False,
        "scope": "Supplied offline observations plus local synthetic fixtures and adapter checks. No Codex or Claude invocation, host version check, network access, or home configuration changes.",
        "results": results,
        "summary": {
            "total": len(results),
            "passed": sum(row["passed"] for row in results),
            "failed": sum(not row["passed"] for row in results),
            "all_passed": all_passed,
        },
        "aggregate_process_exit_status": exit_status,
        "aggregate_exit_status_basis": "Expected Codex helper gate for these observations, computed offline; no live helper host run occurred.",
        "diagnostics": {
            "enable_marker": ".ro/hook-diagnostics.on",
            "prepared_marker": relative(base / "codex" / ".ro" / "hook-diagnostics.on"),
            "environment_flag": "RO_HOOK_DIAGNOSTICS=1",
            "environment_flag_present_during_fixture_checks": False,
            "diagnostic_output": ".ro/hook-diagnostics.jsonl",
            "prepared_output": relative(base / "codex" / ".ro" / "hook-diagnostics.jsonl"),
            "explanation": "The empty project marker enables diagnostics independently of inherited environment variables. The JSONL file records decisions; it is not the enable switch.",
            "output_provenance": "Written by direct local calls to ro_hook_runner.finished using local adapter responses; not captured from a live host.",
        },
        "fixtures": fixtures,
    }
    output = PROJECT / "evidence-review.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "summary": report["summary"],
                      "aggregate_process_exit_status": exit_status,
                      "fixture_root": relative(base)}, indent=2))
    return exit_status


if __name__ == "__main__":
    raise SystemExit(main())
