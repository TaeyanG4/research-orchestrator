# Direction review — 2026-10-26

Slot A; user operator; host local. Completed review: H-A-06. Finding: D-A-006.

Decision: **PIVOT**. Pause threshold-tuning and retire H-A-06 without executing its proposed adjustment. Allocate the one next experiment to **H-A-07: a standalone count-distribution representation with a regularized linear decision rule**. This session performs evidence analysis and queue maintenance only.

The five supplied attempts are comparable: all use I-A-01 and cohort `current`. Their errors are 0.400, 0.401, 0.399, 0.400 and 0.400. The mean is 0.400 and the entire range is 0.002, one fifth of the declared ±0.01 resolution. Five attempts have produced no resolvable improvement from this family. Another small threshold change preserves its information-losing representation and offers little decision value. This is an effort-allocation decision; the observations do not establish that every threshold has identical true error.

I-A-01 is declared independent and held-out, with rank agreement 0.90 against a broader historical review. Those are supplied instrument properties; the underlying calibration records, sample size and paired predictions are absent. Rank agreement supports broad comparisons but does not establish sensitivity to 0.001 changes. The ±0.01 resolution is not a supplied confidence interval. The 0.399 minimum is an observed reference, and its superiority over 0.400 remains unresolved. All five original discoveries remain PENDING; this direction review also remains PENDING for an eligible independent review.

The target remains consequential:

| Quantity | Error units | Meaning |
| --- | ---: | --- |
| Observed minimum | 0.399 | D-A-003; no resolved winner among the five |
| Target | ≤0.350 | Independent review instrument |
| Gap from observed minimum | 0.049 | 4.9 percentage points, about 12.3% relative reduction needed |
| Full threshold range | 0.002 | Too small for the present instrument to resolve |
| Published method score | about 0.360 | Different sample; motivation for a local baseline |

Even if the published score transferred, 0.360 would still leave a 0.010 measured gap. The method is a useful test because the count distribution retains information discarded by a single threshold. Its local benefit and ability to meet the target are untested. The next experiment should establish this standalone family before considering combinations or tuning variants.

The source audit in methods.md localizes the target gap. Equal source counts give `0.5 × 0.30 + 0.5 × 0.50 = 0.40`. Alpha contributes 0.15 and beta 0.25 to aggregate error; beta accounts for 62.5% of current weighted errors. With alpha fixed at 0.30, reaching 0.35 requires beta to fall from 0.50 to 0.40. These component values describe the supplied source audit; per-source values for threshold attempt 3 were not supplied. Acquisition source is an observed performance split, and the cause of beta's higher error is unresolved. Independently assigned targets and the fixed equal mixture remain the basis of evaluation.

H-A-07's bounded protocol is recorded in plan.md:

1. Establish the record-level training data, fixed split IDs, independent review labels and source tags, and the frozen threshold reference's predictions. Only summary files are present in this case. Predeclare the count representation, preprocessing and regularization using training data or a separate training-side validation split; the local note describes a family without a full implementation specification.
2. Fit one frozen standalone count-distribution plus regularized linear baseline. Keep the review cohort, labels, source weights and error metric fixed. Use the held-out instrument once for the candidate comparison.
3. Report overall error, alpha and beta errors, counts, the paired difference from the frozen reference where available, uncertainty, and the residual gap to 0.35. A reduction greater than 0.01 is a useful screening requirement, with uncertainty supporting its sign before claiming improvement. A difference at or below resolution remains inconclusive. Component estimates need their own uncertainty; ±0.01 for the aggregate does not establish subgroup resolution. Report measured target attainment separately from uncertainty near the boundary.

An overall improvement supported at the instrument's resolution earns further consideration. A tiny apparent gain, an unresolved difference, or deterioration ends this bounded test without an automatic tuning series. A beta gain that is offset elsewhere must be judged by the fixed overall metric. Reopen threshold-tuning only when new error evidence or a calibrated instrument supplies a materially different, decision-changing test.

H-A-06's revised priority is 4: Impact 0, Information 1, Confidence 0, Unblock 0, Diversity 0, Cost 1. It is removed after the review. H-A-07 scores 19: Impact 3, Information 3, Confidence 1, Unblock 2, Diversity 3, Cost 2. Low confidence reflects the absence of a local standalone result; its priority comes from the target gap and information gained by testing an unexplored representation. No additional experiments are queued.

Historical evidence is preserved in results/direction_review/initial_inputs.json with SHA-256 hashes. results/history.csv, methods.md and agents.md remain byte-for-byte unchanged. The five discovery records retain every original field value, date, attribution and verification state; extended metadata is nested under Evidence to match the supplied checker's core format. The supplied skill has no referenced modules and its checker emits a generated-rules advisory. These compatibility limits are recorded without replacing project rules.

Arithmetic and preservation checks are reproducible with:

```powershell
& '<host-path-1d5ebf570ab0>' 'results/direction_review/audit_evidence.py' --check-log checker_final.txt
```

The audit writes metrics.json and invokes the supplied checker. Startup and normalized checker outputs are preserved alongside the final output. No candidate score is added to history in this session.

Final validation: preservation audit passed; checker exit code 0, with one active plan item, six discoveries and two events. The generated-rules advisory remains documented. Slot A is released; H-A-07 remains unexecuted.
