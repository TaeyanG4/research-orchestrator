# Method comparison — Discoveries

## D-A-001 — Threshold attempt 1
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 1 measured error 0.400 on the current cohort.
- Evidence: results/history.csv row 1 records the independent I-A-01 measurement.
  - Decision class: model-change
  - Instrument: I-A-01
  - Result: error=0.400 on I-A-01 cohort current
  - Family: threshold-tuning
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:

## D-A-002 — Threshold attempt 2
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 2 measured error 0.401 on the current cohort.
- Evidence: results/history.csv row 2 records the independent I-A-01 measurement.
  - Decision class: model-change
  - Instrument: I-A-01
  - Result: error=0.401 on I-A-01 cohort current
  - Family: threshold-tuning
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:

## D-A-003 — Threshold attempt 3
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 3 measured error 0.399 on the current cohort.
- Evidence: results/history.csv row 3 records the independent I-A-01 measurement.
  - Decision class: model-change
  - Instrument: I-A-01
  - Result: error=0.399 on I-A-01 cohort current
  - Family: threshold-tuning
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:

## D-A-004 — Threshold attempt 4
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 4 measured error 0.400 on the current cohort.
- Evidence: results/history.csv row 4 records the independent I-A-01 measurement.
  - Decision class: model-change
  - Instrument: I-A-01
  - Result: error=0.400 on I-A-01 cohort current
  - Family: threshold-tuning
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:

## D-A-005 — Threshold attempt 5
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 5 measured error 0.400 on the current cohort.
- Evidence: results/history.csv row 5 records the independent I-A-01 measurement.
  - Decision class: model-change
  - Instrument: I-A-01
  - Result: error=0.400 on I-A-01 cohort current
  - Family: threshold-tuning
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:

## D-A-006 — Direction review pauses threshold tuning and prioritizes a standalone family
- Source: A
- Host: local
- User: operator
- Date: 2026-10-26
- Cross-check: PENDING
- Finding: Five comparable threshold attempts show no improvement resolved by I-A-01; the next experiment should test the unbuilt standalone count-distribution plus regularized linear family, with source beta as a diagnostic focus.
- Evidence: D-A-001 through D-A-005 and results/history.csv report errors 0.400, 0.401, 0.399, 0.400 and 0.400 on I-A-01/current: range 0.002 and mean 0.400 against the supplied ±0.01 resolution. The observed minimum misses the ≤0.35 target by 0.049. The original discoveries remain PENDING; this is a source analysis, not an independent cross-check.
  - Decision class: direction-review
  - Decision: PIVOT
  - Family: threshold-tuning
  - Instrument: I-A-01
  - Instrument limits: supplied independent held-out provenance and rank agreement 0.90 support broad comparisons; sample size, paired predictions and resolution calibration records are unavailable. Small score differences cannot establish a winner or significance.
  - Alternative: methods.md describes an unbuilt standalone count-distribution representation and regularized linear rule. Its reported error about 0.36 comes from another sample and is not a local result; even transfer at that level leaves 0.01 to target.
  - Target-gap diagnosis: methods.md gives equal source weights, alpha error 0.30 and beta error 0.50, hence overall 0.40. Beta contributes 0.25 of overall error (62.5% of weighted errors). If alpha stays at 0.30, beta must reach 0.40 to reach overall 0.35. These are source-audit figures, not a per-source breakdown for attempt 3; the mechanism of beta's higher error remains untested.
  - Reproduction: direction_review.md; results/direction_review/audit_evidence.py; results/direction_review/metrics.json; original inputs and hashes in results/direction_review/initial_inputs.json.
  - Queue decision: retire H-A-06 at revised priority 4 and queue only H-A-07 at priority 19. No candidate has been implemented, fitted or scored in this session.
- Implication: Pause small threshold adjustments; H-A-07 should establish a standalone local baseline on the unchanged independent cohort, report the overall target gap and source-specific errors, and interpret differences against instrument resolution and paired uncertainty. Reopen threshold-tuning only with a materially new mechanism or calibrated measurement evidence that changes its decision value.
- Reviews:
