# competition direction review — Plan

## Agent: A

### H-A-07 — Establish a standalone count-distribution and regularized linear baseline
- Sources: D-A-001, D-A-002, D-A-003, D-A-004, D-A-005, D-A-006
- Hypothesis: A count-distribution representation followed by a regularized linear decision rule can retain useful information discarded by thresholding, producing a resolvable reduction in overall error and revealing whether source beta's gap can be reduced.
- Evidence: All cited discoveries are PENDING and have not received an independent cross-check. The five comparable threshold scores have a 0.002 range (0.399–0.401), below I-A-01's ±0.01 resolution; the best observed error misses the ≤0.35 target by 0.049. methods.md describes the unbuilt standalone family; its reported ~0.36 on another sample motivates the test without establishing local benefit. The equal-weight source audit gives alpha 0.30 and beta 0.50; with alpha unchanged, beta must reach 0.40 for overall 0.35.
  - Claimed: none
  - Family: count-distribution-linear
  - Stages: s1 verify data and freeze protocol | s2 fit one standalone baseline | s3 evaluate once and record direction decision
  - Prerequisites: record-level training and review data, fixed split IDs, independent targets and source tags, plus reference predictions for a paired comparison; supplied inputs contain summary evidence only.
- Improvement: Test a different representation as a standalone baseline for the first time, and measure the overall and source-specific gap instead of repeating another sub-resolution threshold change.
- Impact: 3
- Information: 3
- Confidence: 1
- Unblock: 2
- Diversity: 3
- Cost: 2
- Priority: 19
- Resource: CPU
- Parallel: NO
- Other: NONE
- Next test: In a future session, predeclare one count-distribution representation and regularized linear rule using training-side data only, fit the standalone candidate, then evaluate once on unchanged I-A-01/current against the frozen threshold reference. Preserve independent labels and equal source weights; record overall error, alpha/beta errors and counts, paired difference and uncertainty where available, and residual gap to ≤0.35. Require improvement greater than 0.01 as a screen plus uncertainty supporting its sign before claiming benefit; treat smaller or unresolved differences as inconclusive, and report subgroup uncertainty separately. Record one result and reassess the direction; execution is deferred for this session.
