"""Audit supplied evidence only; never build, fit, or evaluate a candidate."""

import argparse
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CHECKER = ROOT.parent / "skill" / "scripts" / "check_project.py"
INPUTS = (
    "agents.md", "discoveries.md", "handoff.md", "methods.md",
    "plan.md", "results/history.csv",
)


def run_checker(name):
    result = subprocess.run(
        [sys.executable, str(CHECKER), str(ROOT)],
        capture_output=True, text=True, encoding="utf-8", check=False,
    )
    (OUT / name).write_text(result.stdout + result.stderr, encoding="utf-8")
    print(result.stdout, end="")
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", action="store_true")
    parser.add_argument("--check-log")
    args = parser.parse_args()
    snapshot_path = OUT / "initial_inputs.json"
    if args.capture:
        if snapshot_path.exists():
            raise FileExistsError("Refusing to overwrite original evidence")
        snapshot = {}
        for name in INPUTS:
            data = (ROOT / name).read_bytes()
            snapshot[name] = {
                "sha256": hashlib.sha256(data).hexdigest(),
                "utf8": data.decode("utf-8"),
            }
        snapshot_path.write_text(
            json.dumps(snapshot, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        print("Original inputs captured with SHA-256 hashes.")
        return run_checker("checker_start.txt")

    snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
    for name in ("agents.md", "methods.md", "results/history.csv"):
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == snapshot[name]["sha256"], name
    old_lines = Counter(
        line.strip() for line in snapshot["discoveries.md"]["utf8"].splitlines() if line.strip()
    )
    new_lines = Counter(
        line.strip() for line in (ROOT / "discoveries.md").read_text(encoding="utf-8").splitlines()
        if line.strip()
    )
    assert not old_lines - new_lines, "Historical discovery content was lost or changed"
    with (ROOT / "results/history.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert [row["attempt"] for row in rows] == ["1", "2", "3", "4", "5"]
    assert {(r["family"], r["instrument"], r["cohort"]) for r in rows} == {
        ("threshold-tuning", "I-A-01", "current")
    }
    errors = [Decimal(row["error"]) for row in rows]
    methods = (ROOT / "methods.md").read_text(encoding="utf-8")
    handoff = (ROOT / "handoff.md").read_text(encoding="utf-8")
    target = Decimal(re.search(r"Target error: at most ([0-9.]+)", methods).group(1))
    resolution = Decimal(re.search(r"Resolution: ±([0-9.]+)", handoff).group(1))
    alpha = Decimal(re.search(r"source alpha ([0-9.]+)", methods).group(1))
    beta = Decimal(re.search(r"source beta ([0-9.]+)", methods).group(1))
    assert "equal counts" in methods
    half = Decimal("0.5")
    metrics = {
        "attempts": len(rows),
        "errors": [str(value) for value in errors],
        "minimum": str(min(errors)),
        "maximum": str(max(errors)),
        "mean": str(sum(errors) / len(errors)),
        "range": str(max(errors) - min(errors)),
        "instrument_resolution_plus_minus": str(resolution),
        "range_divided_by_resolution": str((max(errors) - min(errors)) / resolution),
        "target": str(target),
        "observed_minimum_target_gap": str(min(errors) - target),
        "observed_minimum_relative_reduction_needed": str((min(errors) - target) / min(errors)),
        "source_alpha_error": str(alpha),
        "source_beta_error": str(beta),
        "equal_weight_source_error": str(half * alpha + half * beta),
        "target_gap_at_source_audit_baseline": str(half * alpha + half * beta - target),
        "beta_error_needed_if_alpha_fixed": str((target - half * alpha) / half),
        "beta_absolute_reduction_needed_if_alpha_fixed": str(beta - (target - half * alpha) / half),
        "beta_share_of_current_weighted_errors": str((half * beta) / (half * alpha + half * beta)),
        "historical_evidence_preserved": True,
        "history_csv_sha256": snapshot["results/history.csv"]["sha256"],
        "candidate_runs_in_this_session": 0,
    }
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metrics, indent=2))
    if args.check_log:
        return run_checker(args.check_log)
    return 0


if __name__ == "__main__":
    sys.exit(main())
