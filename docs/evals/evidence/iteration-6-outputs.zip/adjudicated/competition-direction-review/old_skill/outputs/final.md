Paused threshold tuning and retired H-A-06. The 0.002 score range is below ±0.01 instrument resolution, while the target gap remains 0.049.

The [direction review](<host-path-350ad51a3bc5>) records H-A-07 as the sole next experiment: a standalone count-distribution representation plus regularized linear rule, evaluated overall and by acquisition source.

Historical evidence is preserved. The checker passed with a documented rules-format advisory. Slot A is released; no candidate was executed.