# Method comparison — Discoveries

## D-A-001 — Threshold attempt 1
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 1 measured error 0.400 on the current cohort.
- Evidence: results/history.csv row 1 records the independent I-A-01 measurement.
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:
- Decision class: model-change
- Instrument: I-A-01
- Result: error=0.400 on I-A-01 cohort current
- Family: threshold-tuning

## D-A-002 — Threshold attempt 2
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 2 measured error 0.401 on the current cohort.
- Evidence: results/history.csv row 2 records the independent I-A-01 measurement.
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:
- Decision class: model-change
- Instrument: I-A-01
- Result: error=0.401 on I-A-01 cohort current
- Family: threshold-tuning

## D-A-003 — Threshold attempt 3
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 3 measured error 0.399 on the current cohort.
- Evidence: results/history.csv row 3 records the independent I-A-01 measurement.
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:
- Decision class: model-change
- Instrument: I-A-01
- Result: error=0.399 on I-A-01 cohort current
- Family: threshold-tuning

## D-A-004 — Threshold attempt 4
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 4 measured error 0.400 on the current cohort.
- Evidence: results/history.csv row 4 records the independent I-A-01 measurement.
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:
- Decision class: model-change
- Instrument: I-A-01
- Result: error=0.400 on I-A-01 cohort current
- Family: threshold-tuning

## D-A-005 — Threshold attempt 5
- Source: A
- Host: local
- User: operator
- Date: 2026-10-25
- Cross-check: PENDING
- Finding: Threshold attempt 5 measured error 0.400 on the current cohort.
- Evidence: results/history.csv row 5 records the independent I-A-01 measurement.
- Implication: Compare this result with the instrument resolution before repeating the family.
- Reviews:
- Decision class: model-change
- Instrument: I-A-01
- Result: error=0.400 on I-A-01 cohort current
- Family: threshold-tuning


## D-A-006 — Direction review: suspend threshold refinements and test a standalone representation
- Source: A
- Host: local
- User: operator
- Date: 2026-10-26
- Session: codex:A@2026-10-26T14:03
- Cross-check: REVIEWING local (A)
- Finding: The five supplied threshold-tuning results on I-A-01 cohort current are indistinguishable at the stated instrument resolution. Another small threshold change has insufficient evidence to justify the one remaining experiment; prioritize the unbuilt standalone count-distribution representation with a regularized linear rule. This is an allocation decision, not proof that every threshold variant must fail or that the new family will succeed.
- Evidence: results/history.csv data rows 1–5 and D-A-001 through D-A-005; methods.md supplies the target, standalone method note and source audit; handoff.md Instruments supplies I-A-01 provenance, coverage, agreement and resolution. These inputs are supplied observations, not newly reproduced candidate measurements. The historical discoveries remain PENDING; this review uses their explicit unverified-premise limitation and the matching local table.
- Implication: Retire H-A-06 after its review stages; spend the next experiment on H-A-07. No new current best, candidate score, target change or execution is established by this review.
- Reviews:
- Kind: direction-review
- Decision class: model-change
- Instrument: I-A-01
- Family: count-distribution-linear
- Gap: Target error is at most 0.350 on I-A-01. Historical observations dated 2026-10-25, reviewed 2026-10-26, are 0.400, 0.401, 0.399, 0.400 and 0.400 on cohort current; nominal minimum 0.399 leaves an absolute gap of 0.049 (4.9 percentage points), about 12.3% of that error. The instrument is supplied as independent and held-out, with rank agreement 0.90 against the broader historical review and resolution ±0.01. The 0.002 range is one fifth of that resolution, so the nominal minimum is not a resolved winner. The target gap is much larger than this observed tuning spread. Resolution is not a confidence interval; sample sizes and uncertainty estimates are absent, and repeated adaptive use can overfit the review cohort.
- Decomposition: The separate source audit in methods.md gives equal source counts, alpha error 0.30 and beta error 0.50: 0.5*0.30 + 0.5*0.50 = 0.40. Their weighted loss contributions are 0.15 and 0.25; beta accounts for 62.5% of audited errors. Holding alpha fixed, reaching 0.35 requires beta error at most 0.40, an absolute beta reduction of 0.10. These component rates describe the supplied audit reference, not measured components of attempt 3. Source-specific results are therefore required in the next comparison; the association alone establishes no cause or label defect.
- Core families: Threshold-tuning was built standalone five times (D-A-001 through D-A-005), with unchanged representation and no resolution-level separation. Count-distribution representation followed by a regularized linear rule is described in methods.md but has not been built standalone here. H-A-07 tests that missing core family on its own, without an ensemble or a threshold-family sweep. Further threshold work requires either an independently justified, more resolving instrument or a substantive structural change documented in a new direction review; merely renaming a tweak is insufficient.
- Data audit: methods.md states that targets were independently assigned before candidates were built and that the review sample has equal counts from two acquisition sources. Preserve targets, sample identities, source labels, weights and the held-out definition; the beta gap does not justify relabeling or removing beta. The supplied summaries do not establish entity disjointness, train/review overlap, feature leakage, sample sizes or train/evaluation definition consistency. H-A-07 must check those prerequisites from raw inputs, keep label/source identifiers out of predictors, and fit preprocessing and the rule using training data only before one frozen review evaluation. Do not reinterpret this same cohort as a fresh independent confirmation.
- Intake: First-review intake is the local published-method summary in methods.md: retain count-distribution information that a single threshold discards, then use a regularized linear decision rule. Its reported error about 0.36 comes from a different sample; it is motivation, not a local result, comparable saturation observation or promised gain. Even a transferable 0.36 would remain 0.01 above the target. No network intake was performed, and no other public method or score is supplied.
- Rejected consistent gains: None evidenced in the supplied record. The five threshold results show no gain distinguishable at I-A-01 resolution; the outside-sample 0.36 is not a locally established gain that was rejected. Suspending refinements is not an experimental rejection of the unbuilt family.
- Decisions: Completed the inspection, evidence analysis and decision-recording stages of H-A-06 without executing a threshold candidate; removed H-A-06 from the live queue. Created only H-A-07, a bounded standalone count-distribution-linear comparison on I-A-01 cohort current with source-level reporting and prespecified decision gates. Keep the original five discoveries and results/history.csv intact. Do not launch H-A-07 in this session; retain all uncertainty and verification limitations for the next operator session.
