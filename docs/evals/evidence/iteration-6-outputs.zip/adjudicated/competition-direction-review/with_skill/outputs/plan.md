# competition direction review — Plan

## Queue

### H-A-07 — One standalone count-distribution and regularized-linear comparison
- Claimed: none
- Sources: D-A-006, D-A-001, D-A-002, D-A-003, D-A-004, D-A-005
- Hypothesis: Retaining count-distribution information with one regularized linear decision rule can reduce held-out error beyond the threshold family's unresolved spread, with source beta the main diagnostic stratum.
- Evidence: D-A-006 reviews five comparable threshold runs and the source audit; methods.md describes an unbuilt standalone family and an outside-sample score that is motivation only. Historical discoveries and the direction review are PENDING at queue creation; their supplied measurements have not been independently reproduced. No local count-distribution candidate has been tested.
- Improvement: Change the representation and test a missing core family standalone; preserve the evaluation cohort and targets, and expose source-level errors instead of making a sixth threshold adjustment. Related H-A-06 was retired by D-A-006, not executed.
- Impact: 3
- Information: 3
- Confidence: 2
- Unblock: 1
- Diversity: 3
- Cost: 2
- Priority: 19
- Resource: CPU
- Parallel: NO
- Other: NONE
- Next test: In a later session, first obtain the raw training/current-review observations, independent labels, frozen split and source identities; these are not supplied in this summary-only fixture. Verify disjoint entities and compatible definitions. Prespecify one count-distribution feature construction and one L2-regularized linear classifier, including regularization, scaling and seed, using training data only. Fit exactly one standalone candidate and evaluate once on unchanged I-A-01 cohort current with equal source weights. Record overall error, per-source counts/errors, weighted loss contributions and remaining gap to 0.35; compare against the existing nominal threshold baseline without another threshold fit. A reduction greater than 0.01 from 0.399 (error below 0.389) is a prespecified screening signal to pursue this family, not a significance claim; differences at or below resolution are inconclusive. Error at most 0.35 meets the nominal target, but a boundary result needs uncertainty-aware confirmation. Otherwise record the residual gap and reassess rather than opening a sweep. If inputs or instrument identity cannot be verified, stop before fitting. No execution is authorized in the current review session.
- Family: count-distribution-linear
- Stages: s1 validate inputs and freeze specification | s2 one standalone fit and held-out evaluation | s3 source decomposition and decision
