Created [codex-setup.md](<host-path-1d3ac93b7613>) with dated probe evidence, protection limits, practical workflow, and installation steps preserving team settings.

Only the requested note was added. No host was launched or trust settings changed.