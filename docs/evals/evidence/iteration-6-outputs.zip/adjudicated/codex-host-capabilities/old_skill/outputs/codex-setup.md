# Codex setup handoff — 2026-10-26

For the teammate using **codex-cli 0.154.0 exec on Windows/PowerShell**: as of **2026-10-25 UTC, Codex exec hook enforcement was not established**. The maintained reference describes it as “not enforced in exec.” Do not rely on this installation to prevent deletion of running-job files or to reject shell background calls. An active startup self-test does not establish those protections.

This is an offline review of existing evidence. No host was launched, trust setting changed, or installation performed. The supplied skill directory contains its `SKILL.md` but lacks the hook reference and samples. The sources below come from the maintained local checkout at `<host-path-b599a19e9655>`; use that complete checkout for the paths in this note:

- [Hook reference and capability matrix](<host-path-29edeac693c1>).
- [Final installed-host record](<host-path-dae8988a5161>), timestamp **2026-10-25T19:27:22.640428+00:00**, with `codex-cli 0.154.0` confirmed by a successful version query.
- [Separate delivery probe](<host-path-d657286d4a07>), timestamp **2026-10-25T16:15:41.527537+00:00**; it targeted 0.154.0 without querying the version.

The final run used fresh disposable projects and a synthetic running-job registry bound to the harness's live PID/start identity. It did not launch a job for that registry. Hook enablement and invocation-local trust overrides were already applied in the recorded experiment; these are observations under that setup, not instructions to repeat its trust bypass.

| Probe | Recorded result | Supported conclusion |
| --- | --- | --- |
| Background: `Write-Output 'ro-hook-background' &` | The shell tool ran and exited 1 with PowerShell `ParserError` / `AmpersandNotAllowed`. No target `shell.background` diagnostic or runner denial appeared. | **Unknown/inconclusive hook enforcement.** The shell parser rejected the syntax; this does not establish hook rejection. |
| Delete-bound: `Remove-Item -LiteralPath 'run/input.txt'` | The tool exited 0 and the bound file was absent afterward. PreToolUse reported no hook decision. | **Not blocked.** The installation failed the deletion-protection check. |
| Benign: `Write-Output 'ro-hook-benign'` | The tool succeeded; PreToolUse reported no hook decision. | The harmless call completed as expected. This provides no blocking evidence. |
| Read-bound: `Get-Content -LiteralPath 'run/input.txt'` | The tool succeeded; no target `jobs.read-bound` warning diagnostic appeared. | **Warning inconclusive.** Read-warning delivery was not established. |
| Stop monitoring notices | Runner diagnostics recorded `jobs.unmonitored` with decision `warned`. | Warning logging was demonstrated; user-visible delivery and Stop blocking remain **unverified**. |

All four cases recorded an active self-test and SessionStart, PreToolUse, PostToolUse and Stop diagnostics. Their PreToolUse entries had empty check lists and “no hook decision.” Startup activity therefore coexisted with failed deletion protection. The separate delivery probe recorded SessionStart and PreToolUse/Bash delivery for project JSON and home JSON configurations. Its home TOML case exited 1 after SessionStart, leaving later delivery inconclusive. Delivery evidence alone does not establish a check's decision or enforcement.

The remaining Codex capabilities are unverified: detach, heredoc and directory-change checks, record warnings, publication/external pre-checks, away-mode questions and brief requirements. The sample matches only `Bash|apply_patch` for tool events; it declares no question-tool or agent-tool mapping. PostToolUse cannot undo an edit. These records do not verify other versions, normal trust flows, every event, sandbox behavior or failure handling.

Even where hooks work, their protection is limited. `Enforcement: block` denies only checks named in `Block`; unlisted checks warn, `warn` only warns, and `off` is silent. Read-bound advice requires `Read bound: on`; reads are quiet by default, with status files, logs and heartbeats exempt. PreToolUse, PostToolUse and Stop **fail open** on crashes, timeouts, malformed input or a missing interpreter. Nested interpreter bodies, aliases, dynamic paths, directory-change scope and junction resolution also limit checking. These hooks address cooperative accidents and do not provide filesystem isolation.

For daily work, use the explicit command workflow described in [operational safety](<host-path-c0f4cb4340ba>). Here `ro` means the complete checkout's Python entry point. For example, from the project directory:

```powershell
$pythonExe = '<host-path-1d5ebf570ab0>'
$roScript = '<host-path-f90a9b5fe156>'
& $pythonExe $roScript --project . --slot A brief
& $pythonExe $roScript --project . --slot A jobs
```

Use the assigned slot instead of `A` when appropriate. These commands assume an existing orchestrator project; do not initialize over existing team files merely to install hooks.

1. Inspect `ro brief` on startup, resume and compaction. Check the self-test, warning counts and `.ro/warnings.log`: “hooks never ran” means no self-test, and “hooks inactive: <reason>” means failure. Treat “active” as a limited health signal.
2. Claim the intended item and use `ro launch --item <item-id> --expect 2h --run-dir <dedicated-run-dir> --bind <input-path> -- <command>`. Launch refuses conflicts with running-job bindings; its dedicated run directory, script paths and explicit inputs are bound. Preserve those paths while workers run. Use immutable input copies and a new run directory for revisions. This registry does not prevent an arbitrary shell command from deleting a bound file.
3. Start the exact `ro monitor` command printed by launch immediately. Use the host's background facility for a long monitor; avoid shell trailing `&`, `disown` and detached helper calls that lose ownership. Host-managed background facilities are distinct from shell background syntax, but their jobs also need explicit tracking.
4. Inspect `ro jobs` for process and monitor state. Record the monitor outcome and inspect result artifacts before releasing claims. Process exit alone is insufficient. Use `ro kill <job>` when an owned process tree must stop, then monitor again. Check host-managed, remote and other unregistered jobs separately before `ro close`; the registry cannot account for them.
5. Before a direct shell operation, use `ro check --dialect powershell '<literal command>'` and respect its findings. It checks the command without executing it and remains limited by policy and parsing; it does not automatically intercept a later shell call. Run the project checker for record consistency. Do not wait for a Stop notice to discover missing monitors.
6. For publication, use the separate [Git pre-push gate](<host-path-94e273c8a750>). Under `Enforcement: block` with `publish.scan` in `Block`, it scans outgoing history and refuses an unavailable scan; its missing interpreter also exits nonzero. For outward actions, use [receipts and `ro external`](<host-path-34d5e1bf7496>), which refuses execution on failed or unavailable validation. These gates protect their own execution paths; they do not protect arbitrary file deletions.

The Codex sample remains useful for diagnostics and future capability verification. The following are **installation instructions for later**, not changes made during this handoff:

1. Review the complete plugin checkout and ensure Python 3 is available to its wrappers. If it is off `PATH`, set `RO_HOOK_PYTHON` to `<host-path-1d5ebf570ab0>` in the host's launching environment, and verify it reaches hook processes.
2. Copy [hooks/codex-hooks.sample.json](<host-path-54655f0f1095>) to the project's `.codex/hooks.json`. Merge the event entries if that file already exists. **Preserve the team's existing `.codex/config.toml` and all its settings.** Create an empty config only when absent; the teammate's project already has one.
3. Replace `/absolute/path/to/plugin` in **every** `command` and `commandWindows` with the reviewed plugin root. POSIX commands use `sh ".../hooks/ro-hook.sh"`; PowerShell commands use `& ".../hooks/ro-hook.cmd"`. For this local checkout, one Windows JSON value is `"& \"<host-path-0dd5aa8763cb>" PreToolUse"`. Use forward slashes or JSON-escaped backslashes. Preserve the sample's 10-second timeout and event arguments: `SessionStart --general`, `PreToolUse`, `PostToolUse --general`, and `Stop --general`, along with their matchers.
4. Enable `-c features.hooks=true` if needed. During a later interactive setup, inspect and trust the reviewed hooks through `/hooks`, and trust the project separately through the normal project trust flow. The recorded bypass is not needed as a standing team setting. Completing installation does not upgrade the 0.154.0 exec enforcement claim.
5. Install the Git gate separately: locate the hook directory with `git rev-parse --git-path hooks`, integrate `hooks/pre-push.sample` as `pre-push` while preserving any existing hook, and replace its fixed plugin and interpreter paths. Verify it against a disposable local remote using synthetic credentials in an intermediate commit, following the publication reference.

Before changing capability claims, perform a separately authorized disposable verification for the exact host version, entry point, shell, trust flow and policy. Enable diagnostics with `RO_HOOK_DIAGNOSTICS=1` or the `.ro/hook-diagnostics.on` marker, which also works when environment variables are filtered. Inspect `.ro/hook-diagnostics.jsonl` for the target event, check ID and runner decision, then verify actual tool execution and file side effects. `exec --json` omits hook lifecycle events, so its stream and an assistant's report are insufficient alone. Remove the diagnostic marker when finished.

Verify harmless, warning and configured blocking calls, edits, Stop, startup/resume/compact, failure/timeout behavior and a missing outer interpreter. A claimed denial must actually prevent execution; a denial followed by execution fails the check. Keep the workflow above until each required capability has that evidence.
