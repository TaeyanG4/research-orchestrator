Created [codex-setup.md](<host-path-b9ee90f93fd8>) with dated 0.154.0 probe findings, protection limits, practical workflow, and installation steps preserving team configuration.

Local links verified. Only the requested note changed; no host launched or trust settings changed.