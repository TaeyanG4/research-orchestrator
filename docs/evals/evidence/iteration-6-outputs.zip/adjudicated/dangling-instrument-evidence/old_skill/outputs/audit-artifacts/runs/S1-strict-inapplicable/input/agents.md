# Measurement Evidence Checker Audit — Agent Rules

## Project settings

- Platform mode: single
- Platforms: Codex
- Git sync: off
- Plan collector: off
- Plan queue limits: stop at 50, resume at 5
- Reviewer: off
- Cross-check fallback: same-host

- Evidence guards: strict
- Evidence guards activated: 2026-10-01
- Evidence guard applicability: G1 inapplicable — synthetic control excludes this owning guard to audit applicability handling

The user may edit these lines directly.

- `Plan collector`, `Plan queue limits`, `Reviewer`, and `Cross-check fallback` take effect as soon as they are edited; every session reads them at start.
- `Platform mode`, `Platforms`, and `Git sync` change the rules below, so after editing them run `python <skill-root>/scripts/init_research_orchestrator.py . --reconfigure` to regenerate the rules (flags such as `--platform` or `--git` work too). It rewrites only this file.

Log any settings change as a handoff event with heading `none`.

## Who is who

Three different names appear in every session. Do not mix them up:

| Name | What it is | Examples | Where it is recorded |
| --- | --- | --- | --- |
| Agent (slot) | A work slot | `A`, `B`, `AA` | plan and handoff section headings, IDs |
| Host | The platform running the session — not the model | `Claude Code`, `Codex` | `Current host`, event `Host`, discovery `Host` |
| User | The person running the session | `kim`, `user1` | `Users` in Shared state, `Current user`, event `User` |

### Users

- At the start of every session, know your user's name. If the user has not said it, ask once (`What name should I record for you? e.g. kim, user1`). If `Users` lists only one name, you may ask to confirm it instead.
- A user name is one word of letters, digits, `-`, or `_` (for example `kim`, `user1`, `lee-j`). It is never a slot name (`A`, `B`, …) or a host or model name.
- Add a new user to `Users` in `handoff.md` Shared state. Set `Current user` in your slot when you take it and `none` when you release it, and write `User` in every event.
- Never take over an item from a slot that another user is actively running. A released slot of another user may be a take-over source under the usual rules.

### Agent names

Agent names are work slots, not tool or model identities. Allowed names, assigned in order:

```text
A, B, C, ... Z, AA, AB, ... ZZ
```

- Single-agent work always uses `A`. Each additional concurrent session takes the next unused letter; after `Z`, two-letter names follow in spreadsheet-column order. Released slots are reused before new ones are created.
- Never use a host, product, or model name (`Claude`, `Codex`, `GPT`, `Gemini`, `Antigravity`, ...) or a user name as an agent name. Any host and any user may continue any slot.
- A host is the platform (`Claude Code`, `Codex`, `Antigravity`, ...), not the model: two Claude Code sessions running different models are the same host.
- Which host and user own a slot is recorded in `handoff.md`: `Current host` and `Current user` in the agent's active section (update them whenever you take or resume the slot) and `Host` and `User` in each completed-log event.
- A slot is free when its `Current host` is `unassigned` or `released`. If no name is assigned, read only the `Current host` line of each agent section in `handoff.md` and take the first free slot in order (`A`, `B`, `C`, ...); if none is free, create the next unused letter (plan section, handoff section, and `Active agent(s)`). Set `Current host: <your host>` when you take a slot and `Current host: released` when you close the session. Reclaim a slot a crashed session left taken only when the user says so.
- IDs embed the owner: plan items `H-<Agent>-<NN>` (`H-A-01`, `H-B-07`), discoveries `D-<Agent>-<NNN>` (`D-A-001`, `D-C-014`). Number only your own IDs and never reuse a number.
- The current lists of agents and users live in `handoff.md` Shared state, not here. This file holds only stable rules.

## Read order

1. `agents.md`
2. all of `discoveries.md`
3. `handoff.md`: shared state and completed/review log plus only your own active handoff section
4. `plan.md`: only your own detailed `## Agent: <name>` section
5. run the consistency check (below) before starting work

A dispatcher, or a session choosing a take-over item, may inspect only task ID, owner, priority, cost, information, resource, parallel-safety, and `Other` executor metadata across plan sections.

## Core rules

- Keep only unfinished plan items in `plan.md` — nothing else; execute highest priority first. Project-wide values such as the current best live only in `handoff.md` Shared state and cite the discovery that set them.
- Before adding a plan item, check it is not a duplicate: search `discoveries.md` (every completed experiment is there, including negative and inconclusive ones) and the other agents' plan item headings and `Hypothesis` lines. Skip settled (`VERIFIED`) or `CHALLENGED` claims and anything already queued; otherwise cite the prior ID and give a real `Improvement`.
- When a plan item finishes, in one step: create or update its discovery (always — positive, negative, or inconclusive), append a handoff event that points to it, plan its follow-ups (see "Plan follow-ups" below), and remove the completed plan item.
- Read all discoveries, but do not read another active agent's detailed plan or active handoff unless explicitly asked to review it. The only cross-section peeks allowed are dispatcher metadata, the duplicate check above (headings and `Hypothesis` lines only), the `Current host`, `Current user`, and `Current thread` lines when choosing a slot or a take-over source, and the one item you take over.
- Discoveries are cross-checked once by a different slot, not by every agent (see "Discovery cross-check" below).
- A discovery may create zero, one, or many new hypotheses; one hypothesis may combine many discoveries.
- When bringing a discovery back into `plan.md`, include `Sources`, `Evidence`, and `Improvement` so the new attempt is justified and materially different.
- Re-score affected plan items when evidence changes.
- Re-read shared files immediately before editing and patch only the relevant section or append a new entry.
- Make linked changes together: a new slot gets its plan section, handoff section, and `Active agent(s)` entry at once; a take-over moves the item and logs it at once; a new best result updates `Current best` in the same step as its discovery.
- Do not create per-agent continuity folders or a separate process file.
- Create `docs/` only to archive old handoff history when needed.

## What goes where

- `discoveries.md` — **what is known**: claims, numbers, interpretation, verification. The only index of what has been tried.
- `handoff.md` — **what happened and where to resume**: who, when, which host and user, artifact paths, and each slot's resume point. Events point to discoveries by ID instead of repeating them.
- `plan.md` — **what to do next**: plan items only.

## Git sync

This project does not use git for coordination. Do not run git commands for these files; sessions share state only through the files on this machine. Sessions on other machines or other users' computers will not see each other — switch to `push` mode for that.

## Consistency check

Run `python <skill-root>/scripts/check_project.py .` at session start, after a take-over, and before closing. Fix problems in your own sections before starting new work; if a report is wrong, note it under `Open consistency issues` as `(disputed — <why>)` and continue. For a problem in another agent's section, add it under `Open consistency issues` in `handoff.md` Shared state instead of editing their section; the owner or the user resolves it.

## Plan follow-ups (zero or more)

Every time you write or update a discovery — a new finding, a negative result, or a cross-check verdict — decide what it changes before picking your next item:

1. Add each next test that could change a decision as a plan item in your own section, with `Sources`, `Evidence`, and `Improvement`, after the duplicate check.
2. Rescore your existing items it affects; remove the ones it made pointless, naming each in the handoff event's `Action` as `removed H-A-05 — <reason>`.
3. Zero follow-ups is valid but must be deliberate: write `New plan items: none — <reason>` in the handoff event. A bare `none` is not allowed.

## When your own queue runs out

Look for work in this order before going idle:

1. Re-read your own section (another session may have taken items; the handoff log says so).
2. Claim a `PENDING` cross-check of another slot's discovery.
3. Take over an item from another slot (below).
4. New work: if `Plan collector` is on and the queue is at or below its resume limit, start a collection round (see "Plan collector"); otherwise derive new hypotheses from discoveries yourself.
5. If nothing worthwhile is left, note it in your active handoff section, set `Current host: released`, and stop.

**Taking over from another slot.** All sessions run on the one platform in `Platforms`, so this works across sessions and models.

- Eligible sources: a slot that is `released` or `unassigned`, or an active slot of your own user. Never take the item in the owner's `Current thread` or one under an `Active compute` claim, and never from a slot another user is actively running.
- Pick by metadata only: highest `Priority` (ties: lower `Cost`, then higher `Information`) that you can run now.
- Re-read `plan.md`, then move the block into your own section with your next ID and the old ID in the title: `### H-A-05 — <title> (from H-C-03)`. The old ID is retired.
- Rescore it, and log `Action: took over H-C-03 from C (same host) as H-A-05` with `Discovery updates: none — take-over, no experiment` in the handoff.

## Plan collector

`Plan collector` is either `off` or `on — <platform> / <model>`, for example `on — Claude Code / sonnet` or `on — Codex / sol`. When it is on, a sub-agent gathers a wide range of research candidates into `plan.md`, so the main agents never run dry. `Plan queue limits` reads `stop at <N>, resume at <M>`, for example `stop at 50, resume at 5`.

- **When**: at session start and whenever you finish an item, count the plan items in all sections (`### H-` headings). If the count is at or below the resume limit and `Plan collection` in `handoff.md` Shared state reads `idle`, start a round.
- **Who**: only a session running on the collector's platform, because it must launch a sub-agent with the collector's model (for example the Agent tool with the model set, in Claude Code). Sessions on other platforms skip collection.
- **Start a round**: set `Plan collection: running — <your agent> (since YYYY-MM-DD HH:MM)` first, so no second round starts.
- **The sub-agent**: give it all of `discoveries.md`, the headings and `Hypothesis` lines of every plan item, the project goal, and any sources the user allows (papers, competition forums, documentation). Ask for diverse candidates, each a full plan item with `Sources`, `Evidence`, `Improvement`, and honest scores; reject anything that fails the duplicate check.
- **Add**: put accepted items in your own section under your own IDs, until the queue reaches the stop limit or no worthwhile candidates remain. Then set `Plan collection: idle` and log one event with heading `none`: `Action: plan collection round (Claude Code / sonnet): added H-A-12, H-A-13`, the same IDs under `New plan items`, and `Discovery updates: none — collection, no experiment`.
- **Between rounds** nothing is collected, so the queue drains to the resume limit before the next round.
- A `running` marker left by a released slot is stale; clear it and log the cleanup.

## Discovery cross-check

This project runs on one platform (see `Platforms`), so a discovery is checked **once** by a session in a **different slot**; the source slot never reviews its own discovery. Every review reason starts with `same host —`, because both sessions share the platform's blind spots.

Two different words are used, in two different places. Do not mix them up:

- **Verdict** — what the reviewer writes on its own line under `Reviews:`. Only `CLOSED`, `HOLD`, or `CHALLENGED`.
- **State** — the discovery's `Cross-check:` field, which everyone reads to see where it stands.

| Reviewer's verdict (`Reviews:` line) | Resulting state (`Cross-check:`) | Meaning |
| --- | --- | --- |
| — | `PENDING` | Nobody eligible has reviewed it yet |
| — | `REVIEWING <Host> (<Agent>)` | An eligible session has claimed the review |
| `CLOSED` | `VERIFIED` | The reviewer accepts it. **This is the normal pass.** |
| `HOLD` | `HOLD` | Plausible, but specific evidence or an improvement is needed first |
| `CHALLENGED` | `CHALLENGED` | A contradiction, flaw, or missing assumption was found. **This is a failure, not a pass.** |

`CLOSED` is never written in `Cross-check:`, and `VERIFIED` is never written as a verdict.

A passing review looks like this:

```markdown
- Host: Codex
- Cross-check: VERIFIED
- Reviews:
  - Claude Code (A): CLOSED — reproduced independently with ...
```

To review:

1. Pick a discovery from a slot other than yours whose `Cross-check` is `PENDING` (or `HOLD` whose stated condition is now met).
2. Claim it: set `Cross-check: REVIEWING <your host> (<your agent>)`. Do not take a discovery someone else has claimed unless that agent's `Current host` reads `released` or `unassigned`, or the user says so.
3. Add your line `<your host> (<your agent>): CLOSED | HOLD | CHALLENGED — reason`. For `HOLD` or `CHALLENGED`, say what would make it acceptable.
4. Set `Cross-check` to the matching state from the table. If an earlier `CHALLENGED` review is still unresolved, the state stays `CHALLENGED` even after a later `CLOSED`.
5. If you stop before finishing, set `Cross-check` back to `PENDING`.

One review is enough; add another only for high-impact or disputed discoveries. When the source revises a `HOLD` or `CHALLENGED` discovery, it updates `Evidence` and resets `Cross-check` to `PENDING`.

### Reviewer

`Reviewer` is either `off` or `on — <platform> / <model>`, for example `on — Codex / sol`.

- `off`: the agents themselves do cross-checks, as part of "When your own queue runs out".
- `on`: a session on the reviewer's platform hands each eligible `PENDING` discovery to a sub-agent with the reviewer's model, so the main agents keep experimenting. The session claims the review under its own slot (`REVIEWING <host> (<agent>)`) and writes the review line under its own host and slot, with the model at the start of the reason: `Codex (B): CLOSED — reviewer sol — reproduced with ...` (after `same host —` when that applies). All eligibility rules above still hold.

### Cross-check fallback

`Cross-check fallback` decides what happens to discoveries that need a different host when none is active:

- `wait`: leave them `PENDING` for the other host. Work that depends on them says so in its `Evidence`.
- `same-host`: when your own queue runs out, review them on your own host with a different model when you can (the reviewer's model, if `Reviewer` is on); start the reason with `same host —`. A session on another host may add a second review later.

In a `single` project every cross-check is same-host, so this setting has no effect there.

## Priority scoring

Score 0-3 on Impact, Information, Confidence, Unblock, Diversity, and Cost (0 cheap, 3 expensive).

```text
Priority = 2*Impact + 2*Information + Confidence + Unblock + Diversity + (3-Cost)
```

Range 0-24. Break ties by lower Cost, then higher Information.

Each plan item also declares:

```text
Resource: CPU | GPU | EITHER
Parallel: YES | NO
Other: NONE | <external executor>
# Example: Other: Kaggle
```

## Adaptive workers

When parallel work is useful, start with two agents (`A`, `B`) and add more only while independent high-value work and compute headroom remain. Stop at practical full load before contention reduces throughput.

- Fill idle GPU with the highest-priority compatible GPU/EITHER item.
- Fill idle CPU with the highest-priority compatible CPU/EITHER item.
- Use the idle local resource while the other is busy.
- When local CPU and GPU are saturated, use an available `Other` executor only for worthwhile compatible work and only when authorization/quotas permit it.
- Scale down when memory pressure, I/O contention, duplicated work, or lower throughput appears.

**Claim before you launch.** Before a heavy job, check both the `Active compute` claims in `handoff.md` and the machine's real usage (`nvidia-smi`, task manager, `top`). Add `GPU — <you> (<item>, since <time>)` and launch in the same step; remove the claim in the same step that records the job's end. When sessions run on more than one machine, name the machine: `GPU@kim-desktop — A (H-A-04, since <time>)`; only claims on your own machine block you.

**When the resource you need is busy**, do not launch alongside it unless your item is `Parallel: YES` and measured free memory and load clearly fit. Wait, and meanwhile do, in order:

1. your best item that fits an idle resource (or a permitted `Other` executor);
2. work that needs no heavy compute: a pending cross-check, preparing the waiting experiment (script, tiny-sample test), analysing results and planning follow-ups, rescoring, the consistency check;
3. if nothing is left, set `Blocker: waiting for GPU (held by <agent> for <item> since <time>)` and re-check at an interval that matches the running job — not in a tight loop.

**Stale claims.** A claim is stale when its slot is released, its item is gone from `plan.md`, or the job is verifiably not running. Remove your own; clear a released slot's claim and log it; for an active agent's claim, use `Open consistency issues`. Never release your slot while your job still runs.

## Close a session

Finish completed plan-item migrations, rescore your remaining items, finish or release any cross-check you claimed, update `Resumable state` and `Next action` in your active handoff section, run the consistency check, and remove claims for jobs that have ended. If a job you launched is still running, keep its claim, your `Current host`, and your `Current user`, and stop there; otherwise set `Current host: released` and `Current user: none`.
