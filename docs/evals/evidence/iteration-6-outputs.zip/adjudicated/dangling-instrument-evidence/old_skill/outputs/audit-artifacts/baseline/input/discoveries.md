# Isolated evidence audit — Discoveries

## D-Z-990 — Supplied historical agreement observation
- Source: Z
- Host: Codex
- User: audit
- Date: 2026-09-30
- Cross-check: PENDING
- Finding: The supplied independent held-out quality instrument agreed with external observations on 91 of 100 observations in the stable cohort; agreement 0.91.
- Evidence: supporting-evidence.md, D-Z-990; synthetic observations supplied by the user, imported here without claiming an assistant measurement or independent review.
- Implication: Supports the Agreement entry of the supplied I-A-01 fixture; no new experiment is implied.
- Reviews:

## D-Z-991 — Supplied historical resolution observation
- Source: Z
- Host: Codex
- User: audit
- Date: 2026-09-30
- Cross-check: PENDING
- Finding: The supplied repeated measurements of the stable cohort ranged from 0.80 to 0.82 around 0.81; resolution ±0.01.
- Evidence: supporting-evidence.md, D-Z-991; synthetic observations supplied by the user, imported here without claiming an assistant measurement or independent review.
- Implication: Supports the Resolution entry of the supplied I-A-01 fixture; no new experiment is implied.
- Reviews:

## Instrument registry

This is an audit input ledger. The supplied skill does not define an instrument registry schema or validate these entries. Dates follow the supplied fixture. I-A-99 is intentionally absent.

### I-A-01 — Supplied historical quality instrument
- Date: 2026-09-30
- Provenance: independent
- Coverage: held-out
- Measures: quality on stable cohort
- Agreement: 0.91 (D-Z-990)
- Resolution: ±0.01 (D-Z-991)
- Not for: none
