# Skill benchmark: research-orchestrator-skill

Included runs: 76; excluded runs: 18.

with_skill - old_skill comparison: 31 / 47 cases matched.
Excluded 18 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |
| with_skill | 40 | 99.77% | 489.447 |
| old_skill | 36 | 53.12% | 532.1543 |

## Excluded runs

- cli-hook-literal/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-enforcement-evidence/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-enforcement-evidence/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-host-capabilities/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- competition-direction-review/with_skill: transport failure
- credential-storage-redaction/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- external-result-reconciliation/old_skill: transport failure
- fenced-record-examples/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-interpreter-override/old_skill: transport failure
- hook-interpreter-override/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- launch-root-binding/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- native-session-slots/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- note-id-kind/old_skill: transport failure
- owned-job-monitor/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- unified-research-resume/with_skill: transport failure
- unreadable-subdirectory/with_skill: transport failure
- work-project-session-history/with_skill: transport failure
- work-project-start/with_skill: transport failure
