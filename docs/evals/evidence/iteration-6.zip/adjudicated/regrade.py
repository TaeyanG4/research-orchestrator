"""Regrade retained evidence without invoking an executor or a model judge."""
from pathlib import Path
import json, sys, time
sys.path.insert(0, str(Path.cwd()))
from scripts.evals import run_evals as runner, grade_evals as grader, checks
from scripts.evals.contamination import audit_saved_run, recover_reclassified_run
from scripts.evals.aggregate_evals import generate_benchmark, generate_markdown

root=Path(__file__).resolve().parent
changes=[]
for case in runner.load_cases(runner.DEFAULT_SKILL):
    case_root=root/case.name
    if not case_root.is_dir(): continue
    modes=grader.assertion_modes(case)
    for cfg in ('with_skill','old_skill'):
        directory=case_root/cfg
        run=json.loads((directory/'run.json').read_text(encoding='utf-8'))
        old=json.loads((directory/'grading.json').read_text(encoding='utf-8'))
        audit=audit_saved_run(directory,run)
        recovered=recover_reclassified_run(run,audit)
        if recovered: runner.write_json(directory/'run.json',run)
        if audit['contaminated'] or runner.saved_transport_category(directory,run) or run.get('failure_category') in {'launch','setup/copy'}:
            new=grader.grade_run(case,directory)
        else:
            context=checks.CheckContext(case.path,directory,runner.DEFAULT_SKILL,sys.executable)
            manual_path=root/'recovered-grades'/f'{case.name}-{cfg}.json'
            if not manual_path.exists() and cfg=='old_skill':manual_path=root/'recovered-grades'/f'{case.name}.json'
            manual=json.loads(manual_path.read_text(encoding='utf-8')) if manual_path.exists() else {}
            saved={v['text']:v for v in old.get('expectations',[])}
            saved.update({v['text']:v for v in manual.get('expectations',[])})
            verdicts=[]
            for assertion in case.assertions:
                if modes[assertion.path.name]=='scripted':
                    try: passed,evidence=checks.SCRIPTED_CHECKS[(case.name,assertion.path.name)](context)
                    except Exception as exc: passed,evidence=False,str(exc)
                    verdicts.append({'text':assertion.text,'passed':bool(passed),'evidence':evidence})
                else:
                    if assertion.text not in saved: raise RuntimeError(f'Missing reviewed judgment: {case.name}/{cfg}/{assertion.path.name}')
                    verdicts.append({key:saved[assertion.text][key] for key in ('text','passed','evidence')})
            passed=sum(v['passed'] for v in verdicts)
            timing=json.loads((directory/'timing.json').read_text(encoding='utf-8'))
            new={**old,'expectations':verdicts,'summary':{'passed':passed,'failed':len(verdicts)-passed,'total':len(verdicts),'pass_rate':passed/len(verdicts)}}
            for key in ('excluded','exclusion_reason','contamination'):new.pop(key,None)
            if recovered:
                new['timing']={'executor_duration_seconds':timing.get('total_duration_seconds'),'grader_duration_seconds':None,'total_duration_seconds':None}
                new['execution_metrics']={'errors_encountered':int(run.get('returncode')!=0)}
                new['user_notes_summary']={'uncertainties':[],'needs_review':['Retrospective saved-evidence review; manual grading duration unmeasured.'],'workarounds':[]}
                runner.write_json(directory/'grading_status.json',{'error':None,'excluded':False,'method':'retrospective inline evidence review plus scripted checks'})
            new['analysis_provenance']={'method':'Retained judged verdicts; replayed deterministic checks; recovered exclusions reviewed inline','new_executor_run':False}
            runner.write_json(directory/'grading.json',new)
        if old.get('summary')!=new.get('summary') or bool(old.get('excluded'))!=bool(new.get('excluded')):
            changes.append({'case':case.name,'configuration':cfg,'before':old.get('summary'),'after':new.get('summary'),'excluded':new.get('excluded',False)})
            print(case.name,cfg,new['summary'],flush=True)
runner.write_json(root/'regrade-changes.json',changes)
benchmark=generate_benchmark(root,'research-orchestrator-skill',str(runner.DEFAULT_SKILL))
runner.write_json(root/'benchmark.json',benchmark)
(root/'benchmark.md').write_text(generate_markdown(benchmark),encoding='utf-8')
print(benchmark['metadata'],benchmark['run_summary'])
