# Skill benchmark: research-orchestrator-skill

Included runs: 75; excluded runs: 19.

with_skill - old_skill comparison: 31 / 47 cases matched.
Excluded 19 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |
| with_skill | 43 | 87.87% | 491.0459 |
| old_skill | 32 | 47.23% | 559.6645 |

## Excluded runs

- analytic-complete-coverage/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- cli-hook-literal/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-enforcement-evidence/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-enforcement-evidence/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-host-capabilities/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- credential-storage-redaction/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- direct-install-reviewer/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- direct-install-reviewer/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- evaluation-trace-audit/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- fenced-record-examples/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-interpreter-override/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-interpreter-override/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- launch-root-binding/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- native-session-slots/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- owned-job-monitor/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- quick-goal-routing/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- selection-family-source/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- work-brief-references/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- work-project-start/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
