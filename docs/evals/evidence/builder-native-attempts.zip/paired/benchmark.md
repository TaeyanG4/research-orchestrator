# Skill benchmark: research-orchestrator-skill

Included runs: 0; excluded runs: 2.

with_skill - old_skill comparison: 0 / 1 cases matched. Delta unavailable (no matched cases).
Excluded 2 runs; see excluded_runs for reasons.
All four native preflights timed out before a returned tool result or completed turn appeared in the retained event stream.
All four output directories contain only unchanged brief.md and trial.md fixtures plus an empty final.md; there is no substantive result to grade.
Distinct thread.started IDs establish fresh native threads, not fresh user or Codex homes; the harness explicitly records shared host homes and residual access risks.
The paired current/baseline attempts used the same final case prompt; the two earlier baseline-only attempts used earlier prompt revisions and are separate preflights.
The three baseline attempts pin revision 713088d79745589b053ae02996670dc7147a8ee1 and identical runtime digest b2c01f24428b04d8a31225e0f7a3aaed0cc819b52715292c165a264a943588c4.
Executor commentary reports pending initial reads; native events do not identify the exact cause. The startup feature warning alone does not establish causation.
No skill winner, assertion pass rate, instruction-following score, token comparison or execution-performance delta can be inferred from these excluded preflights.
The earlier seven-case benchmark remains historical evidence with shared executor context and executor-written summarized transcripts; it is not upgraded by these attempts.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |

## Excluded runs

- work-project-session-history/old_skill: Infrastructure preflight excluded: native events contain no returned tool result or completed turn; the timeout left no task artifacts beyond unchanged input fixtures and an empty final message. The traces do not establish the exact cause; no skill-performance verdict is assigned.
- work-project-session-history/with_skill: Infrastructure preflight excluded: native events contain no returned tool result or completed turn; the timeout left no task artifacts beyond unchanged input fixtures and an empty final message. The traces do not establish the exact cause; no skill-performance verdict is assigned.
