# Skill benchmark: research-orchestrator-skill

Included runs: 0; excluded runs: 2.

with_skill - old_skill comparison: 0 / 1 cases matched. Delta unavailable (no matched cases).
Excluded 2 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |

## Excluded runs

- work-project-start/old_skill: Grading error: Infrastructure preflight stopped at its 60-second cap before any task tool operation or completed result; excluded from behavioral scoring.
- work-project-start/with_skill: Grading error: Infrastructure preflight stopped at its 60-second cap before any task tool operation or completed result; excluded from behavioral scoring.
