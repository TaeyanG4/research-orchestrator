# Skill benchmark: research-orchestrator-skill

Included runs: 0; excluded runs: 64.

with_skill - old_skill comparison: 0 / 32 cases matched. Delta unavailable (no matched cases).
Excluded 64 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |

## Excluded runs

- analytic-complete-coverage/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- analytic-complete-coverage/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- cli-hook-literal/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- cli-hook-literal/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- close-recorded-scope/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- close-recorded-scope/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-enforcement-evidence/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-enforcement-evidence/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-host-capabilities/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- codex-host-capabilities/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- competition-direction-review/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- competition-direction-review/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- competition-preset-transition/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- competition-preset-transition/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- dangling-instrument-evidence/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- dangling-instrument-evidence/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- direction-review-grace/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- direction-review-grace/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- external-action-order/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- external-action-order/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- external-retry-chain/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- external-retry-chain/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-effective-working-directory/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-effective-working-directory/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-interpreter-override/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-interpreter-override/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-portability/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- hook-portability/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- job-monitor-recovery/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- job-monitor-recovery/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- launch-root-binding/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- launch-root-binding/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- non-ml-replication/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- non-ml-replication/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- note-id-kind/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- note-id-kind/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- owned-job-monitor/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- owned-job-monitor/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- owned-job-parent-exit/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- owned-job-parent-exit/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- project-language/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- project-language/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- queue-freeze-delivery/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- queue-freeze-delivery/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- quick-goal-routing/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- quick-goal-routing/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- release-ci-matrix/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- release-ci-matrix/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- repair-missing-coordination/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- repair-missing-coordination/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- reviewer-read-only/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- reviewer-read-only/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- selection-family-source/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- selection-family-source/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- unified-research-resume/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- unified-research-resume/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- v2-rules-upgrade/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- v2-rules-upgrade/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- v3-interface-scope/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- v3-interface-scope/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- work-project-session-history/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- work-project-session-history/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- work-project-start/old_skill: Contaminated executor trace; excluded from grading and benchmark statistics
- work-project-start/with_skill: Contaminated executor trace; excluded from grading and benchmark statistics
