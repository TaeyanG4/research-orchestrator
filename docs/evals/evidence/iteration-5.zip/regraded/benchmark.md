# Skill benchmark: research-orchestrator-skill

Included runs: 52; excluded runs: 12.

Original benchmark excluded all 64 runs and contained no assertion grades.
Reconstructed grades combine corrected scripted checks and skill-creator artifact review.
One sample per case/configuration; cross-case standard deviation is not repeat-run variance.
Timing is original executor duration only; no post-change improvement or repeat variance is measured.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |
| with_skill | 29 | 99.62% | 236.3199 |
| old_skill | 23 | 47.93% | 258.7099 |

## Excluded runs

- cli-hook-literal/with_skill: isolation boundary: parent instruction-file probes (no foreign read established)
- cli-hook-literal/old_skill: isolation: foreign source/runtime/installed material
- codex-enforcement-evidence/with_skill: infrastructure: setup/copy
- codex-enforcement-evidence/old_skill: infrastructure: setup/copy
- codex-host-capabilities/old_skill: isolation: foreign source/runtime/installed material
- external-action-order/old_skill: isolation: foreign source/runtime/installed material
- hook-interpreter-override/with_skill: infrastructure: setup/copy
- hook-interpreter-override/old_skill: infrastructure: setup/copy
- launch-root-binding/old_skill: isolation: foreign source/runtime/installed material
- note-id-kind/old_skill: isolation: foreign source/runtime/installed material
- owned-job-monitor/old_skill: isolation: foreign source/runtime/installed material
- quick-goal-routing/old_skill: isolation boundary: parent instruction-file probes (no foreign read established)
