# Skill benchmark: research-orchestrator-skill

Included runs: 0; excluded runs: 2.

with_skill - old_skill comparison: 0 / 1 cases matched. Delta unavailable (no matched cases).
Excluded 2 runs; see excluded_runs for reasons.

| Configuration | Included | Mean pass rate | Mean seconds |
| --- | ---: | ---: | ---: |

## Excluded runs

- work-project-start/old_skill: Grading error: Infrastructure-blocked full-duration attempt: native terminal response reports stalled local reads, no task tool items or setup artifacts were retained, and the harness records a 600-second timeout. Excluded from behavioral scoring; precise execution failure cause is unverified.
- work-project-start/with_skill: Grading error: Infrastructure-blocked full-duration attempt: native terminal response reports stalled local reads, no task tool items or setup artifacts were retained, and the harness records a 600-second timeout. Excluded from behavioral scoring; precise execution failure cause is unverified.
